from __future__ import annotations

from dataclasses import dataclass, asdict, field, replace
from typing import Callable, Dict, Iterable, List, Literal, Optional, Sequence, Tuple
import copy
import hashlib
import json
import sqlite3
import time
import uuid


Status = Literal["SOURCE", "DERIVED", "OPEN", "PROPOSED"]
ResidualKind = Literal["drop", "add", "strength"]

STRENGTH_RANK = {
    "possible": 0,
    "supported": 1,
    "implied": 2,
    "exact": 3,
}


def canonical_json(obj) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def digest_obj(obj) -> str:
    return sha256_text(canonical_json(obj))


@dataclass(frozen=True)
class TypedEdge:
    """
    One load-bearing semantic relation.

    edge_id:
        Persistent identity of this occurrence of the relation.
    parent_edge_id:
        Reference edge this candidate claims to carry/reuse.
    licensed_by:
        IDs of witnessed source/input edges that license a genuinely new relation.
    """
    edge_id: str
    symbol: str
    jurisdiction: str
    source_id: str
    source_digest: str
    authority: int
    office: str
    subject: str
    relation: str
    object: str
    domain: str
    range: str
    scope: str
    strength: str
    status: Status
    required: bool = True
    dependency_rank: int = 0
    parent_edge_id: Optional[str] = None
    licensed_by: Tuple[str, ...] = ()

    def semantic_payload(self) -> dict:
        return {
            "symbol": self.symbol,
            "jurisdiction": self.jurisdiction,
            "office": self.office,
            "subject": self.subject,
            "relation": self.relation,
            "object": self.object,
            "domain": self.domain,
            "range": self.range,
            "scope": self.scope,
            "strength": self.strength,
            "authority": self.authority,
            "status": self.status,
        }

    def semantic_digest(self) -> str:
        return digest_obj(self.semantic_payload())


@dataclass(frozen=True)
class HoldPacket:
    """
    Protected state handed to proposal generation.

    All fields are immutable. The proposal channel receives this packet by value;
    host state remains outside that channel.
    """
    hold_id: str
    state_digest: str
    reference_id: str
    jurisdiction: str
    reader_id: str
    occurrence: int
    receipt_head: str
    edges: Tuple[TypedEdge, ...]


@dataclass(frozen=True)
class PrivateProposal:
    candidate_id: str
    private_text: str
    edges: Tuple[TypedEdge, ...]

    def digest(self) -> str:
        return digest_obj({
            "candidate_id": self.candidate_id,
            "private_text": self.private_text,
            "edges": [asdict(e) for e in self.edges],
        })


@dataclass(frozen=True)
class Residual:
    kind: ResidualKind
    symbol: str
    reason: str
    dependency_rank: int
    reference_edge_id: Optional[str] = None
    candidate_edge_id: Optional[str] = None
    detail: Optional[str] = None


@dataclass(frozen=True)
class ReturnResult:
    residuals: Tuple[Residual, ...]
    counts: Dict[str, int]
    fit: int

    @property
    def admissible(self) -> bool:
        return (
            self.counts["drop"] == 0
            and self.counts["add"] == 0
            and self.counts["strength"] == 0
            and self.fit == 1
        )


@dataclass
class RuntimeState:
    reference_id: str
    jurisdiction: str
    reader_id: str
    occurrence: int
    edges: List[TypedEdge]

    def snapshot(self) -> dict:
        return {
            "reference_id": self.reference_id,
            "jurisdiction": self.jurisdiction,
            "reader_id": self.reader_id,
            "occurrence": self.occurrence,
            "edges": [asdict(e) for e in sorted(self.edges, key=lambda x: (x.dependency_rank, x.edge_id))],
        }

    def digest(self) -> str:
        return digest_obj(self.snapshot())


class ReceiptStore:
    """
    SQLite append-only event log + append-only committed snapshots.

    UPDATE and DELETE are mechanically blocked by triggers.
    Each event is hash chained.
    """

    def __init__(self, path: str):
        self.path = path
        self.db = sqlite3.connect(path)
        self.db.row_factory = sqlite3.Row
        self._init_schema()

    def close(self):
        self.db.close()

    def _init_schema(self):
        self.db.executescript(
            """
            PRAGMA journal_mode=WAL;
            PRAGMA foreign_keys=ON;

            CREATE TABLE IF NOT EXISTS events (
                seq INTEGER PRIMARY KEY AUTOINCREMENT,
                ts REAL NOT NULL,
                occurrence INTEGER NOT NULL,
                event_type TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                prev_hash TEXT NOT NULL,
                event_hash TEXT NOT NULL UNIQUE
            );

            CREATE TABLE IF NOT EXISTS snapshots (
                seq INTEGER PRIMARY KEY AUTOINCREMENT,
                ts REAL NOT NULL,
                occurrence INTEGER NOT NULL,
                state_json TEXT NOT NULL,
                state_digest TEXT NOT NULL
            );

            CREATE TRIGGER IF NOT EXISTS events_no_update
            BEFORE UPDATE ON events
            BEGIN
                SELECT RAISE(ABORT, 'events are append-only');
            END;

            CREATE TRIGGER IF NOT EXISTS events_no_delete
            BEFORE DELETE ON events
            BEGIN
                SELECT RAISE(ABORT, 'events are append-only');
            END;

            CREATE TRIGGER IF NOT EXISTS snapshots_no_update
            BEFORE UPDATE ON snapshots
            BEGIN
                SELECT RAISE(ABORT, 'snapshots are append-only');
            END;

            CREATE TRIGGER IF NOT EXISTS snapshots_no_delete
            BEFORE DELETE ON snapshots
            BEGIN
                SELECT RAISE(ABORT, 'snapshots are append-only');
            END;
            """
        )
        self.db.commit()

    def head_hash(self) -> str:
        row = self.db.execute(
            "SELECT event_hash FROM events ORDER BY seq DESC LIMIT 1"
        ).fetchone()
        return row["event_hash"] if row else "GENESIS"

    def append_event(self, occurrence: int, event_type: str, payload: dict) -> str:
        prev = self.head_hash()
        envelope = {
            "occurrence": occurrence,
            "event_type": event_type,
            "payload": payload,
            "prev_hash": prev,
        }
        event_hash = digest_obj(envelope)
        self.db.execute(
            """
            INSERT INTO events(ts, occurrence, event_type, payload_json, prev_hash, event_hash)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                time.time(),
                occurrence,
                event_type,
                canonical_json(payload),
                prev,
                event_hash,
            ),
        )
        self.db.commit()
        return event_hash

    def append_snapshot(self, state: RuntimeState):
        state_json = canonical_json(state.snapshot())
        self.db.execute(
            """
            INSERT INTO snapshots(ts, occurrence, state_json, state_digest)
            VALUES (?, ?, ?, ?)
            """,
            (time.time(), state.occurrence, state_json, state.digest()),
        )
        self.db.commit()

    def latest_snapshot(self) -> Optional[RuntimeState]:
        row = self.db.execute(
            "SELECT state_json FROM snapshots ORDER BY seq DESC LIMIT 1"
        ).fetchone()
        if not row:
            return None
        data = json.loads(row["state_json"])
        return RuntimeState(
            reference_id=data["reference_id"],
            jurisdiction=data["jurisdiction"],
            reader_id=data["reader_id"],
            occurrence=data["occurrence"],
            edges=[TypedEdge(**e) for e in data["edges"]],
        )

    def events(self) -> List[dict]:
        rows = self.db.execute("SELECT * FROM events ORDER BY seq").fetchall()
        return [dict(r) for r in rows]

    def verify_chain(self) -> bool:
        prev = "GENESIS"
        for row in self.db.execute("SELECT * FROM events ORDER BY seq"):
            payload = json.loads(row["payload_json"])
            envelope = {
                "occurrence": row["occurrence"],
                "event_type": row["event_type"],
                "payload": payload,
                "prev_hash": prev,
            }
            expected = digest_obj(envelope)
            if row["prev_hash"] != prev or row["event_hash"] != expected:
                return False
            prev = row["event_hash"]
        return True


class ReturnComparator:
    """
    Deterministic RETURN_COMPARE over already-parsed typed edges.

    Parsing free text into edges is intentionally outside this class.
    """

    TYPE_FIELDS = (
        "jurisdiction",
        "office",
        "subject",
        "relation",
        "object",
        "domain",
        "range",
        "scope",
    )

    def compare(
        self,
        hold: HoldPacket,
        proposal: PrivateProposal,
        licensed_edge_ids: Iterable[str] = (),
    ) -> ReturnResult:
        refs = {e.edge_id: e for e in hold.edges}
        candidates = list(proposal.edges)
        residuals: List[Residual] = []
        licensed = set(licensed_edge_ids) | set(refs)

        by_parent: Dict[str, List[TypedEdge]] = {}
        for edge in candidates:
            if edge.parent_edge_id:
                by_parent.setdefault(edge.parent_edge_id, []).append(edge)

        # Required edge carriage.
        for ref in sorted(hold.edges, key=lambda e: (e.dependency_rank, e.edge_id)):
            if not ref.required or ref.status not in ("SOURCE", "DERIVED"):
                continue
            carriers = by_parent.get(ref.edge_id, [])
            if not carriers:
                residuals.append(
                    Residual(
                        kind="drop",
                        symbol=ref.symbol,
                        reason="required witnessed relation disappeared",
                        dependency_rank=ref.dependency_rank,
                        reference_edge_id=ref.edge_id,
                    )
                )
                continue

            # More than one child is an unsupported branch in v0.2.
            if len(carriers) > 1:
                for extra in carriers[1:]:
                    residuals.append(
                        Residual(
                            kind="add",
                            symbol=extra.symbol,
                            reason="multiple candidate branches claim the same reference edge",
                            dependency_rank=extra.dependency_rank,
                            reference_edge_id=ref.edge_id,
                            candidate_edge_id=extra.edge_id,
                        )
                    )

            cand = carriers[0]
            changed = [
                f for f in self.TYPE_FIELDS if getattr(cand, f) != getattr(ref, f)
            ]
            stronger = STRENGTH_RANK.get(cand.strength, 999) > STRENGTH_RANK.get(ref.strength, -1)
            authority_up = cand.authority > ref.authority
            source_changed_without_license = (
                cand.source_digest != ref.source_digest
                and ref.edge_id not in cand.licensed_by
            )

            if changed or stronger or authority_up or source_changed_without_license:
                detail = {
                    "changed_fields": changed,
                    "stronger_claim": stronger,
                    "authority_increase": authority_up,
                    "source_changed_without_license": source_changed_without_license,
                }
                residuals.append(
                    Residual(
                        kind="strength",
                        symbol=ref.symbol,
                        reason="candidate migrated office/type/jurisdiction/provenance or increased claim strength",
                        dependency_rank=ref.dependency_rank,
                        reference_edge_id=ref.edge_id,
                        candidate_edge_id=cand.edge_id,
                        detail=canonical_json(detail),
                    )
                )

        # Unsupported additions and unknown parent identities.
        for cand in sorted(candidates, key=lambda e: (e.dependency_rank, e.edge_id)):
            if cand.parent_edge_id:
                if cand.parent_edge_id not in refs:
                    residuals.append(
                        Residual(
                            kind="add",
                            symbol=cand.symbol,
                            reason="candidate references an unknown parent edge",
                            dependency_rank=cand.dependency_rank,
                            candidate_edge_id=cand.edge_id,
                        )
                    )
                continue

            if not cand.licensed_by:
                residuals.append(
                    Residual(
                        kind="add",
                        symbol=cand.symbol,
                        reason="new load-bearing relation has no witnessed license",
                        dependency_rank=cand.dependency_rank,
                        candidate_edge_id=cand.edge_id,
                    )
                )
                continue

            if not set(cand.licensed_by).issubset(licensed):
                residuals.append(
                    Residual(
                        kind="add",
                        symbol=cand.symbol,
                        reason="candidate claims unavailable licensing edges",
                        dependency_rank=cand.dependency_rank,
                        candidate_edge_id=cand.edge_id,
                    )
                )

        # Stable dependency order.
        kind_order = {"drop": 0, "add": 1, "strength": 2}
        residuals.sort(key=lambda r: (r.dependency_rank, kind_order[r.kind], r.symbol))

        counts = {
            "drop": sum(r.kind == "drop" for r in residuals),
            "add": sum(r.kind == "add" for r in residuals),
            "strength": sum(r.kind == "strength" for r in residuals),
        }

        fit = int(
            not residuals
            and hold.jurisdiction != ""
            and all(e.jurisdiction == hold.jurisdiction for e in candidates)
        )

        return ReturnResult(tuple(residuals), counts, fit)


class SurgicalRepairer:
    """
    Deterministic graph repair for the first residual only.

    In production, a model may be asked to rewrite the owning text span, but the
    returned typed edge must still pass this deterministic replay.
    """

    def repair_first(
        self,
        hold: HoldPacket,
        proposal: PrivateProposal,
        result: ReturnResult,
    ) -> Tuple[PrivateProposal, str]:
        if not result.residuals:
            return proposal, "no repair"

        residual = result.residuals[0]
        ref_by_id = {e.edge_id: e for e in hold.edges}
        before = {e.edge_id: e.semantic_digest() for e in proposal.edges}
        edges = list(proposal.edges)

        if residual.kind == "drop":
            ref = ref_by_id[residual.reference_edge_id]
            restored = replace(
                ref,
                edge_id=f"cand-{uuid.uuid4().hex[:12]}",
                parent_edge_id=ref.edge_id,
                status="PROPOSED",
            )
            edges.append(restored)
            note = f"restored dropped edge {ref.edge_id}"

        elif residual.kind == "add":
            target = residual.candidate_edge_id
            edges = [e for e in edges if e.edge_id != target]
            note = f"removed unsupported edge {target}"

        elif residual.kind == "strength":
            ref = ref_by_id[residual.reference_edge_id]
            target = residual.candidate_edge_id
            repaired: List[TypedEdge] = []
            for e in edges:
                if e.edge_id == target:
                    repaired.append(
                        replace(
                            ref,
                            edge_id=e.edge_id,
                            parent_edge_id=ref.edge_id,
                            status="PROPOSED",
                        )
                    )
                else:
                    repaired.append(e)
            edges = repaired
            note = f"restored witnessed semantics for {ref.edge_id}"

        else:
            raise ValueError(residual.kind)

        # Surgical invariant: all unrelated candidate edge digests are unchanged.
        after = {e.edge_id: e.semantic_digest() for e in edges}
        touched = {residual.candidate_edge_id} if residual.candidate_edge_id else set()
        for edge_id, digest_before in before.items():
            if edge_id in touched:
                continue
            if edge_id in after and after[edge_id] != digest_before:
                raise RuntimeError(f"non-surgical repair mutated unrelated edge {edge_id}")

        repaired_proposal = PrivateProposal(
            candidate_id=proposal.candidate_id,
            private_text=proposal.private_text,  # never emitted directly
            edges=tuple(edges),
        )
        return repaired_proposal, note


class PreCommitRuntime:
    """
    Host-level reference implementation.

    Sequence:
      immutable HOLD
      -> private proposal
      -> deterministic RETURN_COMPARE
      -> one-edge repair
      -> mandatory replay
      -> COMMIT persisted
      -> render/emit
      -> append EMIT event

    No candidate text is returned to the user before COMMIT.
    """

    def __init__(
        self,
        state: RuntimeState,
        store: ReceiptStore,
        *,
        comparator: Optional[ReturnComparator] = None,
        repairer: Optional[SurgicalRepairer] = None,
    ):
        self.state = state
        self.store = store
        self.comparator = comparator or ReturnComparator()
        self.repairer = repairer or SurgicalRepairer()
        if self.store.latest_snapshot() is None:
            self.store.append_snapshot(self.state)

    def hold(self) -> HoldPacket:
        hold = HoldPacket(
            hold_id=f"hold-{uuid.uuid4().hex}",
            state_digest=self.state.digest(),
            reference_id=self.state.reference_id,
            jurisdiction=self.state.jurisdiction,
            reader_id=self.state.reader_id,
            occurrence=self.state.occurrence,
            receipt_head=self.store.head_hash(),
            edges=tuple(copy.deepcopy(self.state.edges)),
        )
        self.store.append_event(
            self.state.occurrence,
            "HOLD_CREATED",
            {
                "hold_id": hold.hold_id,
                "state_digest": hold.state_digest,
                "receipt_head": hold.receipt_head,
                "edge_ids": [e.edge_id for e in hold.edges],
            },
        )
        return hold

    def process(
        self,
        generate_private: Callable[[HoldPacket], PrivateProposal],
        render_committed: Callable[[Sequence[TypedEdge]], str],
        emit: Callable[[str], None],
        *,
        licensed_edge_ids: Iterable[str] = (),
        max_repairs: int = 16,
        record_regression_case: bool = True,
    ) -> str:
        hold = self.hold()

        proposal = generate_private(hold)
        self.store.append_event(
            self.state.occurrence,
            "PRIVATE_PROPOSAL",
            {
                "hold_id": hold.hold_id,
                "candidate_id": proposal.candidate_id,
                "candidate_digest": proposal.digest(),
                "edges": [asdict(e) for e in proposal.edges],
            },
        )

        initial_proposal = proposal
        residual_trace: List[dict] = []

        for repair_index in range(max_repairs + 1):
            result = self.comparator.compare(hold, proposal, licensed_edge_ids)
            residual_trace.append({
                "counts": result.counts,
                "fit": result.fit,
                "residuals": [asdict(r) for r in result.residuals],
            })
            self.store.append_event(
                self.state.occurrence,
                "RETURN_COMPARE",
                {
                    "hold_id": hold.hold_id,
                    "candidate_id": proposal.candidate_id,
                    "candidate_digest": proposal.digest(),
                    "counts": result.counts,
                    "fit": result.fit,
                    "residuals": [asdict(r) for r in result.residuals],
                },
            )

            if result.admissible:
                # Commit semantic state BEFORE rendering/emission.
                committed_edges = [
                    replace(
                        e,
                        edge_id=(e.parent_edge_id or e.edge_id),
                        parent_edge_id=None,
                        status=("SOURCE" if e.status == "PROPOSED" else e.status),
                    )
                    for e in proposal.edges
                ]
                next_state = RuntimeState(
                    reference_id=self.state.reference_id,
                    jurisdiction=self.state.jurisdiction,
                    reader_id=self.state.reader_id,
                    occurrence=self.state.occurrence + 1,
                    edges=committed_edges,
                )
                pre_digest = self.state.digest()
                post_digest = next_state.digest()

                self.store.append_event(
                    next_state.occurrence,
                    "COMMIT",
                    {
                        "hold_id": hold.hold_id,
                        "candidate_id": proposal.candidate_id,
                        "pre_state_digest": pre_digest,
                        "post_state_digest": post_digest,
                        "counts": result.counts,
                        "fit": result.fit,
                    },
                )
                self.state = next_state
                self.store.append_snapshot(self.state)

                if record_regression_case:
                    self.store.append_event(
                        self.state.occurrence,
                        "REGRESSION_CASE",
                        {
                            "hold": {
                                "reference_id": hold.reference_id,
                                "jurisdiction": hold.jurisdiction,
                                "reader_id": hold.reader_id,
                                "occurrence": hold.occurrence,
                                "edges": [asdict(e) for e in hold.edges],
                            },
                            "initial_proposal": {
                                "candidate_id": initial_proposal.candidate_id,
                                "private_text": initial_proposal.private_text,
                                "edges": [asdict(e) for e in initial_proposal.edges],
                            },
                            "licensed_edge_ids": list(licensed_edge_ids),
                            "expected_final_edge_semantics": {
                                e.edge_id: e.semantic_digest() for e in self.state.edges
                            },
                            "expected_residual_trace": residual_trace,
                        },
                    )

                output = render_committed(tuple(self.state.edges))
                # User-visible emission occurs only after persisted COMMIT.
                emit(output)
                self.store.append_event(
                    self.state.occurrence,
                    "EMIT",
                    {
                        "post_state_digest": self.state.digest(),
                        "output_sha256": sha256_text(output),
                    },
                )
                return output

            if repair_index >= max_repairs:
                raise RuntimeError("repair limit exceeded")

            proposal, note = self.repairer.repair_first(hold, proposal, result)
            self.store.append_event(
                self.state.occurrence,
                "REPAIR_APPLIED",
                {
                    "hold_id": hold.hold_id,
                    "candidate_id": proposal.candidate_id,
                    "repair_index": repair_index,
                    "note": note,
                    "candidate_digest_after": proposal.digest(),
                },
            )
            # Mandatory replay happens by loop continuation.

        raise AssertionError("unreachable")


class RegressionReplay:
    """
    Replays retained REGRESSION_CASE events against the current comparator/repairer.
    """

    def __init__(
        self,
        store: ReceiptStore,
        comparator: Optional[ReturnComparator] = None,
        repairer: Optional[SurgicalRepairer] = None,
    ):
        self.store = store
        self.comparator = comparator or ReturnComparator()
        self.repairer = repairer or SurgicalRepairer()

    def run(self) -> List[dict]:
        results = []
        rows = self.store.db.execute(
            "SELECT payload_json FROM events WHERE event_type='REGRESSION_CASE' ORDER BY seq"
        ).fetchall()

        for i, row in enumerate(rows, start=1):
            case = json.loads(row["payload_json"])
            h = case["hold"]
            hold = HoldPacket(
                hold_id=f"replay-{i}",
                state_digest="replay",
                reference_id=h["reference_id"],
                jurisdiction=h["jurisdiction"],
                reader_id=h["reader_id"],
                occurrence=h["occurrence"],
                receipt_head="replay",
                edges=tuple(TypedEdge(**e) for e in h["edges"]),
            )
            p = case["initial_proposal"]
            proposal = PrivateProposal(
                candidate_id=p["candidate_id"],
                private_text=p["private_text"],
                edges=tuple(TypedEdge(**e) for e in p["edges"]),
            )
            licensed = case["licensed_edge_ids"]

            trace = []
            for _ in range(32):
                result = self.comparator.compare(hold, proposal, licensed)
                trace.append({
                    "counts": result.counts,
                    "fit": result.fit,
                    "residuals": [asdict(r) for r in result.residuals],
                })
                if result.admissible:
                    break
                proposal, _ = self.repairer.repair_first(hold, proposal, result)
            else:
                raise RuntimeError("replay did not converge")

            final_edges = [
                replace(
                    e,
                    edge_id=(e.parent_edge_id or e.edge_id),
                    parent_edge_id=None,
                    status=("SOURCE" if e.status == "PROPOSED" else e.status),
                )
                for e in proposal.edges
            ]
            final_semantics = {e.edge_id: e.semantic_digest() for e in final_edges}
            passed = (
                final_semantics == case["expected_final_edge_semantics"]
                and trace == case["expected_residual_trace"]
            )
            results.append({
                "case": i,
                "passed": passed,
                "trace": trace,
            })

        return results
