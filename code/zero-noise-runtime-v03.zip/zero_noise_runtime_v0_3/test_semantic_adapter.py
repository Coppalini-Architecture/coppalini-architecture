import hashlib
import json

from semantic_adapter import (
    AdapterResult,
    EvidenceSpan,
    ProposedRelation,
    SemanticAdapter,
    SourceDocument,
)

TEXT = "Theta is Timing. Theta maps n to n+1. g is Read."
RAW = TEXT.encode("utf-8")
DIGEST = hashlib.sha256(RAW).hexdigest()

OFFICES = {"Timing", "Read", "Receipt", "Carriage", "Survival"}


def source():
    return SourceDocument(
        source_id="fixture",
        raw_bytes=RAW,
        authority=2,
        jurisdiction="test",
    )


def proposal_theta(**changes):
    quote = "Theta maps n to n+1."
    start = TEXT.index(quote)
    p = dict(
        proposal_id="p1",
        symbol="Theta",
        office="Timing",
        subject="Theta",
        relation="successor",
        object="n+1",
        domain="n",
        range="n+1",
        scope="occurrence-index",
        strength="exact",
        status="PROPOSED",
        evidence=(EvidenceSpan(start, start+len(quote), quote),),
        claimed_source_sha256=DIGEST,
        claimed_authority=2,
        dependency_rank=1,
        parent_edge_id=None,
        licensed_by=(),
    )
    p.update(changes)
    return ProposedRelation(**p)


def test_valid_binding():
    result = SemanticAdapter(OFFICES).bind(source(), [proposal_theta()])
    assert not result.untypeable
    assert len(result.edges) == 1
    edge = result.edges[0]
    assert edge.symbol == "Theta"
    assert edge.source_digest == DIGEST
    assert edge.office == "Timing"


def test_fabricated_quote_blocked():
    bad = proposal_theta(
        evidence=(EvidenceSpan(0, 5, "WRONG"),)
    )
    result = SemanticAdapter(OFFICES).bind(source(), [bad])
    assert result.untypeable
    assert "evidence span mismatch" in result.residuals[0].reason


def test_source_digest_mismatch_blocked():
    result = SemanticAdapter(OFFICES).bind(
        source(),
        [proposal_theta(claimed_source_sha256="bad")],
    )
    assert result.untypeable
    assert "source digest mismatch" in result.residuals[0].reason


def test_authority_strengthening_blocked():
    result = SemanticAdapter(OFFICES).bind(
        source(),
        [proposal_theta(claimed_authority=3)],
    )
    assert result.untypeable
    assert "authority strengthening" in result.residuals[0].reason


def test_unknown_office_blocked():
    result = SemanticAdapter(OFFICES).bind(
        source(),
        [proposal_theta(office="Magic")],
    )
    assert result.untypeable
    assert "unknown office" in result.residuals[0].reason


def test_empty_extraction_is_untypeable():
    result = SemanticAdapter(OFFICES).bind(source(), [])
    assert result.untypeable
    assert result.edges == ()


if __name__ == "__main__":
    test_valid_binding()
    test_fabricated_quote_blocked()
    test_source_digest_mismatch_blocked()
    test_authority_strengthening_blocked()
    test_unknown_office_blocked()
    test_empty_extraction_is_untypeable()
    print("PASS: 6 semantic-adapter groups")
