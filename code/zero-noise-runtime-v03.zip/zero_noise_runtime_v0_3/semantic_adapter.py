from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Literal, Optional, Sequence, Tuple
import hashlib
import json
import uuid

from znc_runtime import TypedEdge


Strength = Literal["possible", "supported", "implied", "exact"]
Status = Literal["SOURCE", "DERIVED", "OPEN", "PROPOSED"]


class Untypeable:
    pass


UNTYPEABLE = Untypeable()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


@dataclass(frozen=True)
class SourceDocument:
    source_id: str
    raw_bytes: bytes
    authority: int
    jurisdiction: str

    @property
    def sha256(self) -> str:
        return sha256_bytes(self.raw_bytes)

    @property
    def text(self) -> str:
        return self.raw_bytes.decode("utf-8")


@dataclass(frozen=True)
class EvidenceSpan:
    start: int
    end: int
    quote: str

    def validate(self, text: str) -> bool:
        if self.start < 0 or self.end < self.start or self.end > len(text):
            return False
        return text[self.start:self.end] == self.quote


@dataclass(frozen=True)
class ProposedRelation:
    """
    Model- or parser-proposed semantic extraction.

    This object is never trusted as committed semantics merely because it is valid JSON.
    """
    proposal_id: str
    symbol: str
    office: str
    subject: str
    relation: str
    object: str
    domain: str
    range: str
    scope: str
    strength: Strength
    status: Status
    evidence: Tuple[EvidenceSpan, ...]
    claimed_source_sha256: str
    claimed_authority: int
    dependency_rank: int = 0
    parent_edge_id: Optional[str] = None
    licensed_by: Tuple[str, ...] = ()


@dataclass(frozen=True)
class AdapterResidual:
    proposal_id: str
    kind: str
    reason: str


@dataclass(frozen=True)
class AdapterResult:
    edges: Tuple[TypedEdge, ...]
    residuals: Tuple[AdapterResidual, ...]
    untypeable: bool


class SemanticAdapter:
    """
    Deterministic evidence binder.

    It does NOT infer semantics from free text by itself.
    An upstream model/parser proposes relations.
    This adapter decides whether those proposed relations are sufficiently
    source-bound to enter RETURN_COMPARE as PROPOSED typed edges.

    Guarantees:
      - source digest must match exact bytes;
      - authority cannot exceed source authority;
      - every relation must carry at least one exact evidence span;
      - evidence spans must match exact source text;
      - office/strength/status must be in the allowed registries;
      - empty or invalid extraction becomes UNTYPEABLE rather than fabricated meaning.
    """

    ALLOWED_STRENGTH = {"possible", "supported", "implied", "exact"}
    ALLOWED_STATUS = {"SOURCE", "DERIVED", "OPEN", "PROPOSED"}

    def __init__(self, office_registry: Optional[Iterable[str]] = None):
        self.office_registry = set(office_registry or [])

    def bind(
        self,
        source: SourceDocument,
        proposals: Sequence[ProposedRelation],
    ) -> AdapterResult:
        if not proposals:
            return AdapterResult((), (), True)

        edges: List[TypedEdge] = []
        residuals: List[AdapterResidual] = []

        for p in proposals:
            reasons = []

            if p.claimed_source_sha256 != source.sha256:
                reasons.append("source digest mismatch")

            if p.claimed_authority > source.authority:
                reasons.append("authority strengthening")

            if p.strength not in self.ALLOWED_STRENGTH:
                reasons.append("unknown strength")

            if p.status not in self.ALLOWED_STATUS:
                reasons.append("unknown status")

            if self.office_registry and p.office not in self.office_registry:
                reasons.append("unknown office")

            if not p.evidence:
                reasons.append("missing evidence")

            for ev in p.evidence:
                if not ev.validate(source.text):
                    reasons.append("evidence span mismatch")
                    break

            for field_name, value in [
                ("symbol", p.symbol),
                ("office", p.office),
                ("subject", p.subject),
                ("relation", p.relation),
                ("object", p.object),
                ("domain", p.domain),
                ("range", p.range),
                ("scope", p.scope),
            ]:
                if not isinstance(value, str) or not value.strip():
                    reasons.append(f"empty {field_name}")

            if reasons:
                residuals.append(
                    AdapterResidual(
                        proposal_id=p.proposal_id,
                        kind="UNTYPEABLE",
                        reason="; ".join(sorted(set(reasons))),
                    )
                )
                continue

            edge = TypedEdge(
                edge_id=f"edge-{uuid.uuid4().hex}",
                symbol=p.symbol,
                jurisdiction=source.jurisdiction,
                source_id=source.source_id,
                source_digest=source.sha256,
                authority=p.claimed_authority,
                office=p.office,
                subject=p.subject,
                relation=p.relation,
                object=p.object,
                domain=p.domain,
                range=p.range,
                scope=p.scope,
                strength=p.strength,
                status=p.status,
                required=True,
                dependency_rank=p.dependency_rank,
                parent_edge_id=p.parent_edge_id,
                licensed_by=p.licensed_by,
            )
            edges.append(edge)

        # No valid witnessed relation => no semantic output from this adapter.
        return AdapterResult(
            edges=tuple(edges),
            residuals=tuple(residuals),
            untypeable=(len(edges) == 0),
        )


def proposals_from_json(data: List[dict]) -> List[ProposedRelation]:
    out = []
    for row in data:
        evidence = tuple(EvidenceSpan(**ev) for ev in row.get("evidence", []))
        payload = dict(row)
        payload["evidence"] = evidence
        payload["licensed_by"] = tuple(payload.get("licensed_by", []))
        out.append(ProposedRelation(**payload))
    return out
