import hashlib
from semantic_adapter import EvidenceSpan, ProposedRelation, SemanticAdapter, SourceDocument

text = "Theta maps n to n+1."
raw = text.encode()
digest = hashlib.sha256(raw).hexdigest()
source = SourceDocument("demo", raw, authority=2, jurisdiction="demo")

start = 0
proposal = ProposedRelation(
    proposal_id="demo-1",
    symbol="Theta",
    office="Timing",
    subject="Theta",
    relation="successor",
    object="n+1",
    domain="n",
    range="n+1",
    scope="occurrence-index",
    strength="exact",
    status="PROPOSED",
    evidence=(EvidenceSpan(start, len(text), text),),
    claimed_source_sha256=digest,
    claimed_authority=2,
)

result = SemanticAdapter({"Timing"}).bind(source, [proposal])
print("untypeable =", result.untypeable)
print("edges =", len(result.edges))
print("source_digest =", result.edges[0].source_digest if result.edges else None)
