# Zero-Noise Runtime v0.3 — Semantic Adapter

This package adds the next implementation seam:

```text
natural language source bytes
        ↓
model/parser proposes typed relations
        ↓
DETERMINISTIC EVIDENCE BINDER
        ↓
bound PROPOSED edges
        ↓
RETURN_COMPARE
        ↓
repair / replay / commit
```

## Important boundary

The semantic adapter does **not** claim to solve language understanding deterministically.

An upstream model/parser may propose:

- subject
- relation
- object
- office
- domain/range
- strength
- scope

The deterministic adapter requires those proposals to carry exact source evidence
before they can enter RETURN_COMPARE.

It checks:

1. exact source SHA-256;
2. exact quote/span match;
3. no authority increase above the source;
4. known office;
5. known strength/status;
6. nonempty semantic fields.

If every proposed load-bearing relation fails binding, the adapter returns:

```text
UNTYPEABLE
```

rather than inventing meaning.

## Why this matters

Structured Outputs can enforce the JSON shape of a model extraction, but schema
compliance alone does not establish that the semantic values are correct or
source-grounded.

This adapter therefore treats structured extraction as a proposal.

RETURN_COMPARE still owns adoption.

## Run

```bash
python test_semantic_adapter.py
python demo_semantic_adapter.py
```

Expected:

```text
PASS: 6 semantic-adapter groups
```

## Next seam

The next engineering problem is proposal quality:

- sentence/claim segmentation;
- relation extraction;
- office classification;
- strength classification;
- cross-source provenance;
- ambiguity / OPEN handling.

Those are model-assisted tasks evaluated against source-bound fixtures. The
deterministic adapter and RETURN_COMPARE remain the commit boundary.
