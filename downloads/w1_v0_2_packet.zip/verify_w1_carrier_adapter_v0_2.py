#!/usr/bin/env python3
"""W-1 v0.2: carrier adapter  c_W(P) = u(P) (+) 0_{P^perp}  in  u(3) in k  ->  span(W+, W-, Z, A).

Run:  python3 -I verify_w1_carrier_adapter_v0_2.py      (exact SymPy; no floats; no empirical inputs)

Depends on
  F-5 / 05a SD.0, SD.9-SD.10:  eta^ = G + I2 + I2 + I2,  C^ = C + C + C + C,  k = Stab(eta^, C^), dim 10 (F5-L1-1 L1-0)
  W-0 v0.2: beta_EW (bracket), R_W, vacuum quadratic form, convention Q = T3 + Y, Y_phi = 1/2, g, g', v > 0 supplied
v0.2 vs v0.1: text only (map direction stated as iota_P with alpha_P = iota_P^{-1}; W1-9 conjugacy line); no change to any check.
This is an adapter verification.  It declares a carrier and a map; it does not identify particles, compare with data, or predict.
The transverse complex 2-plane P is a SUPPLIED choice shared with T1; its selection is OPEN (check W1-9).
"""
from __future__ import annotations
import sys, hashlib
import sympy as sp

checks = []
def zero(x):
    return all(sp.simplify(e) == 0 for e in x) if isinstance(x, sp.MatrixBase) else sp.simplify(x) == 0
def check(i, stmt, cond):
    if not cond: raise AssertionError(f"{i} failed: {stmt}")
    checks.append(i); print(f"[{i}] PASS  {stmt}")

R, I = sp.Rational, sp.I
g, gp, v = sp.symbols("g gprime v", positive=True, nonzero=True)
n = sp.sqrt(g**2 + gp**2); c_w, s_w = g / n, gp / n

# ---------------------------------------------------------------- carrier data (05a SD.0)
G = sp.Matrix([[-2, 1], [1, 2]]); C2 = sp.Matrix([[0, -1], [1, 0]])
ETA = sp.diag(G, sp.eye(2), sp.eye(2), sp.eye(2)); CH = sp.diag(C2, C2, C2, C2)
def in_k(X): return zero(X.T * ETA + ETA * X) and zero(X.T * CH + CH * X)

# W1-1  k = so(1,1) (+) u(3), dim 10, block diagonal; J = C^ on the transverse R^6 is a complex structure
xs = sp.symbols("x0:64"); Xg = sp.Matrix(8, 8, xs)
eqs = list(Xg.T * ETA + ETA * Xg) + list(Xg.T * CH + CH * Xg)
A, _ = sp.linear_eq_to_matrix(eqs, xs); ker = A.nullspace()
kmats = [sp.Matrix(8, 8, list(vv)) for vv in ker]
offblock = all(all(m[i, j] == 0 for i in range(2) for j in range(2, 8)) and all(m[i, j] == 0 for i in range(2, 8) for j in range(2)) for m in kmats)
root_dim = sp.Matrix([list(m[:2, :2]) for m in kmats]).rank(); trans_dim = sp.Matrix([list(m[2:, 2:]) for m in kmats]).rank()
J = CH[2:, 2:]
check("W1-1", "k = Stab(eta^, C^) has dim 10, block diagonal (root 2x2) + (transverse 6x6), with dims 1 (so(1,1)) + 9 (u(3)); J = C^ on the transverse R^6 satisfies J^2 = -1",
      len(ker) == 10 and offblock and root_dim == 1 and trans_dim == 9 and zero(J * J + sp.eye(6)))

# ---------------------------------------------------------------- declared carrier c_W(P)
# transverse blocks b = 1,2,3 occupy indices (2b, 2b+1); J e_{2b} = e_{2b+1}, i.e. e_{2b+1} = i e_{2b}.  P = blocks (1,2), P^perp = block 3.
def c2r(Z):
    m = Z.shape[0]; M = sp.zeros(2 * m, 2 * m)
    for p in range(m):
        for q in range(m):
            a, b = sp.re(Z[p, q]), sp.im(Z[p, q])
            M[2 * p:2 * p + 2, 2 * q:2 * q + 2] = sp.Matrix([[a, -b], [b, a]])
    return M
def embed(Z, blocks):
    idx = [i for b in blocks for i in (2 * b, 2 * b + 1)]; Mr = c2r(Z); M8 = sp.zeros(8, 8)
    for r, ir in enumerate(idx):
        for c, ic in enumerate(idx): M8[ir, ic] = Mr[r, c]
    return M8
sig = [sp.Matrix([[0, 1], [1, 0]]), sp.Matrix([[0, -I], [I, 0]]), sp.Matrix([[1, 0], [0, -1]])]
Zbasis = [-I / 2 * s for s in sig] + [-I / 2 * sp.eye(2)]          # e_1, e_2, e_3, e_B  (anti-Hermitian)
PB = (1, 2)
eP = [embed(Z, PB) for Z in Zbasis]
ind = sp.Matrix([list(m) for m in eP]).rank()
zero_root_perp = all(m[:2, :].is_zero_matrix and m[:, :2].is_zero_matrix and m[6:8, :].is_zero_matrix and m[:, 6:8].is_zero_matrix for m in eP)
hom = all(zero(c2r(Z1 * Z2 - Z2 * Z1) - (c2r(Z1) * c2r(Z2) - c2r(Z2) * c2r(Z1))) for Z1 in Zbasis for Z2 in Zbasis)
check("W1-2", "c_W(P) = u(P) (+) 0_{P^perp}: the four declared generators (three traceless on P, plus central iI_P/2) lie in k, are independent (real dim 4), vanish on the root block and on P^perp, and the real embedding is a Lie-algebra homomorphism",
      all(in_k(m) for m in eP) and ind == 4 and zero_root_perp and hom)

# ---------------------------------------------------------------- alpha_P : c_W(P) -> su(2)_L (+) u(1)_Y
beta = sp.Matrix([[0, 0, 0, 1, 0, 0], [0, -1, 0, 0, 0, 0], [1, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0]])   # W-0 beta_EW, wedge order 12,13,14,23,24,34
pairs = ((0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3))
# source basis (eps_1, eps_2, eps_3, eps_B) of su(2)_L (+) u(1)_Y with [eps_i, eps_j] = sum_k beta[k, (i,j)] eps_k;  iota_P(eps_i) = eP[i];  alpha_P = iota_P^{-1}
br_ok = all(zero(eP[i] * eP[j] - eP[j] * eP[i] - sum((beta[k, col] * eP[k] for k in range(4)), sp.zeros(8, 8))) for col, (i, j) in enumerate(pairs))
check("W1-3", "iota_P: su(2)_L (+) u(1)_Y -> c_W(P), eps_a -> -(i/2) sigma_a on P, eps_B -> -(i/2) I_P (eps_i -> e_{P,i}) is a Lie-algebra isomorphism onto c_W(P): every bracket equals the W-0 beta_EW structure constants (6 pairs, 8x8 real matrices); bijective (rank 4); alpha_P := iota_P^{-1}",
      br_ok and ind == 4)

# central line
comm_B = all(zero(eP[3] * m - m * eP[3]) for m in eP)
xc = sp.symbols("z0:4"); Xc = sum((xc[i] * eP[i] for i in range(4)), sp.zeros(8, 8))
Ac, _ = sp.linear_eq_to_matrix([e for i in range(4) for e in (Xc * eP[i] - eP[i] * Xc)], xc)
center_dim = len(Ac.nullspace()); cvec = Ac.nullspace()[0].T if center_dim else None
mix = sp.zeros(8, 8); mix[2, 6] = 1; mix[6, 2] = -1; mix[3, 7] = 1; mix[7, 3] = -1          # complex-linear antisymmetric P -> P^perp rotation in u(3)
check("W1-4", "the central line: eps_B commutes with c_W(P); the centre of c_W(P) is exactly R*eps_B; eps_B is central in c_W(P) only (it fails to commute with a u(3) generator mixing P and P^perp, which is in k)",
      comm_B and center_dim == 1 and zero(cvec - sp.Matrix([[0, 0, 0, cvec[3]]])) and in_k(mix) and not zero(eP[3] * mix - mix * eP[3]))

# normalized trace pairing and the convention
pair = sp.Matrix(4, 4, lambda i, j: -(eP[i] * eP[j]).trace())
T = [I * Z for Z in Zbasis[:3]]; Yp = I * Zbasis[3]; Qp = T[2] + Yp
check("W1-5", "normalized trace pairing <X,Y> = -tr_{R^8}(XY) is orthonormal on (eps_1, eps_2, eps_3, eps_B) (positive definite); Hermitian T_a = i eps_a = sigma_a/2, Y_P = i eps_B = I/2, and Q = T3 + Y = diag(1,0) on P (the W-0 convention Y_phi = 1/2)",
      pair == sp.eye(4) and all(zero(T[a] - sig[a] / 2) for a in range(3)) and zero(Yp - sp.eye(2) / 2) and zero(Qp - sp.diag(1, 0)))

# separate metric offices
x0 = sp.symbols("r0:4"); X0 = sp.Matrix(2, 2, x0)
A0, _ = sp.linear_eq_to_matrix(list(X0.T * G + G * X0) + list(X0.T * C2 + C2 * X0), x0); k0 = A0.nullspace()
K0 = sp.zeros(8, 8); K0[:2, :2] = sp.Matrix(2, 2, list(k0[0])) if k0 else sp.zeros(2, 2)
check("W1-6", "metric offices stay separate: c_W(P) has zero root block, commutes with the so(1,1) generator, and carries the positive-definite compact trace pairing, while -tr is negative on so(1,1) (Lorentzian G office, not mapped)",
      len(k0) == 1 and in_k(K0) and all(zero(K0 * m - m * K0) for m in eP) and sp.simplify(-(K0 * K0).trace()) < 0 and pair.is_positive_definite)

# ---------------------------------------------------------------- complexification and the coordinate map into (W+, W-, Z, A)
w1, w2, w3, b = sp.symbols("w1 w2 w3 b")
N = sp.Matrix([[1, -I, 0, 0], [1, I, 0, 0], [0, 0, c_w, -s_w], [0, 0, s_w, c_w]])
N[:2, :] = N[:2, :] / sp.sqrt(2)
r_neutral = sp.Matrix([[c_w, -s_w], [s_w, c_w]])                   # W-0 R_W
Nd = N.H
check("W1-7", "N: (w1,w2,w3,b) -> (W+, W-, Z, A) with W+- = (w1 -+ i w2)/sqrt2 and the W-0 R_W on (w3, b) is an exact complex-unitary isomorphism (N N^dagger = I)",
      zero(N * Nd - sp.eye(4)) and zero(N[2:, 2:] - r_neutral) and sp.simplify(N.det()) != 0)

Wp, Wm, Zs, As = sp.symbols("Wp Wm Z A")
wv = sp.simplify(N.inv() * sp.Matrix([Wp, Wm, Zs, As]))
Qf = v**2 / 8 * (g**2 * (w1**2 + w2**2) + (g * w3 - gp * b) ** 2)     # W-0 v0.2 vacuum form (restated, not re-derived)
Qn = sp.simplify(Qf.subs({w1: wv[0], w2: wv[1], w3: wv[2], b: wv[3]}))
m_w, m_z = g * v / 2, v * n / 2
check("W1-8", "composite: the W-0 vacuum quadratic form pulled back through N is diagonal in (W+, W-, Z, A): m_W^2 W+ W- + (1/2) m_Z^2 Z^2 + 0*A^2",
      zero(Qn - (m_w**2 * Wp * Wm + m_z**2 * Zs**2 / 2)) and zero(sp.diff(Qn, As)))

# ---------------------------------------------------------------- non-uniqueness of the plane (selection OPEN)
PB2 = (1, 3); eP2 = [embed(Z, PB2) for Z in Zbasis]
span_dim = sp.Matrix([list(m) for m in eP + eP2]).rank(); inter = 8 - span_dim
S = sp.eye(8)
for i in range(4, 6): S[i, i] = 0
for i in range(6, 8): S[i, i] = 0
S[4, 6] = S[5, 7] = S[6, 4] = S[7, 5] = 1                          # swap transverse blocks 2 <-> 3
check("W1-9", "plane non-uniqueness: P' (blocks 1,3) gives a distinct subalgebra c_W(P') (intersection with c_W(P) has dim 1), conjugate to c_W(P) by the block swap S in K, with iota_{P'} = Ad_S iota_P (equivalently alpha_{P'} = alpha_P Ad_S^{-1}). The selection of P is OPEN (shared with T1)",
      all(in_k(m) for m in eP2) and inter == 1 and zero(S.T * ETA * S - ETA) and zero(S.T * CH * S - CH)
      and all(zero(S * eP[i] * S.inv() - eP2[i]) for i in range(4)))

# ---------------------------------------------------------------- exact failure witnesses
flip = [-eP[0], eP[1], eP[2], eP[3]]
check("N1", "REJECTED as expected: eps_1 -> -eps_1 (others fixed) is not a homomorphism: [flip e1, e2] = -e3 but flip(e3) = +e3",
      not zero(flip[0] * flip[1] - flip[1] * flip[0] - flip[2]))
bad_central = [eP[0], eP[1], eP[2], eP[2]]
check("N2", "REJECTED as expected: eps_B -> iota(eps_3) breaks the central line ([iota(eps_B), iota(eps_1)] != 0) and injectivity",
      not zero(bad_central[3] * bad_central[0] - bad_central[0] * bad_central[3]) and sp.Matrix([list(m) for m in bad_central]).rank() < 4)
def killing(m, structure):                                           # structure(i, j) = coordinates of [b_i, b_j]
    ad = []
    for X in range(m):
        cols = [structure(X, Y) for Y in range(m)]; ad.append(sp.Matrix(m, m, lambda r, c: cols[c][r]))
    return sp.Matrix(m, m, lambda i, j: (ad[i] * ad[j]).trace())
Ksu = killing(3, lambda X, Y: [beta[k, pairs.index((X, Y))] if X < Y else (-beta[k, pairs.index((Y, X))] if Y < X else 0) for k in range(3)])
H2 = sp.Matrix([[1, 0], [0, -1]]); E2 = sp.Matrix([[0, 1], [0, 0]]); F2 = sp.Matrix([[0, 0], [1, 0]]); sl = [H2, E2, F2]
def coords_sl(M): return [M[0, 0], M[0, 1], M[1, 0]]
Ksl = killing(3, lambda X, Y: coords_sl(sl[X] * sl[Y] - sl[Y] * sl[X]))
sig_of = lambda M: tuple(sum(1 for e in M.eigenvals(multiple=True) if (e > 0) == s and e != 0) for s in (True, False))
check("N3", "REJECTED as expected: the real 2x2 root-type carrier sl(2,R) (+) R has Killing signature (2,1) on its semisimple part; su(2) has (0,3): no isomorphism (real-form adapter would be a separate declaration)",
      sig_of(Ksl) == (2, 1) and sig_of(Ksu) == (0, 3))
L1 = embed(sp.Matrix([[I]]), (1,)); dimL = 1; dimU3 = trans_dim
check("N4", "REJECTED as expected: dimension witnesses: a complex line gives u(1), dim 1; the whole u(3) has dim 9; neither is isomorphic to su(2) (+) u(1), dim 4",
      in_k(L1) and dimL != 4 and dimU3 != 4)
N_bad = sp.Matrix([[1, -I, 0, 0], [1, I, 0, 0], [0, 0, c_w, -s_w], [0, 0, s_w, c_w]])
check("N5", "REJECTED as expected: W+- = w1 -+ i w2 without the 1/sqrt2 is not unitary (N N^dagger != I)", not zero(N_bad * N_bad.H - sp.eye(4)))
N_wrong = sp.Matrix(N); N_wrong[2:, 2:] = sp.Matrix([[c_w, s_w], [-s_w, c_w]])
Qw = sp.simplify(Qf.subs(dict(zip((w1, w2, w3, b), sp.simplify(N_wrong.inv() * sp.Matrix([Wp, Wm, Zs, As]))))))
check("N6", "REJECTED as expected: the opposite-sign neutral rotation leaves a mass term on A or a Z-A cross term after pull-back",
      not zero(sp.diff(Qw, As)) )

print()
print("BOUNDARY: adapter verification.  Carrier c_W(P) = u(P) (+) 0 in u(3) in k (real dim 4), P a supplied transverse complex 2-plane;")
print("  iota_P: su(2)_L (+) u(1)_Y -> c_W(P) exact (bracket, central line, normalized trace pairing); alpha_P = iota_P^{-1}; complexified coordinate map into (W+,W-,Z,A) exact.")
print("  supplied: P (selection OPEN, shared with T1), g, gprime, v symbolic; convention Q = T3 + Y, Y_phi = 1/2.")
print("  held: identification of P with the Higgs doublet or of any carrier element with a particle, numerical theta_W or mass, empirical comparison, prediction;")
print("        Z7-su(3) route (embedding selection OPEN); real-form adapter for the Lorentzian G carrier.")
print(f"checks: {len(checks)}/{len(checks)} satisfied")
print("source SHA-256:", hashlib.sha256(open(__file__, "rb").read()).hexdigest())
print("OVERALL: PASS")
