# W-1 · Carrier adapter contract · v0.2

Supersedes v0.1 (preserved). Delta: map direction stated explicitly (ι_P with α_P = ι_P⁻¹); W1-9 conjugacy line; canonical packet filenames. No algebra altered, no physical claim strengthened.

**Entry:** W-1, carrier adapter c_W(P) → span(W⁺,W⁻,Z,A).
**Status:** adapter verification, exact. Not a particle identification, comparison, or prediction.
**Depends on:** W-0 v0.2 (contract `c8f03b360cef3700f4c9c2d57711692b0bdab8c8ec93b2f8d3ce42da1449c7ec`, verifier `8e090c1cd25dc455f624f7029b66b794f250151f0de3228f5eaeadd4e78d1a8e`); 05a SD.0, SD.9–SD.10 via F5-L1-1 v0.1 (`8378c686af0598fc197f3a78a9959102e9ed10693e3266c60e9b9cd61efb53d1`, L1-0).

## 1 · Declared carrier
- **Ambient:** K = Stab(η̂,Ĉ) ⊂ GL(8,ℝ), η̂ = G⊕I₂⊕I₂⊕I₂, Ĉ = C⊕C⊕C⊕C. 𝔨 ≅ 𝔰𝔬(1,1) ⊕ 𝔲(3), dim_ℝ 𝔨 = 10 (1 + 9). The four-dimensional object is the chosen 𝔲(2) subcarrier, not 𝔨.
- **Complex structure:** J = Ĉ on the transverse ℝ⁶ (indices 2–7), J² = −1, ℂ³ ≅ ℝ⁶, 𝔲(3) = {X : Xᵀ = −X, [X,J] = 0}.
- **Plane:** P ⊂ ℂ³ a transverse complex 2-plane. Declared instance: blocks 1,2 (indices 2–5); P^⊥ = block 3 (indices 6,7).
- **Carrier:** 𝔠_W(P) := 𝔲(P) ⊕ 0_{P^⊥} ⊂ 𝔲(3) ⊂ 𝔨, dim_ℝ 4. Field ℝ (complexification ℂ). Representation: defining rep on P ≅ ℂ² (ℝ⁴), zero on the root block and on P^⊥.
- **Basis:** ε_a ↦ −(i/2)σ_a (three traceless generators on P), ε_B ↦ −(i/2)I_P (central iI_P up to the declared factor).

## 2 · Map
- **ι_P:** 𝔰𝔲(2)_L ⊕ 𝔲(1)_Y → 𝔠_W(P), ε_i ↦ e_{P,i}, exact isomorphism (this is the map W1-3 checks): every bracket equals the W-0 β_EW structure constants. **α_P := ι_P⁻¹:** 𝔠_W(P) → 𝔰𝔲(2)_L ⊕ 𝔲(1)_Y; central line ℝ·ε_B ↦ 𝔲(1)_Y; normalized trace pairing ⟨X,Y⟩ = −tr_{ℝ⁸}(XY) orthonormal on (ε₁,ε₂,ε₃,ε_B). Hermitian form: T_a = iε_a = σ_a/2, Y_P = iε_B = ½I, Q = T₃+Y = diag(1,0).
- **Coordinate map:** (w¹,w²,w³,b) ↦ (W⁺,W⁻,Z,A), W^± = (w¹ ∓ i w²)/√2, (Z,A) = R_W(w³,b) with the W-0 R_W. Complex-unitary, exact; g,g′ symbolic.
- **Composite:** the W-0 vacuum quadratic form pulled back through the map equals m_W² W⁺W⁻ + ½m_Z² Z² + 0·A² (m_W = gv/2, m_Z = v√(g²+g′²)/2), symbolic in g,g′,v.

## 3 · Preserved structure and exact failure witnesses
| Preserved | Witness that fails |
|---|---|
| bracket | ε₁↦−ε₁ is not a homomorphism (N1) |
| central line | ε_B↦ι(ε₃) is not central, not injective (N2) |
| compact real form | sl(2,ℝ)⊕ℝ carrier: Killing signature (2,1) vs (0,3) (N3) |
| dimension 4 | complex line (dim 1), full 𝔲(3) (dim 9) (N4) |
| unitary normalization | W^± without 1/√2 (N5) |
| diagonalization | opposite-sign neutral rotation (N6) |

## 4 · Offices kept separate
𝔠_W(P) has zero root block and commutes with the 𝔰𝔬(1,1) generator. It carries the positive-definite compact trace pairing. The Lorentzian G office is not mapped; −tr is negative on 𝔰𝔬(1,1). ε_B is central in 𝔠_W(P) only, not in 𝔲(3) (a P↔P^⊥ rotation in 𝔨 fails to commute with it).

## 5 · Open and supplied
- **Plane P is a supplied choice, shared with T1. Its selection is OPEN.** Witness (W1-9): the plane P′ = blocks (1,3) gives a distinct subalgebra (intersection with 𝔠_W(P) has dim 1), conjugate to it by the block swap S ∈ K, ι_{P′} = Ad_S ι_P (equivalently α_{P′} = α_P Ad_S⁻¹).
- **Supplied:** g, g′, v (symbolic); convention Q = T₃ + Y, Y_φ = ½ (W-0).
- **Held:** identification of P with the Higgs doublet or of any carrier element with a particle; numerical θ_W or mass; empirical comparison; prediction (forced-number certificate); Z₇–𝔰𝔲(3) route (embedding selection OPEN, later strengthening); real-form adapter for the Lorentzian G carrier.
- **Packaging residual:** the three W-0 cited source files (Electroweak Seam, Two-Operator Certificate, Empirical Input Register) are not bundled; the executable receipt is self-contained.

## 6 · Executable
`verify_w1_carrier_adapter_v0_2.py`, SHA-256 `6211cd25a771fcc06f682e2846c68bf088a95c712510b41d2d3ae6cfd4e6e634`. `python3 -I`, exact SymPy, no floats. 15/15 (W1-1…W1-9, N1…N6).

## 7 · Packet
Canonical filenames: W1_CARRIER_ADAPTER_CONTRACT_v0_2.md, verify_w1_carrier_adapter_v0_2.py, W1_CARRIER_ADAPTER_RECEIPT_v0_2.txt, SHA256SUMS. `sha256sum --check SHA256SUMS` is run in the directory holding exactly these names (also shipped as W1_v0_2_packet.zip). v0.1 files and manifest are preserved unchanged.
