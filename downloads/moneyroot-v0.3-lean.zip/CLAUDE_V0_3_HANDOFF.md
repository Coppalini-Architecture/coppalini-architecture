# MoneyRoot v0.3 — Lean handoff

## Purpose

v0.3 preserves the certified v0.2 kernel unchanged except for the version header and appends T7. T7 does **not** claim a new theorem of set theory. It machine-types the stop line identified in the v0.2 semantic review: `SupplementSufficient` plus the information preorder alone do not supply a canonical least supplement.

The new finite schema uses a three-state carrier and Bool-valued reads to prove a stronger constructive statement: two individually sufficient supplements can be incomparable and have no sufficient common lower bound. Therefore even restricting all supplements to one fixed codomain (`Bool`) does not force a least sufficient supplement.

## Canonical source

- `MoneyRoot_v0_3.lean`
- expected SHA-256: `4f2a8bf0d2754e9ceed87b339abbb678674355344cbc5200e28b91d9a0312c0c`
- pinned toolchain: `leanprover/lean4:v4.33.0`
- `lean-toolchain` expected SHA-256: `302cd63c54178885b89e669f33b38f12f4dd7ae7e5cac537b3203e3768d8fb2b`

## Pre-run status

- v0.2 theorem kernel: `LEAN_ELABORATION = CERTIFIED` by attached receipt.
- v0.3 appended T7 source: `SOURCE_READY`.
- v0.3 Lean elaboration: `OPEN` until this exact source is run.
- economic/legal adapters: unchanged; still OPEN / CONDITIONAL.

## Requested run discipline

1. Verify `HANDOFF_MANIFEST.sha256` before running Lean.
2. Run the byte-identical source under the pinned Lean 4.33.0 toolchain.
3. Preserve the first diagnostic exactly if elaboration fails. Do not patch before reporting it.
4. On success record exact Lean version, command, exit code, stdout/stderr, pre/post source hash, and grep for `sorry`, `admit`, and user-written `axiom`.
5. Run `#print axioms` on the new T7 theorems using a scratch copy only.

## Semantic review requested

Please independently check these points rather than accepting comments or names:

1. `LeastAllowedSupplement` has the correct order direction: a least supplement `S` must satisfy `ReadNoMoreInformative S T` for every allowed sufficient `T`.
2. `leftSupp` and `rightSupp` are each genuinely sufficient relative to `base` for `decision`.
3. The two reads are genuinely incomparable under `ReadNoMoreInformative`.
4. `no_common_sufficient_lower_bound` proves the intended stronger fact. In particular, verify the chain:
   - `U ≤info leftSupp` forces `U a = U c`;
   - `U ≤info rightSupp` forces `U b = U c`;
   - transitivity of equality forces `U a = U b`;
   - since `base a = base b` but `decision a ≠ decision b`, such a `U` cannot be sufficient.
5. `T7_no_least_bool_sufficient_supplement` follows from the stronger common-lower-bound obstruction and does not merely assert nonexistence.
6. Check whether the finite proof accidentally relies on classical choice, excluded middle, additional imports, or stronger structure than the source declares.
7. Check the wording boundary: T7 proves nonexistence of a least supplement in **this unrestricted Bool-valued candidate class**. It does not prove that every economically meaningful candidate class lacks a least element.
8. If you can strengthen or simplify the theorem without changing its jurisdiction, flag that separately rather than silently rewriting the source.

## Intended status if clean

If the exact source elaborates with no sorry/admit/user axiom and the semantic checks hold, the narrow status is:

`MoneyRoot v0.3 / T7 NO-LEAST-SUPPLEMENT COUNTEREXAMPLE = CERTIFIED`

This certifies only the pure formal counterexample. It does not select an admissible policy metric or establish empirical facts about money.
