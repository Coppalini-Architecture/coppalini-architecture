## Reference-copy correction · 29 October 2026

Current UI labels call the first two B7 eigenvectors matrix modes 0 and 1. The phrase “first excited state” in retained historical source is a projected-matrix label, not an identification with the measured bound 1s2s ¹S level. Ground energy differs from the matching fixed-nucleus nonrelativistic reference by 0.0125186 eV (0.0158434%); the B7 gap is 36.3826 eV versus the NIST spectroscopic singlet gap of 20.6158 eV. Native and laboratory mathematical source identities remain unchanged. Current visible scopes state these distinctions directly.

# Laboratory 0.3 · current implementation audit

The native Engine 0.2 source identity is unchanged. The Laboratory 0.3 preparation layer is separately hashed and replayed. All inherited calculation extracts are unchanged. Current source/bundle checks, native checks, Hydrogen display checks and laboratory checks are in `receipts/`.

Water's specialized basis is algebraically the same normalized m=0 circular Coulomb basis; the general Laguerre degree is zero in all four channels. Test points cover the construction interval and coordinate range. Spatial current uses centered finite differences at h=10⁻⁴; vector length is a display choice. Signed interference is 2 Re(L R*). Retained channel/detail reconstruction checks run on the native state.

Helium adds the preparation √(1−p)|0⟩ + √p exp(−i(ΔEt+φ))|1⟩. Its coefficient norm is one; expected energy is (1−p)E₀+pE₁. The global ground-state phase is restored in the phase-color display. Eigenvalues, correlated basis and symmetric singlet sector are retained. Correlation compares against exp(−2s)/π. Separation, cusp and reduced-density plots are explicitly ground-state diagnostics and do not follow the live superposition. The supplied upstream 45/45 suite has not been independently rebuilt here.

Eye adds a phase bias inside the two-beam cosine and independent cage rate in its sampled normals. Radius, Cauchy dispersion and source throughput coherence retain their source meanings; coherence remains a source throughput parameter, not a newly asserted visibility law. Zero added phase and default cage reproduce source spectra. Display exposure is applied after the spectral RGB read. Sphere scattering remains a first-order two-beam approximation.

Watchworks adds cage phase offset to its declared orientation-error harmonics and their analytic running mean. At zero rate, the error stays at its chosen angle; the rotating long-run mean statement is not applied to a stationary cage. This demonstrator establishes no manufactured-watch performance.

Temperament and the independently tunable SO(2) connection are separate, explicitly labeled comparison experiments. Their formulas and source scope appear in README.md. The pitch wheel is closed using one visible closing step; open pure fifths are not silently identified with twelve equal-temperament classes. A specifically named Riemann tuning implementation awaits source specification.

All 43 reads use discrete immediate selection. No guide, crossfade, or blended-coordinate animation executes. Numerical field work and rendering share the UI thread; 30 Hz is a scheduling target, not a universal guarantee. Actual last-draw timing is visible. Fixed geometry and reusable buffers reduce repeated work. Browser checks record observed control-to-draw delay on the tested browser. Dense numerical ground-state diagnostics are cached after first calculation.

## Retained native Engine 0.2 audit (historical)

The material below records the prior edition. Its guided presentation and 32-read statements are historical; Laboratory 0.3 supersedes them as described above.

# Native Engine 0.2 · implementation assessment

Release: 2026-10-29 · automatic lift cadence edition. Scope: standalone Clear_Onyx instrument; no website integration or deployment.

## Computational boundary

The session records integer reference ticks (120,000 per beat), independent native origins and parameters, a shared probe, an exact comparison frame, the selected reader and an ordered event history. Each native adapter computes a state at the current reference occurrence through its declared clock conversion. Unselected carriers continue to have defined evolving states. Rendering samples those states and maps them to a canvas. It does not supply a replacement evolution law.

Playback commits 1/12-beat increments and renders an analytic preview between commits. Hold and save flush residual integer ticks. Backgrounding the document holds playback. Each scheduling callback admits at most 0.25 seconds after a gap, avoiding a long catch-up burst. The default half-pace opening follows Hydrogen, Helium, Water, Doublet, Periodic / pitch, Watchworks, Orbit and Eye, with four reference beats per chapter. Each chapter first admits 2.5 beats of native observation, followed where applicable by a one-beat reader transition. The finite guide settles at the Eye writer; native playback continues. The golden arrow reads presentation progress; the turn/quarter counter reads continuing reference occurrence. Previous/Next and direct choices end the guide, while Pause/Play retain its current position. Workings exposes the advanced instrument and ends the guide. Reduced-motion preference opens at rest; explicit Play and Follow lift remain available. Reduced-motion preferences remove animated transitions.

The exact root bench acts on comparison coordinates. Chronological operator application is left action: selecting Q, then C₁, then H gives H C₁ Q = Lₐₓ. The exact matrix and normal form in the basis (I,Q,Ω,G) are retained. The bench distinguishes Euclidean orthogonal operators from the other declared form relations and reports numerical comparison norms separately. No comparison operation changes native preparation, energy or time.

## Native ownership and limits

**Hydrogen.** Retains the supplied analytic circular Coulomb kernel and circular-state ladder, including mirror handedness, energy ratios and probability-current read. One reference beat is the source 1s–2p relative beat. Relative frequencies (0,1,32/27,5/4) explain the separate 1,27,4 and108 beat returns. No fine-structure, external-field or many-electron additions are implied.

**Helium.** Retains the supplied α=2 seven-function Hylleraas basis, coefficient solve and diagnostics, including the physical `/π` amplitude normalization. E₀=−2.903264326982932 and E₁=−1.5662272375668875 Hartree. The ground-relative gauge removes an unobservable common phase; one reference beat is 2π/(E₁−E₀). The configuration field is a declared collinear section of a correlated two-electron singlet, not two independent electron clouds. The new release verifies normalization and orthogonality using the retained quadrature; it does not independently rebuild the generalized eigenproblem. Its eigen-residual and overlap-residual metadata remain supplied results.

**Water construction.** Carries forward the v0.1 eight-channel normalized coefficient construction using analytic m=0 Hydrogen orbitals, a continuous channel split, and an endpoint angle104.52°/bond length0.9572Å. A continuous orthogonal coordinate path reaches two collective coordinates plus six retained detail coordinates. The full local channel vector is reconstructible from those coordinates. Coefficient norm and local channel norm are typed separately from an integrated spatial wavefunction norm. This is a declared geometric/channel construction, not a molecular-water Hamiltonian or prediction of water bonding.

**Doublet / Higgs scope.** Reads the live Water collective or a declared manual doublet. It exposes the radius, projective direction, common central phase and V=λ(ρ²−ρ₀²)². The zero vector has zero radius and unavailable projective direction; it is never assigned an arbitrary direction. This geometry and radial potential do not by themselves implement Standard Model field equations, gauge dynamics or a measured Higgs mass.

**Periodic / pitch.** Retains an integer lift k with separate readers N=4k mod7 and p=7k mod12, with octave floor(7k/12). The descriptor source uses the Be…Ne 2p occupancy sequence and its supplied terms; it is not a full periodic-table electronic-structure solver. Reflection R:k↦5−k induces N↦6−N mod7. Descriptor return7, pitch-class return12 and joint reader return84 remain distinct; the integer lift continues. Pitch classes use the declared A reference. There is no audio synthesis in this release.

**Watchworks.** Uses four releases per beat, a continuing lift, r₄/r₁₃₇ and exact CRT reconstruction modulo548 (inverse4 mod137=103). The cage defaults to1/8 turn per beat. Retains source error 0.04+0.34cosθ+0.15cos2θ+0.08sin3θ and its analytic cage mean. This is ideal kinematics and an illustrative error function, not a measured clock or a performance claim.

**Mechanical Eye.** Retains the original sphere-normal, Cauchy-index, Fresnel/two-beam, analytic color-matching and display-transfer functions. The spectrum has31 wavelengths400…700nm. The137 addresses are a sampling choice, not a derivation of a physical constant. One reference beat releases four addresses. Cage phase has its own16-beat period:137 beats returns the address reader; the full joint address/cage return is2192 beats. Spectrum, linear color, display color, eight means and28 seams are separately exposed. Display tone mapping is a rendering operation; compressed channels do not reconstruct a discarded full spectrum.

**Orbit.** New planar bound two-body implementation, μ=1 in declared units, a∈[0.5,3], e∈[0,0.85]. One reference beat is0.5 native time units. It solves E−e sinE=M using a safeguarded Newton/bisection iteration and computes position/velocity analytically. Energy, angular momentum, swept area and equation residual are inspectable. This is not a measured solar-system ephemeris. Primary mathematical reference: NASA/JPL NAIF `prop2b_c`, https://naif.jpl.nasa.gov/pub/naif/toolkit_docs/C/cspice/prop2b_c.html . That routine uses universal variables; this implementation uses the bounded elliptic branch and does not call SPICE.

## Retained lineage

The root and m=0 orbital modules are copied byte for byte from the retained laboratory source release. The previous One Carrier engine is byte-retained for strict migration. The original Hydrogen viewer supplies two exact script extracts. The Helium viewer supplies the unchanged precomputed solve and contiguous pure mathematical block, wrapped for a headless namespace. The Eye viewer supplies its unchanged contiguous spectral block, wrapped with the source constants. Complete reference viewers are included. Watch and atomic-music readers adapt their stated laws while separating their native carrier from display and scheduling.

The return/lift typing also follows the supplied *Return, Residue, and Transport in Central Extensions — Algebraic Recursion and Holonomy Lift*, Anthony Vito Coppa,20February2026 canonical version. Its conditional statements about connected abelian covers remain under their stated hypotheses. No claim is added that the common session engine derives each native physical law.

## Validation

`tests/check-session.cjs`:34 passing check groups. Coverage includes exact inherited identities and normal-form reconstruction; continuing clocks and selected origins; upstream Hydrogen agreement; Helium exchange, normalization and orthogonality; reversible Water collective/detail coordinates; zero-doublet handling; distinct quotient returns and reflected/negative lifts; all548 CRT addresses; watch analytic/integrated mean; Eye sampling/seams; Kepler energy, angular momentum, derivative and force consistency; replay, migration, source identities and tamper/parameter rejection.

Retained Helium quadrature (order40, s≤15) produced ground norm1.0000000000000193, excited norm1.0000000000001232 and cross overlap1.5765×10⁻¹⁴. Worst sampled Kepler equation residual was7.21645×10⁻¹⁶. These numerical checks validate the implementation and declared finite test set; they do not constitute experimental verification of every model.

Browser checks exercised all32 readings, carrier changes during playback, automatic traversal, exact root composition, periodic origin, zero-doublet handling, actual v0.1 migration and v0.2 replay. Import through a local JSON file restored the saved native beat and reported successful replay. Browser console checks found no application errors. A375-pixel content width matched its375-pixel scroll width; narrow-preview keyboard carrier selection reached the Eye with passing declared checks. Managed nested-frame pointer automation did not activate the narrow preview controls, while keyboard activation did; direct-tab controls were exercised normally. The Blob download was not independently captured by automation; the visible JSON/copy path and file import were verified. Tests were in the managed Chromium browser, not an exhaustive browser/device matrix.

Session import is bounded to24MB and100,000 events, validates strict command contracts and compares the replayed final state before replacement. The input is parsed as JSON and never evaluated as code. No network API or persistent telemetry is used by the delivered file. Source hashes provide implementation consistency, not provenance authentication against a malicious author. Resource and integer-size limits remain practical implementation constraints.

## Cadence edition verification

The computational source identity remains the same nine modules as the original0.2 delivery. Only UI scheduling, markup, styles and the separately identified `src/cadence.js` changed. The source audit verifies compatibility with the included browser-exported0.2 example. Six new cadence check groups verify the eight distinct chapters, Hydrogen start/Eye endpoint, observation interval, bounded monotone arrow, finite nonwrapping arrival and invalid-age rejection. The twenty-one source/bundle checks include unchanged native extracts and offline bundling. Native tests remain34 passing groups.

New browser checks cover default autoplay at half pace, hidden workings, automatic native handoff, guide-preserving pause, manual Next taking over while paused, Workings and its checks, and the finite Eye arrival. The golden line is a display of the guided passage; its diagonal is not a new dynamical equation or a claim of physical transformation between carriers. The recurring phase and continuing occurrence remain separately readable. Canonical orientation for this update: *Minimum mirror coherence*, pages1–3, distinguishing carried return difference from compatibility defects between descriptions.

## Hydrogen lab restoration /29October2026

The first Hydrogen display is now the signed density difference ρ₊−ρ₋ between equal-coefficient opposite azimuthal preparations. Positive difference uses the original48° orange hue and negative difference the248° blue hue, with the original fixed logarithmic reader and exact retained OKLCH→RGB conversion. The source's quadratic radial map r/aH=32u² restores the extended field. Circles and ray-return position are display coordinates; probability current is pushed forward through that same radial map.

The retained native kernels, energies, coefficients and clock mapping remain unchanged. Added UI code is identified separately as `src/hydrogen-display.js`. All34 native,6 cadence and7 restored-display check groups pass, alongside22 source/bundle checks. The previous0.2 receipt's computational identity still matches. Hydrogen's former amplitudes reading is now the signed mirror reading; amplitudes remain inspectable in the advanced state dialog.

Browser inspection exercised all four readings, independent3d/4f preparation switches, recurrence summaries, playback selection and keyboard scrubbing. Removing both optional states gave a1-beat/0.41fs recurrence; restoring both gave108beats/43.79fs. At375px the content and scroll widths match. The plot legend was moved into HTML to keep sign/color meaning legible at narrow widths. Controls in the managed narrow iframe were operated through keyboard input, retaining the previous automation boundary.

Language and layout now foreground the selected physical model, what to try, model assumptions, and measurements. General session/root explanations remain in expandable technical notes. No new physical interpretation or experimentally measured performance claim is introduced by this presentation change.
