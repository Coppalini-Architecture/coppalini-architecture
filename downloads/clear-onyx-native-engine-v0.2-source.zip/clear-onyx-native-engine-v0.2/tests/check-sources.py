"""Verify retained mathematical extracts and the self-contained bundle."""
from pathlib import Path
import hashlib, json, re

R = Path(__file__).resolve().parents[1]
results = []
def check(name, condition):
    assert condition, name
    results.append(name)
    print('PASS', name)

hydrogen = (R/'references/original-hydrogen.html').read_text()
scripts = re.findall(r'<script(?:\s[^>]*)?>([\s\S]*?)</script>', hydrogen)
for i, name in enumerate(['hydrogen-kernel-v01.js','hydrogen-ladder-v02.js']):
    retained = (R/'inherited/src'/name).read_text()
    check(name+' exact upstream script', retained == scripts[i])

helium = (R/'references/original-helium.html').read_text()
block = helium[helium.index('  const ALPHA ='):helium.index('  const HE_PLUS =')]
check('Helium contiguous mathematical block unchanged', block in (R/'inherited/src/helium-reads-v01.js').read_text())
data = re.search(r'<script[^>]*id="precomputed-data"[^>]*>([\s\S]*?)</script>',helium).group(1)
solve = (R/'inherited/src/helium-solve.js').read_text().removeprefix('globalThis.HeliumSolve = ').rstrip().removesuffix(';')
check('Helium supplied solve unchanged',json.loads(data)==json.loads(solve))

eye = (R/'references/original-mechanical-eye.html').read_text()
start = eye.index('      const WAVELENGTHS_NM =')
end = eye.index('\n      }',eye.index('      function spectrumDistance',start))+len('\n      }')
check('Eye contiguous spectral block unchanged',eye[start:end] in (R/'inherited/src/eye-spectrum-v04.js').read_text())

identities = json.loads((R/'source-identities.json').read_text())
for name, expected in identities.items():
    check(name+' source identity', hashlib.sha256((R/name).read_bytes()).hexdigest()==expected)

example = json.loads((R/'examples-session.json').read_text())
computational = {n:h for n,h in identities.items() if n not in ['src/app.js','src/renderers.js','src/cadence.js','src/hydrogen-display.js','src/laboratory.js']}
check('prior browser receipt keeps the identical computational identity', example['sources']['sha256']==computational)

html = (R/'clear-onyx-native-engine-v0.2.html').read_text()
check('delivered and dist HTML identical',html==(R/'dist/index.html').read_text())
check('no external script or stylesheet',not re.search(r'<script\s+src=|<link[^>]+rel="stylesheet"',html))
check('no runtime network API',not re.search(r'\bfetch\s*\(|\bXMLHttpRequest\b|\bWebSocket\b',html))
receipt = {'passed':len(results),'checks':results}
(R/'receipts/source-checks.json').write_text(json.dumps(receipt,indent=2)+'\n')
