'use strict';
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const root=path.resolve(__dirname,'..'),x={};vm.createContext(x);vm.runInContext(fs.readFileSync(path.join(root,'src/cadence.js'),'utf8'),x);
const C=x.CarrierCadence,passed=[];function test(name,fn){fn();passed.push(name);console.log('PASS '+name);}
test('passage starts with Hydrogen and finishes at the Eye',()=>{assert.equal(C.at(0).id,'hydrogen');assert.equal(C.at(C.END).id,'eye');assert.equal(C.at(C.END).done,true);});
test('every native carrier occurs once in the directed passage',()=>{assert.equal(new Set(C.ROUTE).size,8);C.ROUTE.forEach((id,i)=>assert.equal(C.at(i*C.DWELL).id,id));});
test('each chapter admits a read interval before its scope moves',()=>{for(let i=0;i<7;i++){assert.equal(C.at(i*C.DWELL+2.49).view,i===0?1/3:0);assert.ok(C.at(i*C.DWELL+3.5).view>=0);}});
test('arrival settles at the Eye writer and never wraps or resets',()=>{for(const t of [C.END,C.END+4,1e6]){assert.equal(C.at(t).id,'eye');assert.equal(C.at(t).view,0);assert.equal(C.at(t).progress,1);}});
test('golden path is continuous, bounded and monotone',()=>{let previous=0;for(let i=0;i<=3000;i++){const r=C.at(i/100);assert.ok(r.progress>=previous&&r.progress<=1);assert.ok(r.view>=0&&r.view<=1);previous=r.progress;}});
test('invalid schedule input refuses and negative age stays at origin',()=>{assert.throws(()=>C.at(NaN));assert.throws(()=>C.at(Infinity));assert.equal(C.at(-1).slot,0);});
fs.writeFileSync(path.join(root,'receipts/cadence-checks.json'),JSON.stringify({passed:passed.length,checks:passed},null,2)+'\n');
