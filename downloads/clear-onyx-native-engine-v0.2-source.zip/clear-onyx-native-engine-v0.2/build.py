from pathlib import Path
import hashlib,json,re
R=Path(__file__).resolve().parent
scripts=['inherited/src/kernel.js','inherited/src/native-orbitals.js','legacy/src/engine.js','inherited/src/hydrogen-kernel-v01.js','inherited/src/hydrogen-ladder-v02.js','inherited/src/helium-solve.js','inherited/src/helium-reads-v01.js','inherited/src/eye-spectrum-v04.js','src/session.js','src/laboratory.js','src/hydrogen-display.js','src/renderers.js','src/app.js']
hashes={p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in scripts}
old={'inherited/src/kernel.js':hashes['inherited/src/kernel.js'],'inherited/src/native-orbitals.js':hashes['inherited/src/native-orbitals.js'],'src/engine.js':hashes['legacy/src/engine.js']}
(R/'src/provenance.js').write_text('globalThis.OneCarrierSourceHashes=Object.freeze('+json.dumps(old)+');\nglobalThis.CarrierSourceHashes=Object.freeze('+json.dumps({p:h for p,h in hashes.items() if p not in ['src/laboratory.js','src/hydrogen-display.js','src/renderers.js','src/app.js']})+');\n'+'globalThis.LabSourceHashes=Object.freeze('+json.dumps({'src/laboratory.js':hashes['src/laboratory.js']})+');\n')
html=(R/'index.html').read_text()
html=re.sub(r'<link rel="stylesheet" href="([^"]+)">',lambda m:'<style>\n'+(R/m[1]).read_text()+'\n</style>',html)
html=re.sub(r'<script src="([^"]+)"></script>',lambda m:'<script>\n'+(R/m[1]).read_text()+'\n</script>',html)
(R/'dist').mkdir(exist_ok=True);(R/'dist/index.html').write_text(html)
(R/'clear-onyx-native-engine-v0.2.html').write_text(html)
(R/'source-identities.json').write_text(json.dumps(hashes,indent=2)+'\n')
print(json.dumps({'html':str(R/'clear-onyx-native-engine-v0.2.html'),'bytes':len(html.encode()),'sources':len(hashes)},indent=2))
