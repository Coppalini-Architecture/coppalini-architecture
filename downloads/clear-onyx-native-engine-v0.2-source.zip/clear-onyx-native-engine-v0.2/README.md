# Clear_Onyx · Laboratory 0.3

Eight instruments, 43 discrete views, one offline session. Open `clear-onyx-native-engine-v0.2.html` in a current browser. The filename is retained for existing links; the interface and additional preparation layer are Laboratory 0.3, over the unchanged native Engine 0.2.

Hydrogen opens in the original orange/blue mirror read. Motion starts at half pace unless reduced motion is requested. Choose a model or view directly. There is no guided tour, scene crossfade, or continuous view morph. Hiding the page pauses playback. Model controls are open initially and can be collapsed. Keyboard-accessible buttons, native selects and sliders carry all inputs.

## Instruments

- Hydrogen: density/phase, mirror difference, energies, probability current. Original display mapping and source math retained.
- Helium: joint field, correlation comparison, exchange residue, separation cut, both cusp diagnostics, reduced ground-state distributions, occupied eigenstates. Population and relative phase control the superposition of B7 matrix modes 0 and 1. Mode 1 is a projected matrix eigenvector; it is not identified with the observed first bound excited singlet. Source eigenvalues and the finite basis stay fixed.
- Water construction: density/phase, signed interference, probability current, 28 pair relations, channels, collective coordinates, doublet. One/paired-center buttons and intermediate construction remain available. This is the retained two-center Hydrogen construction, not an ab initio water calculation.
- Doublet: state geometry, components, radial potential, common phase. Live Water or manual components.
- Periodic/pitch: occupation descriptor, pitch, joint wheels, lift, temperament comparison.
- Watchworks: mechanism, encoder, lift, orientation error, temperament wheel, SO(2) connection. Cage rate and phase offset tune the declared orientation-error calculation.
- Eye: writer, sampled spectrum, channels, signed seams, temperament wheel, SO(2) connection. Radius, dispersion, throughput coherence, independent cage rate and additional optical phase bias are explicit inputs. Zero bias reproduces the source spectra.
- Orbit: trajectory, mean anomaly, specific energy, equal-area read, with eccentricity and size controls.

## Tuning definitions and scope

The pitch comparator uses fifths of `2^(7/12)`, `3/2`, or `5^(1/4)`. Its unclosed 12-step remainder is `fifth^12 / 2^7`; in cents, `1200 log2(remainder)`. Eleven selected fifths plus one explicitly located closing step `2^7/fifth^11` close to seven octaves. The Pythagorean remainder is exactly `531441/524288`. The quarter-comma definition gives `fifth^4/4 = 5/4`. The closing step is visible rather than silently equating open fifths with a closed octave wheel. These are mathematical definitions of this comparator; a specifically named Riemann tuning scheme has not been implemented without its source specification.

The connection comparator implements the family in Anthony Vito Coppa, *Independent Tunability of Local Curvature and Global Holonomy in a Source-Free SO(2) Gauge Field* (July 2026): `A = aη + b sin(u)dy`, `F = b cos(u)du∧dy`, and circle holonomy `exp(−2πa C1)`. Changing a leaves this curvature unchanged; changing b leaves the circle holonomy unchanged. This is a separate mathematical comparison, not a claim that the same two controls describe a material sphere or a manufactured watch.

The palette and exposure controls change display encoding. Complex phase/spectrum preserves the mathematical phase or spectral read. The normal-form palette is an eight-stop display color sequence; its interpolation is a viewer choice, not a measured spectrum or a verified semantic color calibration. Density/intensity removes hue from field and Eye point reads. Signed comparisons retain orange/blue so their sign remains legible. Text legends describe each selected view outside the canvas.

## Performance

Views select immediately without rendering a second scene. Water uses specialized n=1…4, l=n−1, m=0 degree-zero Laguerre formulas, checked against the retained general orbital functions. Grid preparation hoists center geometry and normalization constants out of pixel evaluation. Geometry caches are bounded and pixel buffers reused. The same native coefficients and fixed display bounds apply. The animation target is 30 draws/second; diagnostics refresh at most five times/second. Readouts disclose actual last-draw duration. This is measured local-browser behavior, not a guarantee on every device.

## Receipts and compatibility

Save holds playback and exposes JSON for download or copy. Resume verifies native source identity, native event replay and final state, then laboratory source identity, ordered laboratory settings events and final settings before replacing the active session. Laboratory events identify the native-operation count at which they occurred. Native 0.2 and original One Carrier 0.1 receipts import through the retained verifiers. Native 0.2 computational source identity remains unchanged. View positions refer to the current discrete view order; an older normalized view can select a different view while retaining its native state. Playback pace, detail and the Hydrogen fixed/return playback selector are local presentation settings.

`src/session.js` owns unchanged native calculations. `src/laboratory.js` adds declared preparations and comparison reads without replacing inherited source files. Renderer and app own display and scheduling. `src/cadence.js` and its old checks remain historical source only and are not bundled or executed.

## Rebuild and verify

```sh
python3 build.py
node tests/check-session.cjs
node tests/check-hydrogen-display.cjs
node tests/check-laboratory.cjs
python3 tests/check-sources.py
```

No third-party build dependencies. See `receipts/` for actual results and browser checks; `AUDIT.md` distinguishes retained native math, added reads and limits. Original standalone interfaces remain in `references/` and on the website under `models/source/`.

The inherited rights notice remains in `inherited/LICENSE`. These author-approved copies may be run and inspected; no new general public reuse license is assigned.

Anthony Vito Coppa / Coppalini Architecture · 2026-10-29

## Reference-copy revision · 29 October 2026

The website and instrument now distinguish exact phase/lift, address and exchange relations from energy accuracy. The unchanged B7 ground energy is −2.903264326982932 Ha, compared with −2.9037243770341195 Ha for the matching fixed-nucleus nonrelativistic benchmark: +0.000460050051 Ha = 0.0125186 eV (0.0158434%). The first two B7 modes are separated by 36.3826327 eV; NIST lists the observed 1s2s ¹S excitation at 166277.4403 cm⁻¹, or 20.6157752 eV. They are labeled matrix modes in the current UI. Canonical native and Laboratory 0.3 computational identities are unchanged; these are presentation labels. The normal-form and grayscale Hydrogen display branches also now allow their local RGB display variable to be reassigned.
