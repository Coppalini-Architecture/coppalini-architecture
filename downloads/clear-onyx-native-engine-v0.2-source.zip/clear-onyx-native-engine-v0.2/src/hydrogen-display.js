/* Original Hydrogen display mapping and OKLCH reader; native state is unchanged. */
(function(root){'use strict';
const K=root.HydrogenKernelV01,H=root.HydrogenOrbitalLadderV02,TAU=2*Math.PI,HORIZON=32;
  function linearToSrgb(value) {
    const encoded = value <= 0.0031308
      ? 12.92 * value
      : 1.055 * Math.pow(Math.max(0, value), 1 / 2.4) - 0.055;
    return Math.round(255 * Math.min(1, Math.max(0, encoded)));
  }

  function oklchToRgb(lightness, chroma, hueDegrees) {
    const hue = hueDegrees * Math.PI / 180;
    const a = chroma * Math.cos(hue);
    const b = chroma * Math.sin(hue);
    const l0 = lightness + 0.3963377774 * a + 0.2158037573 * b;
    const m0 = lightness - 0.1055613458 * a - 0.0638541728 * b;
    const s0 = lightness - 0.0894841775 * a - 1.291485548 * b;
    const l = l0 * l0 * l0;
    const m = m0 * m0 * m0;
    const s = s0 * s0 * s0;
    return [
      linearToSrgb(4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s),
      linearToSrgb(-1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s),
      linearToSrgb(-0.0041960863 * l - 0.7034186147 * m + 1.707614701 * s)
    ];
  }

function weights(active,phase){return active.map(n=>{const o=H.ORBITALS[n],angle=-o.phaseNumerator/o.phaseDenominator*phase;return {n,cos:Math.cos(angle)/Math.sqrt(active.length),sin:Math.sin(angle)/Math.sqrt(active.length)};});}
function sample(values,w,offset=0){let pr=0,pi=0,mr=0,mi=0,incoherent=0;for(const {n,cos:c,sin:s} of w){const re=values[offset+2*(n-1)],im=values[offset+2*(n-1)+1];pr+=c*re-s*im;pi+=s*re+c*im;mr+=c*re+s*im;mi+=s*re-c*im;incoherent+=(re*re+im*im)/w.length;}const plus=pr*pr+pi*pi,minus=mr*mr+mi*mi;return {pr,pi,mr,mi,plus,minus,difference:plus-minus,incoherent};}
function pixel(p,mode,handedness=1){const density=handedness===1?p.plus:p.minus,tone=Math.pow(Math.min(1,Math.log1p(1e6*density)/Math.log1p(1e6/Math.PI)),.8);let lightness,chroma,hue;
if(mode==='mirror'){const magnitude=Math.min(1,Math.log1p(1e6*Math.abs(p.difference))/Math.log1p(1e4));lightness=.075+.84*Math.max(.18*tone,magnitude);chroma=.035+.17*magnitude;hue=p.difference>=0?48:248;}
else{const den=density+p.incoherent,coherence=den>Number.MIN_VALUE?Math.min(1,Math.abs(density-p.incoherent)/den):0;lightness=.07+.86*tone;chroma=(.035+.17*coherence)*Math.min(1,tone/.08);hue=density>0?(Math.atan2(handedness===1?p.pi:p.mi,handedness===1?p.pr:p.mr)*180/Math.PI+670)%360:0;}
return [...oklchToRgb(lightness,chroma,hue),Math.round(255*Math.min(1,.16+1.08*tone))];}
function grid(size){const basis=new Float64Array(size*size*8),mask=new Uint8Array(size*size);for(let y=0;y<size;y++)for(let x=0;x<size;x++){const dx=(x+.5-size/2)/(size/2),dy=-(y+.5-size/2)/(size/2),i=y*size+x;if(Math.hypot(dx,dy)>1)continue;mask[i]=1;const p=K.quadraticDisplayToPhysical(dx,dy,HORIZON);for(let n=1;n<=4;n++){const z=H.orbitalSpatial(n,p.x,p.y,0,1).value;basis[i*8+2*(n-1)]=z.re;basis[i*8+2*(n-1)+1]=z.im;}}return {basis,mask,size};}
function playbackRate(mode,period,pace){return mode==='return'?period/24:pace;}
function seekDelta(ticks,period,fraction){const P=BigInt(period)*120000n,t=BigInt(ticks),target=BigInt(Math.round(Math.max(0,Math.min(1,fraction))*Number(P)));return (target-t%P+P)%P;}
root.HydrogenDisplay=Object.freeze({HORIZON,weights,sample,pixel,grid,seekDelta,playbackRate,oklchToRgb});
})(globalThis);
