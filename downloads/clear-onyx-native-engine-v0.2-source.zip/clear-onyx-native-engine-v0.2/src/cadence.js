/* Presentation schedule only. Native laws and the replay contract live in session.js. */
(function(root){
'use strict';
const ROUTE=Object.freeze(['hydrogen','helium','water','higgs','periodic','watch','orbit','eye']);
const LABELS=Object.freeze(['Hydrogen mirror','Correlated pair','Two-center scope','Doublet','Pitch wheel','Watchworks','Orbital flow','Eye reader']);
const PEEK=Object.freeze([1/3,1/3,2/3,0,1/3,0,0,0]),DWELL=4,END=DWELL*(ROUTE.length-1);
function at(age){
 if(!Number.isFinite(age))throw Error('Cadence age must be finite.');
 age=Math.max(0,age);const done=age>=END,slot=Math.min(ROUTE.length-1,Math.floor(age/DWELL)),local=done?0:age%DWELL;
 // Read first, then move: 2.5 beats of native motion precede the reader transition.
 const t=Math.max(0,Math.min(1,(local-2.5))),smooth=t*t*(3-2*t);
 return Object.freeze({id:ROUTE[slot],slot,view:slot===0?1/3:PEEK[slot]*smooth,progress:done?1:Math.min(1,(slot+local/DWELL)/(ROUTE.length-1)),done});
}
root.CarrierCadence=Object.freeze({ROUTE,LABELS,DWELL,END,at});
})(globalThis);
