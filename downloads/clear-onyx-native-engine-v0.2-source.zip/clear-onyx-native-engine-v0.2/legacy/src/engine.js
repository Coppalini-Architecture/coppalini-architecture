/* Clear_Onyx / One Carrier 0.1. Native state, readers and return receipt. No DOM. */
(function (root) {
  'use strict';
  const Core = root.ClearOnyxNext, Orbitals = root.HydrogenOrbitals;
  if (!Core || !Orbitals) throw Error('The retained root and orbital modules are required.');
  const VERSION = 'clear-onyx-one-carrier/0.1';
  const TICKS = 120000n, RETURN_TICKS = 108n * TICKS;
  const NUM = [0n, 108n, 128n, 135n]; // common denominator 108, in native base-beats
  const FREQUENCIES = [0, 1, 32 / 27, 5 / 4];
  const W = [[1,1,1,1],[1,-1,1,-1],[1,1,-1,-1],[1,-1,-1,1]].map(r=>r.map(v=>v/2));
  const negA = [1,-1,-1,-1].map(v=>v/2), negB = [0,1,-1,0].map(v=>v/Math.sqrt(2));
  const GEOMETRY = Object.freeze({bondLengthAH:0.9572/0.529177,bondAngleRad:104.52*Math.PI/180});
  const SOURCES = Object.freeze({root:'Structure of Survival v66 / retained laboratory root',orbitals:'HydrogenOrbitals / retained analytic Coulomb functions',phase:'[0,1,32/27,5/4] base-beat frequencies',construction:'Declared norm-preserving channel split; fixed H–O–H endpoint geometry',collective:'diag(W4,W4); normalized real Hadamard coordinates',sha256:root.OneCarrierSourceHashes||null});
  const abs2 = z=>z.re*z.re+z.im*z.im;
  const norm2 = u=>u.reduce((s,z)=>s+abs2(z),0);
  const finite = (x,lo,hi,name)=>{if(typeof x!=='number'||!Number.isFinite(x)||x<lo||x>hi)throw Error('Invalid '+name);return x;};
  const sum = u=>u.reduce((a,z)=>({re:a.re+z.re,im:a.im+z.im}),{re:0,im:0});
  const complexScale=(z,a)=>({re:z.re*a,im:z.im*a});
  const keys=(x,wanted)=>x&&typeof x==='object'&&!Array.isArray(x)&&Object.keys(x).sort().join('|')===wanted.slice().sort().join('|');
  function integer(x,name,maxDigits=30){if(typeof x!=='string'||!/^\d+$/.test(x)||x.length>maxDigits)throw Error('Invalid '+name);return BigInt(x);}
  function basisMatrix(amount) {
    finite(amount,0,1,'basis amount');
    if(amount===0)return W.map((r,i)=>r.map((_,j)=>+(i===j)));
    if(amount===1)return W.map(r=>r.slice());
    const c=Math.cos(Math.PI*amount)-1,s=Math.sin(Math.PI*amount);
    return W.map((r,i)=>r.map((_,j)=>+(i===j)+c*(negA[i]*negA[j]+negB[i]*negB[j])+s*(negB[i]*negA[j]-negA[i]*negB[j])));
  }
  function coordinates(u,amount=1,inverse=false){
    if(!Array.isArray(u)||u.length!==8)throw Error('Eight complex channels are required.');
    let M=basisMatrix(amount);if(inverse)M=M[0].map((_,i)=>M.map(row=>row[i]));
    return [0,1].flatMap(side=>M.map(row=>row.reduce((z,a,j)=>({re:z.re+a*u[4*side+j].re,im:z.im+a*u[4*side+j].im}),{re:0,im:0})));
  }
  function split(u){const v=coordinates(u),h=[v[0],v[4]],details=[v[1],v[2],v[3],v[5],v[6],v[7]];return {v,h,details,total:norm2(u),collective:norm2(h),detail:norm2(details),reconstructionResidual:Math.max(...coordinates(v,1,true).map((z,i)=>Math.hypot(z.re-u[i].re,z.im-u[i].im)))};}
  function polar(h){
    const rho=Math.hypot(h[0].re,h[0].im,h[1].re,h[1].im);
    if(rho===0)return {available:false,rho:0,reason:'ZERO_DOUBLET'};
    const a=complexScale(h[0],1/rho),b=complexScale(h[1],1/rho);
    return {available:true,rho,n:{x:2*(a.re*b.re+a.im*b.im),y:2*(a.re*b.im-a.im*b.re),z:abs2(a)-abs2(b)}};
  }
  function centers(construction){const d=GEOMETRY.bondLengthAH*construction,h=GEOMETRY.bondAngleRad/2;return [[-d*Math.sin(h),-d*Math.cos(h)],[d*Math.sin(h),-d*Math.cos(h)]];}
  function staticBasis(x,z,construction){const cs=centers(construction);return Array.from({length:8},(_,i)=>{const j=i%4,c=cs[i<4?0:1];return Orbitals.orbitalValue(j+1,j,0,x-c[0],0,z-c[1]);});}
  function phase(ticks,previewTicks=0){
    const t=BigInt(ticks),f=finite(previewTicks,0,Number(TICKS),'preview interval');
    return NUM.map((n,j)=>{const r=(n*t)%RETURN_TICKS;const a=-2*Math.PI*(Number(r)/Number(RETURN_TICKS)+FREQUENCIES[j]*f/Number(TICKS));return {re:Math.cos(a),im:Math.sin(a)};});
  }
  function coefficients(ticks,construction,previewTicks=0){const ph=phase(ticks,previewTicks),angle=construction*Math.PI/4;return [Math.cos(angle),Math.sin(angle)].flatMap(w=>ph.map(z=>complexScale(z,.5*w)));}
  function amplitudes(basis,c){return basis.map((a,j)=>complexScale(c[j],a));}
  function sample(ticks,construction,x,z,previewTicks=0){const u=amplitudes(staticBasis(x,z,construction),coefficients(ticks,construction,previewTicks));const L=sum(u.slice(0,4)),R=sum(u.slice(4));return {u,L,R,density:abs2({re:L.re+R.re,im:L.im+R.im}),contrast:2*(L.re*R.re+L.im*R.im),...split(u)};}
  function current(ticks,construction,x,z,previewTicks=0){const h=1e-4,psi=(x,z)=>{const p=sample(ticks,construction,x,z,previewTicks);return {re:p.L.re+p.R.re,im:p.L.im+p.R.im};},p=psi(x,z),xp=psi(x+h,z),xm=psi(x-h,z),zp=psi(x,z+h),zm=psi(x,z-h);return {x:(p.re*(xp.im-xm.im)-p.im*(xp.re-xm.re))/(2*h),z:(p.re*(zp.im-zm.im)-p.im*(zp.re-zm.re))/(2*h)};}
  function grid(size,construction){finite(size,40,300,'grid size');if(!Number.isInteger(size))throw Error('Integer grid size required.');const extent=5.6,b=new Float64Array(size*size*8);for(let y=0;y<size;y++)for(let x=0;x<size;x++)b.set(staticBasis(((x+.5)/size*2-1)*extent,(1-(y+.5)/size*2)*extent,construction),(y*size+x)*8);return {size,extent,b,construction};}
  function field(g,ticks,previewTicks=0,mode='density',out){if(!['density','contrast'].includes(mode))throw Error('Unknown field read');const c=coefficients(ticks,g.construction,previewTicks);out=out||new Float64Array(g.size*g.size);for(let i=0;i<out.length;i++){let lr=0,li=0,rr=0,ri=0;for(let j=0;j<8;j++){const b=g.b[i*8+j];if(j<4){lr+=b*c[j].re;li+=b*c[j].im;}else{rr+=b*c[j].re;ri+=b*c[j].im;}}out[i]=mode==='contrast'?2*(lr*rr+li*ri):(lr+rr)**2+(li+ri)**2;}return out;}
  function makeEngine() {
    let native=0n,total=0n,construction=1,probe={x:.4,z:.65};const events=[];
    function append(e){if(events.length>=50000)throw Error('Session receipt limit reached. Save this session before beginning another.');events.push(Object.freeze({n:events.length+1,...e}));}
    function snapshot(){return {version:VERSION,nativeTicks:String(native),totalTicks:String(total),construction,probe:{...probe},occurrences:events.length};}
    function execute(e){
      if(e.type==='advance'&&keys(e,['type','ticks'])){const d=integer(e.ticks,'tick interval',12);if(d<=0n||d>RETURN_TICKS)throw Error('Advance must be positive and at most 108 beats.');append(e);native+=d;total+=d;}
      else if(e.type==='construction'&&keys(e,['type','value'])){const v=finite(e.value,0,1,'construction');append(e);construction=v;}
      else if(e.type==='probe'&&keys(e,['type','x','z'])){const x=finite(e.x,-5.6,5.6,'probe x'),z=finite(e.z,-5.6,5.6,'probe z');append(e);probe={x,z};}
      else if(e.type==='origin'&&keys(e,['type'])){append(e);native=0n;}
      else if(e.type==='view'&&keys(e,['type','value'])){finite(e.value,0,1,'view amount');append(e);}
      else throw Error('Unrecognized session operation.');
      return snapshot();
    }
    return Object.freeze({snapshot,execute,advance:t=>execute({type:'advance',ticks:String(t)}),construct:v=>execute({type:'construction',value:v}),moveProbe:(x,z)=>execute({type:'probe',x,z}),origin:()=>execute({type:'origin'}),view:v=>execute({type:'view',value:v}),
      read(preview=0){const p=sample(native,construction,probe.x,probe.z,preview),q=polar(p.h);const quarters=total/(TICKS/4n);return {...snapshot(),u:p.u,split:p,polar:q,coefficientNorm:norm2(coefficients(native,construction,preview)),nativeBeat:Number(native%RETURN_TICKS)/Number(TICKS),fullNativeReturns:String(native/RETURN_TICKS),phase4:Number(quarters%4n),lift:String(quarters/4n),seams:Core.seams(p.u)};},
      export(view=0){finite(view,0,1,'saved view');return {format:VERSION,sources:SOURCES,state:snapshot(),view,events:events.map(e=>({...e}))};},
      get events(){return events.map(e=>({...e}));}
    });
  }
  function restore(data){
    if(!keys(data,['format','sources','state','view','events'])||data.format!==VERSION||JSON.stringify(data.sources)!==JSON.stringify(SOURCES)||!Array.isArray(data.events)||data.events.length>50000)throw Error('Session format or source identity does not match this instrument.');
    finite(data.view,0,1,'saved view');const engine=makeEngine();for(let i=0;i<data.events.length;i++){const e=data.events[i];if(!e||e.n!==i+1)throw Error('Receipt sequence is incomplete.');const {n,...command}=e;engine.execute(command);}
    if(JSON.stringify(engine.snapshot())!==JSON.stringify(data.state))throw Error('Replayed session differs from its declared final state.');return {engine,view:data.view};
  }
  const api={VERSION,TICKS,RETURN_TICKS,NUM,FREQUENCIES,W,GEOMETRY,SOURCES,Core,norm2,abs2,sum,basisMatrix,coordinates,split,polar,centers,staticBasis,phase,coefficients,sample,current,grid,field,makeEngine,restore};
  root.OneCarrier=Object.freeze(api);if(typeof module!=='undefined')module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this);
