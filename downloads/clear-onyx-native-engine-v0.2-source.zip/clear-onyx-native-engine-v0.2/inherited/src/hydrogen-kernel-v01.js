
(function (root, factory) {
  "use strict";
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.HydrogenKernelV01 = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  const SCHEMA = "architecture-of-silence.minimum-hydrogen-dynamics/v1";
  const RECEIPT_SCHEMA = "architecture-of-silence.axial-path-lift-receipt/v1";
  const TAU = 2 * Math.PI;
  const SQRT_PI = Math.sqrt(Math.PI);
  const EXPECTATION_RADIUS_AH = 128 / 243;
  const ZETA_MAX = 1 / (6 * Math.PI * Math.E);

  // 2022 CODATA inputs, used only to state the declared reduced-mass model.
  const CONSTANTS = Object.freeze({
    electronMassKg: 9.1093837139e-31,
    protonMassKg: 1.67262192595e-27,
    bohrRadiusM: 5.29177210544e-11,
    rydbergEnergyEv: 13.60569312299,
    hbarEvS: 6.582119569e-16
  });

  function assert(condition, message) {
    if (!condition) throw new TypeError(message);
  }

  function mod(value, modulus) {
    return ((value % modulus) + modulus) % modulus;
  }

  function clamp(value, minimum, maximum) {
    return Math.min(maximum, Math.max(minimum, value));
  }

  function freezeDeep(value) {
    if (value && typeof value === "object" && !Object.isFrozen(value)) {
      Object.freeze(value);
      for (const item of Object.values(value)) freezeDeep(item);
    }
    return value;
  }

  function multiplyComplex(aRe, aIm, bRe, bIm) {
    return { re: aRe * bRe - aIm * bIm, im: aRe * bIm + aIm * bRe };
  }

  function reducedMassModel() {
    const me = CONSTANTS.electronMassKg;
    const mp = CONSTANTS.protonMassKg;
    const ratio = mp / (me + mp);
    const reducedMassKg = me * ratio;
    const bohrRadiusM = CONSTANTS.bohrRadiusM / ratio;
    const rydbergEnergyEv = CONSTANTS.rydbergEnergyEv * ratio;
    const beatEnergyEv = 0.75 * rydbergEnergyEv;
    const angularFrequencyRadS = beatEnergyEv / CONSTANTS.hbarEvS;
    const beatPeriodS = TAU / angularFrequencyRadS;
    return freezeDeep({
      regime: "center-of-mass-separated, field-free, nonrelativistic reduced-mass Coulomb model",
      reducedMassKg,
      reducedMassElectronRatio: ratio,
      bohrRadiusM,
      rydbergEnergyEv,
      beatEnergyEv,
      angularFrequencyRadS,
      beatPeriodS,
      horizonRadiusAh: 12
    });
  }

  const MODEL = reducedMassModel();

  // Dimensionless normalized basis functions in X = r / a_H.
  function basisAt(x, y, z, handedness) {
    assert(handedness === 1 || handedness === -1, "Handedness must be +1 or -1.");
    const radius = Math.hypot(x, y, z);
    const s = Math.exp(-radius) / SQRT_PI;
    const f = Math.exp(-0.5 * radius) / (8 * SQRT_PI);
    return {
      radius,
      s,
      f,
      p: { re: f * x, im: f * handedness * y }
    };
  }

  // Exact spectral propagation of (1s + exp(-i tau) 2p,m=h) / sqrt(2).
  // The omitted common energy phase cannot affect the displayed observables.
  function sample(x, y, z, phase, handedness = 1) {
    const basis = basisAt(x, y, z, handedness);
    const qRe = Math.cos(phase);
    const qIm = -Math.sin(phase);
    const qp = multiplyComplex(qRe, qIm, basis.p.re, basis.p.im);
    const psiRe = (basis.s + qp.re) / Math.SQRT2;
    const psiIm = qp.im / Math.SQRT2;
    const density = psiRe * psiRe + psiIm * psiIm;
    const basisCarrier = basis.s * basis.s + basis.p.re * basis.p.re + basis.p.im * basis.p.im;
    const visibility = basisCarrier > Number.MIN_VALUE
      ? clamp(2 * basis.s * Math.hypot(basis.p.re, basis.p.im) / basisCarrier, 0, 1)
      : 0;

    return {
      psi: { re: psiRe, im: psiIm },
      density,
      localPhase: Math.atan2(psiIm, psiRe),
      visibility,
      interference: density - 0.5 * basisCarrier,
      radius: basis.radius
    };
  }

  function densityClosedForm(x, y, z, phase, handedness = 1) {
    const basis = basisAt(x, y, z, handedness);
    const pSquared = basis.f * basis.f * (x * x + y * y);
    const cross = 2 * basis.s * basis.f * (
      x * Math.cos(phase) + handedness * y * Math.sin(phase)
    );
    return 0.5 * (basis.s * basis.s + pSquared + cross);
  }

  // Difference between the two exact reflected branches. The half-angle
  // adapter phase = 2 * theta exposes the Heavy Horizon sin(2 theta) factor.
  function mirrorZeta(x, y, z, theta) {
    const radius = Math.hypot(x, y, z);
    return y * Math.exp(-1.5 * radius) * Math.sin(2 * theta) / (4 * Math.PI);
  }

  function branchDifference(x, y, z, phase) {
    return densityClosedForm(x, y, z, phase, 1)
      - densityClosedForm(x, y, z, phase, -1);
  }

  function expectationPosition(phase, handedness = 1) {
    assert(handedness === 1 || handedness === -1, "Handedness must be +1 or -1.");
    return {
      x: EXPECTATION_RADIUS_AH * Math.cos(phase),
      y: handedness * EXPECTATION_RADIUS_AH * Math.sin(phase),
      z: 0
    };
  }

  // Dimensionless probability current J = Im(psi* grad_X psi).
  // Physical current is (hbar / (mu a_H^4)) J.
  function probabilityCurrent(x, y, z, phase, handedness = 1) {
    const basis = basisAt(x, y, z, handedness);
    const radius = basis.radius;
    const invRadius = radius > 0 ? 1 / radius : 0;
    const qRe = Math.cos(phase);
    const qIm = -Math.sin(phase);
    const qp = multiplyComplex(qRe, qIm, basis.p.re, basis.p.im);
    const psi = {
      re: (basis.s + qp.re) / Math.SQRT2,
      im: qp.im / Math.SQRT2
    };

    const pFactorRe = x;
    const pFactorIm = handedness * y;
    const axes = [
      { radial: x, directRe: 1, directIm: 0 },
      { radial: y, directRe: 0, directIm: handedness },
      { radial: z, directRe: 0, directIm: 0 }
    ];
    const current = [];

    for (const axis of axes) {
      const ds = -basis.s * axis.radial * invRadius;
      const radialScale = -0.5 * axis.radial * invRadius;
      const dpRe = basis.f * (axis.directRe + radialScale * pFactorRe);
      const dpIm = basis.f * (axis.directIm + radialScale * pFactorIm);
      const qdp = multiplyComplex(qRe, qIm, dpRe, dpIm);
      const gradientRe = (ds + qdp.re) / Math.SQRT2;
      const gradientIm = qdp.im / Math.SQRT2;
      current.push(psi.re * gradientIm - psi.im * gradientRe);
    }

    return { x: current[0], y: current[1], z: current[2] };
  }

  function displayTone(density) {
    const intensity = clamp(2 * Math.PI * density, 0, 1);
    return Math.log1p(31 * intensity) / Math.log(32);
  }

  function phaseDisplayChroma(visibility) {
    return 0.2 * clamp(visibility, 0, 1);
  }

  function seamDisplayChroma(zeta) {
    return 0.2 * Math.min(1, Math.abs(zeta) / ZETA_MAX);
  }

  // Renderer-only map between the physical Cartesian plane and a unit disk:
  // R = r/a_H = horizon * u^2. Cartesian +Y remains up in this API.
  function physicalToQuadraticDisplay(x, y, horizon = 12) {
    assert(Number.isFinite(horizon) && horizon > 0, "Display horizon must be positive.");
    const radius = Math.hypot(x, y);
    if (radius === 0) return { x: 0, y: 0, u: 0 };
    const u = Math.sqrt(radius / horizon);
    return { x: u * x / radius, y: u * y / radius, u };
  }

  function quadraticDisplayToPhysical(displayX, displayY, horizon = 12) {
    assert(Number.isFinite(horizon) && horizon > 0, "Display horizon must be positive.");
    const u = Math.hypot(displayX, displayY);
    if (u === 0) return { x: 0, y: 0, radius: 0 };
    const radius = horizon * u * u;
    return {
      x: radius * displayX / u,
      y: radius * displayY / u,
      radius
    };
  }

  // Pushes a physical vector through F(r)=r/(sqrt(horizon)*sqrt(|r|)).
  function pushForwardQuadraticDisplay(x, y, vectorX, vectorY, horizon = 12) {
    assert(Number.isFinite(horizon) && horizon > 0, "Display horizon must be positive.");
    const radius = Math.hypot(x, y);
    if (radius === 0) return { x: 0, y: 0 };
    const dot = x * vectorX + y * vectorY;
    const scale = 1 / Math.sqrt(horizon * radius);
    const correction = 0.5 * dot / (radius * radius);
    return {
      x: scale * (vectorX - correction * x),
      y: scale * (vectorY - correction * y)
    };
  }

  function exactQuarterPhase(index) {
    const table = Object.freeze([
      Object.freeze({ cos: 1, sin: 0 }),
      Object.freeze({ cos: 0, sin: 1 }),
      Object.freeze({ cos: -1, sin: 0 }),
      Object.freeze({ cos: 0, sin: -1 })
    ]);
    return table[mod(index, 4)];
  }

  function spinLift(physicalAngle) {
    const alpha = physicalAngle / 2;
    return {
      physicalAngle,
      coveringAngle: alpha,
      diagonal: [
        { re: Math.cos(alpha), im: -Math.sin(alpha) },
        { re: Math.cos(alpha), im: Math.sin(alpha) }
      ]
    };
  }

  // Standard active Pauli-adjoint convention:
  // sigma(p(U)v) = U sigma(v) U^dagger.
  function projectAxialLiftToSO3(lift) {
    assert(lift && Array.isArray(lift.diagonal) && lift.diagonal.length === 2, "An axial diagonal spin lift is required.");
    const top = lift.diagonal[0];
    const physicalAngle = -2 * Math.atan2(top.im, top.re);
    const cosine = Math.cos(physicalAngle);
    const sine = Math.sin(physicalAngle);
    return [
      [cosine, -sine, 0],
      [sine, cosine, 0],
      [0, 0, 1]
    ];
  }

  function defectFromDeck(deck) {
    assert(deck === 1 || deck === -1, "Central deck value must be +1 or -1.");
    return deck - 1;
  }

  function composeDefects(first, second) {
    return first + second + first * second;
  }

  function canonicalAxialPath(direction = 1) {
    assert(direction === 1 || direction === -1, "Turn direction must be +1 or -1.");
    return freezeDeep({
      schema: "architecture-of-silence.canonical-axial-loop/v1",
      parameter: { symbol: "s", interval: [0, 1] },
      axis: [0, 0, 1],
      direction,
      coverMap: "p: SU(2) -> SO(3), restricted to the chosen axial torus",
      basePath: {
        group: "SO(3)",
        expression: "R_z(direction * 2pi * s)",
        basepoint: "+I_3",
        start: "+I_3",
        end: "+I_3"
      },
      liftedPath: {
        group: "SU(2)",
        expression: "diag(exp(-i * direction * pi * s), exp(i * direction * pi * s))",
        initialSheet: "+I_2",
        endpoint: "-I_2"
      },
      endpointEquation: "gammaLift(1) = (-I_2) * gammaLift(0)",
      projectionWitness: "theta_physical(s) = 2 * alpha_covering(s)",
      continuityWitness: "analytic one-parameter subgroup",
      sheetWitness: "changing the initial sheet multiplies both lifted endpoints by -I_2 and preserves the deck element",
      homotopyClass: "nontrivial generator of pi_1(SO(3))",
      concatenationWitness: "deck(gamma_1 * gamma_2) = deck(gamma_1) * deck(gamma_2)",
      evidence: "exact symbolic path; no sampled reconstruction"
    });
  }

  function evaluateAxialPath(pathSpec, parameter) {
    assert(pathSpec && pathSpec.schema === "architecture-of-silence.canonical-axial-loop/v1", "A canonical axial path is required.");
    assert(Number.isFinite(parameter) && parameter >= 0 && parameter <= 1, "Path parameter must lie in [0,1].");
    const direction = pathSpec.direction;
    const physicalAngle = direction * TAU * parameter;
    const coveringAngle = direction * Math.PI * parameter;
    const cosine = Math.cos(physicalAngle);
    const sine = Math.sin(physicalAngle);
    return freezeDeep({
      parameter,
      physicalAngle,
      coveringAngle,
      baseSO3: [
        [cosine, -sine, 0],
        [sine, cosine, 0],
        [0, 0, 1]
      ],
      liftSU2: [
        [{ re: Math.cos(coveringAngle), im: -Math.sin(coveringAngle) }, { re: 0, im: 0 }],
        [{ re: 0, im: 0 }, { re: Math.cos(coveringAngle), im: Math.sin(coveringAngle) }]
      ]
    });
  }

  function createReturnLedger() {
    return freezeDeep({ schema: SCHEMA, completedTurns: 0, cumulativeDeck: 1, receipts: [] });
  }

  function appendPhysicalTurn(ledger, direction = 1) {
    assert(ledger && ledger.schema === SCHEMA, "A minimum hydrogen return ledger is required.");
    assert(direction === 1 || direction === -1, "Turn direction must be +1 or -1.");
    const previousDeck = ledger.cumulativeDeck;
    const loopDeck = -1;
    const cumulativeDeck = previousDeck * loopDeck;
    const receipt = freezeDeep({
      schema: RECEIPT_SCHEMA,
      kind: "LoopLift",
      sequence: ledger.receipts.length,
      physicalTurn: direction * TAU,
      coveringTurn: direction * Math.PI,
      loopDeck,
      cumulativeDeck,
      loopDefectScalar: defectFromDeck(loopDeck),
      cumulativeDefectScalar: defectFromDeck(cumulativeDeck),
      path: canonicalAxialPath(direction),
      priorSequence: ledger.receipts.length ? ledger.receipts.length - 1 : null
    });
    return freezeDeep({
      schema: SCHEMA,
      completedTurns: ledger.completedTurns + 1,
      cumulativeDeck,
      receipts: [...ledger.receipts, receipt]
    });
  }

  function encodePathReceipt(receipt) {
    assert(receipt && receipt.schema === RECEIPT_SCHEMA, "An axial path-lift receipt is required.");
    return JSON.stringify(receipt);
  }

  function validatePathReceipt(receipt) {
    assert(receipt && receipt.schema === RECEIPT_SCHEMA, "Encoded receipt has the wrong schema.");
    const allowedKeys = [
      "schema", "kind", "sequence", "physicalTurn", "coveringTurn",
      "loopDeck", "cumulativeDeck", "loopDefectScalar",
      "cumulativeDefectScalar", "path", "priorSequence"
    ].sort();
    assert(JSON.stringify(Object.keys(receipt).sort()) === JSON.stringify(allowedKeys), "Encoded receipt has an inadmissible field set.");
    assert(receipt.kind === "LoopLift", "Encoded receipt has the wrong occurrence kind.");
    assert(Number.isInteger(receipt.sequence) && receipt.sequence >= 0, "Encoded receipt has an invalid sequence.");
    const direction = Math.sign(receipt.physicalTurn);
    assert(direction === 1 || direction === -1, "Encoded receipt has an invalid direction.");
    assert(receipt.physicalTurn === direction * TAU, "Encoded receipt has an invalid physical turn.");
    assert(receipt.coveringTurn === direction * Math.PI, "Encoded receipt has an invalid covering turn.");
    assert(receipt.loopDeck === -1, "Encoded receipt has an invalid loop deck value.");
    const expectedCumulativeDeck = receipt.sequence % 2 === 0 ? -1 : 1;
    assert(receipt.cumulativeDeck === expectedCumulativeDeck, "Encoded receipt has an invalid cumulative deck value.");
    assert(receipt.loopDefectScalar === -2, "Encoded receipt has an invalid loop defect coefficient.");
    assert(receipt.cumulativeDefectScalar === defectFromDeck(expectedCumulativeDeck), "Encoded receipt has an invalid cumulative defect coefficient.");
    const expectedPrior = receipt.sequence === 0 ? null : receipt.sequence - 1;
    assert(receipt.priorSequence === expectedPrior, "Encoded receipt has an invalid prior sequence.");
    const expectedPath = canonicalAxialPath(direction);
    assert(JSON.stringify(receipt.path) === JSON.stringify(expectedPath), "Encoded receipt does not contain the canonical path witness.");
    return true;
  }

  function decodePathReceipt(encoded) {
    assert(typeof encoded === "string", "Encoded receipt must be a string.");
    const receipt = JSON.parse(encoded);
    validatePathReceipt(receipt);
    return freezeDeep(receipt);
  }

  const H_HE_REFERENCE = freezeDeep({
    kind: "GroundSpectroscopyReferenceSeam",
    source: {
      kind: "AtomicReference",
      isotope: "1H",
      occupancy: "1s^1",
      term: "2S_1/2",
      electronicJ: 0.5,
      centralCharacter: { identity: 1, centralGenerator: -1 },
      z2piValue: -1,
      shell: "open"
    },
    target: {
      kind: "AtomicReference",
      isotope: "4He",
      occupancy: "1s^2",
      term: "1S_0",
      electronicJ: 0,
      centralCharacter: { identity: 1, centralGenerator: 1 },
      z2piValue: 1,
      shell: "closed"
    },
    edge: {
      kind: "RefStep",
      description: "open first shell to closed first shell",
      isPhysicalEvolution: false
    },
    exclusions: [
      "not physical H-to-He evolution",
      "not H2Molecule",
      "not HydrogenPairOccurrence",
      "not HeavyHorizonH2",
      "not a Berry phase"
    ]
  });

  return freezeDeep({
    SCHEMA,
    RECEIPT_SCHEMA,
    TAU,
    EXPECTATION_RADIUS_AH,
    ZETA_MAX,
    CONSTANTS,
    MODEL,
    H_HE_REFERENCE,
    mod,
    basisAt,
    sample,
    densityClosedForm,
    mirrorZeta,
    branchDifference,
    expectationPosition,
    probabilityCurrent,
    displayTone,
    phaseDisplayChroma,
    seamDisplayChroma,
    physicalToQuadraticDisplay,
    quadraticDisplayToPhysical,
    pushForwardQuadraticDisplay,
    exactQuarterPhase,
    spinLift,
    projectAxialLiftToSO3,
    defectFromDeck,
    composeDefects,
    canonicalAxialPath,
    evaluateAxialPath,
    createReturnLedger,
    appendPhysicalTurn,
    encodePathReceipt,
    validatePathReceipt,
    decodePathReceipt
  });
});

