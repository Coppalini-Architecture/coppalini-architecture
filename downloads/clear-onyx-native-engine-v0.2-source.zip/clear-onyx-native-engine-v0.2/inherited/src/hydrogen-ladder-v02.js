
(function (root, factory) {
  "use strict";
  const parent = root.HydrogenKernelV01
    || (typeof require === "function" ? require("../witnesses/hydrogen_kernel_v01.js") : null);
  const api = factory(parent);
  if (typeof module === "object" && module.exports) module.exports = api;
  root.HydrogenOrbitalLadderV02 = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function (parent) {
  "use strict";

  if (!parent) throw new TypeError("HydrogenKernelV01 parent is required.");

  const SCHEMA = "architecture-of-silence.hydrogen-orbital-ladder/v2";
  const SQRT_PI = Math.sqrt(Math.PI);
  const ALLOWED = Object.freeze([1, 2, 3, 4]);
  const ORBITALS = Object.freeze({
    1: Object.freeze({ n: 1, l: 0, mAbs: 0, label: "1s", stateLabel: "1s · mₗ=0", coefficient: 1 / SQRT_PI, phaseNumerator: 0, phaseDenominator: 1 }),
    2: Object.freeze({ n: 2, l: 1, mAbs: 1, label: "2p", stateLabel: "2p · mₗ=+1", coefficient: 1 / (8 * SQRT_PI), phaseNumerator: 1, phaseDenominator: 1 }),
    3: Object.freeze({ n: 3, l: 2, mAbs: 2, label: "3d", stateLabel: "3d · mₗ=+2", coefficient: 1 / (162 * SQRT_PI), phaseNumerator: 32, phaseDenominator: 27 }),
    4: Object.freeze({ n: 4, l: 3, mAbs: 3, label: "4f", stateLabel: "4f · mₗ=+3", coefficient: 1 / (6144 * SQRT_PI), phaseNumerator: 5, phaseDenominator: 4 })
  });

  function assert(condition, message) {
    if (!condition) throw new TypeError(message);
  }

  function clamp(value, minimum, maximum) {
    return Math.min(maximum, Math.max(minimum, value));
  }

  function freezeDeep(value) {
    if (value && typeof value === "object" && !Object.isFrozen(value)) {
      Object.freeze(value);
      for (const item of Object.values(value)) freezeDeep(item);
    }
    return value;
  }

  function complexMultiply(a, b) {
    return { re: a.re * b.re - a.im * b.im, im: a.re * b.im + a.im * b.re };
  }

  function complexAdd(a, b) {
    return { re: a.re + b.re, im: a.im + b.im };
  }

  function complexScale(value, scale) {
    return { re: value.re * scale, im: value.im * scale };
  }

  function complexPower(base, exponent) {
    let result = { re: 1, im: 0 };
    for (let index = 0; index < exponent; index++) result = complexMultiply(result, base);
    return result;
  }

  function isNormalizedActive(active) {
    return Array.isArray(active)
      && active.length >= 2
      && active[0] === 1
      && active[1] === 2
      && active.every((n, index) => ALLOWED.includes(n) && (index === 0 || active[index - 1] < n));
  }

  function normalizeActive(active) {
    if (Object.isFrozen(active) && isNormalizedActive(active)) return active;
    assert(Array.isArray(active), "Active orbital support must be an array.");
    const normalized = Array.from(new Set(active)).sort((left, right) => left - right);
    assert(normalized.includes(1) && normalized.includes(2), "The sealed 1s and 2p parent support must remain active.");
    assert(normalized.every(n => ALLOWED.includes(n)), "Only the declared n=1..4 ladder is available.");
    return Object.freeze(normalized);
  }

  function orbitalSpatial(n, x, y, zCoordinate, mSign = 1) {
    assert(mSign === 1 || mSign === -1, "Azimuthal sign must be +1 or -1.");
    const orbital = ORBITALS[n];
    assert(orbital, "Unknown hydrogen orbital.");
    const radius = Math.hypot(x, y, zCoordinate);
    const xy = { re: x, im: mSign * y };
    const monomial = complexPower(xy, orbital.l);
    const lowerPower = orbital.l > 0 ? complexPower(xy, orbital.l - 1) : { re: 0, im: 0 };
    const envelope = orbital.coefficient * Math.exp(-radius / orbital.n);
    const value = complexScale(monomial, envelope);
    const invRadius = radius > 0 ? 1 / radius : 0;
    const directX = complexScale(lowerPower, orbital.l);
    const directY = complexMultiply(
      complexScale(lowerPower, orbital.l),
      { re: 0, im: mSign }
    );
    const radialX = -x * invRadius / orbital.n;
    const radialY = -y * invRadius / orbital.n;
    const radialZ = -zCoordinate * invRadius / orbital.n;
    const gradientX = complexScale(complexAdd(directX, complexScale(monomial, radialX)), envelope);
    const gradientY = complexScale(complexAdd(directY, complexScale(monomial, radialY)), envelope);
    const gradientZ = complexScale(monomial, envelope * radialZ);
    return {
      radius,
      value,
      gradient: [gradientX, gradientY, gradientZ],
      // The 1s Coulomb cusp has no classical Cartesian gradient at R=0.
      // The zero vector above is only a weak-gradient representative used
      // inside the separately well-defined continuous current extension.
      gradientDefined: !(n === 1 && radius === 0)
    };
  }

  function relativePhaseRatio(n) {
    const orbital = ORBITALS[n];
    assert(orbital, "Unknown hydrogen orbital.");
    return freezeDeep({
      numerator: orbital.phaseNumerator,
      denominator: orbital.phaseDenominator,
      value: orbital.phaseNumerator / orbital.phaseDenominator
    });
  }

  function sampleState(activeInput, x, y, zCoordinate, basePhase, mSign = 1) {
    const active = normalizeActive(activeInput);
    const amplitudeScale = 1 / Math.sqrt(active.length);
    let psi = { re: 0, im: 0 };
    const gradient = [{ re: 0, im: 0 }, { re: 0, im: 0 }, { re: 0, im: 0 }];
    let incoherentDensity = 0;
    let gradientDefined = true;

    for (const n of active) {
      const spatial = orbitalSpatial(n, x, y, zCoordinate, mSign);
      gradientDefined = gradientDefined && spatial.gradientDefined;
      const ratio = ORBITALS[n].phaseNumerator / ORBITALS[n].phaseDenominator;
      const angle = -ratio * basePhase;
      const timeFactor = { re: Math.cos(angle), im: Math.sin(angle) };
      const amplitude = complexScale(complexMultiply(timeFactor, spatial.value), amplitudeScale);
      psi = complexAdd(psi, amplitude);
      for (let axis = 0; axis < 3; axis++) {
        gradient[axis] = complexAdd(
          gradient[axis],
          complexScale(complexMultiply(timeFactor, spatial.gradient[axis]), amplitudeScale)
        );
      }
      incoherentDensity += amplitudeScale * amplitudeScale
        * (spatial.value.re * spatial.value.re + spatial.value.im * spatial.value.im);
    }

    const density = psi.re * psi.re + psi.im * psi.im;
    const probabilityCurrent = gradient.map(component => psi.re * component.im - psi.im * component.re);
    const contrastDenominator = density + incoherentDensity;
    const coherenceContrast = contrastDenominator > Number.MIN_VALUE
      ? clamp(Math.abs(density - incoherentDensity) / contrastDenominator, 0, 1)
      : 0;

    return {
      active,
      psi,
      density,
      incoherentDensity,
      coherenceContrast,
      localPhase: density > 0 ? Math.atan2(psi.im, psi.re) : null,
      gradientDefined,
      probabilityCurrent: { x: probabilityCurrent[0], y: probabilityCurrent[1], z: probabilityCurrent[2] }
    };
  }

  function mirrorDifference(active, x, y, zCoordinate, basePhase) {
    return sampleState(active, x, y, zCoordinate, basePhase, 1).density
      - sampleState(active, x, y, zCoordinate, basePhase, -1).density;
  }

  function greatestCommonDivisor(a, b) {
    let left = Math.abs(a);
    let right = Math.abs(b);
    while (right) [left, right] = [right, left % right];
    return left;
  }

  function leastCommonMultiple(a, b) {
    return Math.abs(a * b) / greatestCommonDivisor(a, b);
  }

  function rayRecurrenceBeats(activeInput) {
    const active = normalizeActive(activeInput);
    return active.reduce(
      (multiple, n) => leastCommonMultiple(multiple, ORBITALS[n].phaseDenominator),
      1
    );
  }

  // Absolute Coulomb phases in units of the sealed 1s-2p beat period obey
  // exp(i * 2pi * 4k / (3n^2)).  This recurrence depends on the declared
  // zero of the Hamiltonian; the ray recurrence above is the observable one.
  function vectorRecurrenceBeats(activeInput) {
    const active = normalizeActive(activeInput);
    return active.reduce((multiple, n) => {
      const denominator = 3 * n * n;
      return leastCommonMultiple(multiple, denominator / greatestCommonDivisor(4, denominator));
    }, 1);
  }

  function energySummary(activeInput) {
    const active = normalizeActive(activeInput);
    const count = active.length;
    const meanBindingRatio = active.reduce((sum, n) => sum + 1 / (n * n), 0) / count;
    const secondMomentRatio = active.reduce((sum, n) => sum + 1 / Math.pow(n, 4), 0) / count;
    const varianceRatio = Math.max(0, secondMomentRatio - meanBindingRatio * meanBindingRatio);
    const rayBeats = rayRecurrenceBeats(active);
    const vectorBeats = vectorRecurrenceBeats(active);
    return freezeDeep({
      active,
      eigenvaluesEv: active.map(n => -parent.MODEL.rydbergEnergyEv / (n * n)),
      expectationEv: -parent.MODEL.rydbergEnergyEv * meanBindingRatio,
      bindingExpectationRatio: meanBindingRatio,
      varianceEvSquared: parent.MODEL.rydbergEnergyEv * parent.MODEL.rydbergEnergyEv * varianceRatio,
      standardDeviationEv: parent.MODEL.rydbergEnergyEv * Math.sqrt(varianceRatio),
      rayRecurrenceBeats: rayBeats,
      rayRecurrenceSeconds: rayBeats * parent.MODEL.beatPeriodS,
      vectorRecurrenceBeats: vectorBeats,
      vectorRecurrenceSeconds: vectorBeats * parent.MODEL.beatPeriodS
    });
  }

  function fixedEnergyLevels() {
    return freezeDeep(ALLOWED.map(n => ({
      n,
      label: ORBITALS[n].label,
      stateLabel: ORBITALS[n].stateLabel,
      bindingRatio: 1 / (n * n),
      energyEv: -parent.MODEL.rydbergEnergyEv / (n * n)
    })));
  }

  function stateSignature(activeInput) {
    return normalizeActive(activeInput).map(n => ORBITALS[n].stateLabel).join(" + ");
  }

  return freezeDeep({
    SCHEMA,
    ORBITALS,
    ALLOWED,
    normalizeActive,
    orbitalSpatial,
    relativePhaseRatio,
    sampleState,
    mirrorDifference,
    rayRecurrenceBeats,
    vectorRecurrenceBeats,
    energySummary,
    fixedEnergyLevels,
    stateSignature
  });
});

