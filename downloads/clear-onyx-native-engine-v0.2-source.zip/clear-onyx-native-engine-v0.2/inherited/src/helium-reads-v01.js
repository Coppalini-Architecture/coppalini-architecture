(function(root){
"use strict"; const PRECOMPUTED=root.HeliumSolve;
  const ALPHA = PRECOMPUTED.alpha;
  const BASIS_NAMES = PRECOMPUTED.basisNames;
  const EIGENVALUES = PRECOMPUTED.eigenvalues;
  const GROUND = PRECOMPUTED.groundCoeffs;
  const FIRST_EXCITED = PRECOMPUTED.firstExcitedCoeffs;

  // ---- basis function values (mirrors src/helium_hylleraas_basis_v01.js
  // exactly; duplicated here only because this is a standalone viewer file,
  // not because the math differs) ----
  function basisPoly(name, s, t, u) {
    switch (name) {
      case "1": return 1;
      case "u": return u;
      case "s": return s;
      case "u2": return u * u;
      case "su": return s * u;
      case "s2": return s * s;
      case "t2": return t * t;
    }
  }
  function stuFromX1X2(x1, x2) {
    const r1 = Math.abs(x1), r2 = Math.abs(x2);
    const s = r1 + r2, t = r1 - r2;
    const sameSign = (x1 >= 0 && x2 >= 0) || (x1 <= 0 && x2 <= 0);
    const u = sameSign ? Math.abs(t) : s;
    return { s, t, u, r1, r2 };
  }
  function waveAt(coeffs, s, t, u) {
    const E = Math.exp(-ALPHA * s);
    let v = 0;
    for (let k = 0; k < BASIS_NAMES.length; k++) v += coeffs[k] * basisPoly(BASIS_NAMES[k], s, t, u);
    return E * v;
  }

  // -------------------------------------------------------------------
  // Ported directly from src/helium_hylleraas_basis_v01.js,
  // src/helium_cusp_diagnostics_v01.js, and src/helium_reads_v01.js --
  // same verified formulas (including the corrected r2hat.uhat sign and
  // the pi^2 physical-normalization fix), not reimplemented from scratch,
  // so this viewer needs no Node runtime to reproduce every diagnostic.
  // -------------------------------------------------------------------
  function gaussLegendre(n) {
    const x = new Array(n), w = new Array(n);
    const m = Math.floor((n + 1) / 2);
    for (let i = 0; i < m; i++) {
      let z = Math.cos(Math.PI * (i + 0.75) / (n + 0.5));
      let z1, pp;
      for (let iter = 0; iter < 100; iter++) {
        let p0 = 1, p1 = 0;
        for (let j = 0; j < n; j++) { const p2 = p1; p1 = p0; p0 = ((2 * j + 1) * z * p1 - j * p2) / (j + 1); }
        pp = n * (z * p0 - p1) / (z * z - 1);
        z1 = z; z = z1 - p0 / pp;
        if (Math.abs(z - z1) < 1e-15) break;
      }
      x[i] = -z; x[n - 1 - i] = z;
      w[i] = 2 / ((1 - z * z) * pp * pp); w[n - 1 - i] = w[i];
    }
    return { x, w };
  }
  function glMapped(order, a, b) {
    const gl = gaussLegendre(order);
    const scale = 0.5 * (b - a);
    return gl.x.map((xn, i) => ({ x: 0.5 * (b - a) * xn + 0.5 * (a + b), w: gl.w[i] * scale }));
  }
  function basisPartialsFor(name, s, t, u) {
    const E = Math.exp(-ALPHA * s);
    let v, vs, vt, vu;
    switch (name) {
      case "1": v = 1; vs = 0; vt = 0; vu = 0; break;
      case "u": v = u; vs = 0; vt = 0; vu = 1; break;
      case "s": v = s; vs = 1; vt = 0; vu = 0; break;
      case "u2": v = u * u; vs = 0; vt = 0; vu = 2 * u; break;
      case "su": v = s * u; vs = u; vt = 0; vu = s; break;
      case "s2": v = s * s; vs = 2 * s; vt = 0; vu = 0; break;
      case "t2": v = t * t; vs = 0; vt = 2 * t; vu = 0; break;
    }
    return { s: E * (vs - ALPHA * v), t: E * vt, u: E * vu, val: E * v };
  }

  // ---- Cusp diagnostics ----
  function electronElectronCuspResidual(coeffs, sValues) {
    return sValues.map(s => {
      let val = 0, du = 0;
      for (let k = 0; k < BASIS_NAMES.length; k++) {
        const p = basisPartialsFor(BASIS_NAMES[k], s, 0, 0);
        val += coeffs[k] * p.val; du += coeffs[k] * p.u;
      }
      const ratio = Math.abs(val) > 1e-12 ? du / val : NaN;
      return { s, ratio, residual: ratio - 0.5 };
    });
  }
  function waveCartesian(coeffs, r1vec, r2vec) {
    const r1 = Math.hypot(...r1vec), r2 = Math.hypot(...r2vec);
    const u = Math.hypot(r1vec[0] - r2vec[0], r1vec[1] - r2vec[1], r1vec[2] - r2vec[2]);
    const s = r1 + r2, t = r1 - r2;
    return waveAt(coeffs, s, t, u);
  }
  function electronNuclearCuspResidual(coeffs, r2, r1Small, angleCount) {
    angleCount = angleCount || 12;
    const r2vec = [r2, 0, 0];
    const cosThetas = []; for (let i = 0; i < angleCount; i++) cosThetas.push(-1 + 2 * (i + 0.5) / angleCount);
    const h = r1Small * 0.02;
    let sumRadialDeriv = 0, sumPsiAtR1 = 0;
    for (const cosT of cosThetas) {
      const sinT = Math.sqrt(Math.max(0, 1 - cosT * cosT));
      const dir = [cosT, sinT, 0];
      const plus = dir.map(x => x * (r1Small + h)), minus = dir.map(x => x * (r1Small - h)), at = dir.map(x => x * r1Small);
      sumRadialDeriv += (waveCartesian(coeffs, plus, r2vec) - waveCartesian(coeffs, minus, r2vec)) / (2 * h);
      sumPsiAtR1 += waveCartesian(coeffs, at, r2vec);
    }
    const avgRadialDeriv = sumRadialDeriv / angleCount, avgPsi = sumPsiAtR1 / angleCount;
    const ratio = Math.abs(avgPsi) > 1e-12 ? avgRadialDeriv / avgPsi : NaN;
    return { r2, r1Probe: r1Small, ratio, residual: ratio + 2 };
  }

  // ---- Reduced density reads (pi^2 physical-normalization fix applied) ----
  function physicallyNormalizedCoeffs(coeffs) { return coeffs.map(c => c / Math.PI); }
  function oneElectronDensity(coeffsRaw, r1Values, quadOrder, r2Max) {
    const coeffs = physicallyNormalizedCoeffs(coeffsRaw);
    const r2Nodes = glMapped(quadOrder, 1e-6, r2Max);
    return r1Values.map(r1 => {
      let acc = 0;
      for (const { x: r2, w: wr2 } of r2Nodes) {
        const uLo = Math.abs(r1 - r2), uHi = r1 + r2;
        if (uHi - uLo < 1e-9) continue;
        const uNodes = glMapped(quadOrder, uLo, uHi);
        let inner = 0;
        for (const { x: u, w: wu } of uNodes) { const s = r1 + r2, t = r1 - r2; const psi = waveAt(coeffs, s, t, u); inner += wu * u * psi * psi; }
        acc += wr2 * r2 * inner;
      }
      return { r1, rho1: r1 > 1e-9 ? (4 * Math.PI / r1) * acc : 0 };
    });
  }
  function overlapNormApprox(coeffs, quadOrder, sMax) {
    // <Psi|Psi> in the SAME (pi^2-omitted) measure used for S/H -- for our
    // eigensolver-normalized ground/first-excited coefficients this is 1
    // by construction (C^dagger S C = I); computed directly here anyway
    // rather than assumed.
    const sNodes = glMapped(quadOrder, 1e-6, sMax);
    let acc = 0;
    for (const { x: s, w: ws } of sNodes) {
      const tNodes = glMapped(quadOrder, -s, s);
      for (const { x: t, w: wt } of tNodes) {
        const uNodes = glMapped(Math.max(6, Math.floor(quadOrder / 2)), Math.abs(t), s);
        for (const { x: u, w: wu } of uNodes) { const psi = waveAt(coeffs, s, t, u); acc += ws * wt * wu * u * (s * s - t * t) * psi * psi; }
      }
    }
    return acc;
  }
  function pairSeparationDistribution(coeffs, uValues, quadOrder, sMax, norm) {
    return uValues.map(u => {
      if (u < 1e-6) return { u, P: 0 };
      const sNodes = glMapped(quadOrder, u, sMax);
      const tNodes = glMapped(quadOrder, -u, u);
      let acc = 0;
      for (const { x: s, w: ws } of sNodes) for (const { x: t, w: wt } of tNodes) { const psi = waveAt(coeffs, s, t, u); acc += ws * wt * u * (s * s - t * t) * psi * psi; }
      return { u, P: acc / norm };
    });
  }


root.HeliumNative=Object.freeze({waveAt,stuFromX1X2,waveCartesian,gaussLegendre,glMapped,electronElectronCuspResidual,electronNuclearCuspResidual,oneElectronDensity,overlapNormApprox,pairSeparationDistribution});
})(globalThis);
