(function(root){
"use strict";const TAU=2*Math.PI,PHI=(1+Math.sqrt(5))/2,GOLDEN_ANGLE=TAU/(PHI*PHI);
      const WAVELENGTHS_NM = Array.from({ length: 31 }, (_, k) => 400 + 10 * k);
      const CAUCHY_A = 1.50;
      const DEFAULT_CAUCHY_B = 0.004;
      const SOURCE_DIRECTION = (() => {
        const v = [0.37, -0.26, 0.892];
        const d = Math.hypot(v[0], v[1], v[2]);
        return v.map(x => x / d);
      })();

      function gaussianAsymmetric(wavelength, mean, leftSigma, rightSigma) {
        const sigma = wavelength < mean ? leftSigma : rightSigma;
        const t = (wavelength - mean) / sigma;
        return Math.exp(-0.5 * t * t);
      }
      function cie1931Fit(wavelength) {
        const x = 1.056 * gaussianAsymmetric(wavelength, 599.8, 37.9, 31.0)
          + 0.362 * gaussianAsymmetric(wavelength, 442.0, 16.0, 26.7)
          - 0.065 * gaussianAsymmetric(wavelength, 501.1, 20.4, 26.2);
        const y = 0.821 * gaussianAsymmetric(wavelength, 568.8, 46.9, 40.5)
          + 0.286 * gaussianAsymmetric(wavelength, 530.9, 16.3, 31.1);
        const z = 1.217 * gaussianAsymmetric(wavelength, 437.0, 11.8, 36.0)
          + 0.681 * gaussianAsymmetric(wavelength, 459.0, 26.0, 13.8);
        return [Math.max(0, x), Math.max(0, y), Math.max(0, z)];
      }
      const CMF = WAVELENGTHS_NM.map(cie1931Fit);
      const EQUAL_ENERGY_Y = CMF.reduce((sum, xyz) => sum + xyz[1], 0);

      function sphereNormal(address, cageAngle = 0, phase = 0) {
        const u = (address + 0.5) / 137;
        const z = 1 - 2 * u;
        const radial = Math.sqrt(Math.max(0, 1 - z * z));
        const azimuth = address * GOLDEN_ANGLE + cageAngle + phase * Math.PI / 2;
        return [radial * Math.cos(azimuth), radial * Math.sin(azimuth), z];
      }
      function cauchyIndex(wavelengthNm, dispersionB) {
        const wavelengthMicron = wavelengthNm / 1000;
        return CAUCHY_A + dispersionB / (wavelengthMicron * wavelengthMicron);
      }
      function twoBeamSphereSpectrum(normal, radiusMicron, dispersionB, coherence = 1) {
        const cosIncidenceRaw = Math.abs(
          normal[0] * SOURCE_DIRECTION[0]
          + normal[1] * SOURCE_DIRECTION[1]
          + normal[2] * SOURCE_DIRECTION[2]
        );
        const cosIncidence = Math.max(0.025, Math.min(0.999999, cosIncidenceRaw));
        const sinIncidence2 = Math.max(0, 1 - cosIncidence * cosIncidence);
        const geometricThroughput = (0.28 + 0.72 * Math.abs(normal[2])) * (0.25 + 0.75 * coherence);
        return WAVELENGTHS_NM.map(wavelengthNm => {
          const wavelengthMicron = wavelengthNm / 1000;
          const n = cauchyIndex(wavelengthNm, dispersionB);
          const sinTransmit2 = sinIncidence2 / (n * n);
          const cosTransmit = Math.sqrt(Math.max(0, 1 - sinTransmit2));
          const rsNumerator = cosIncidence - n * cosTransmit;
          const rsDenominator = cosIncidence + n * cosTransmit;
          const rpNumerator = n * cosIncidence - cosTransmit;
          const rpDenominator = n * cosIncidence + cosTransmit;
          const reflectance = 0.5 * (
            Math.pow(rsNumerator / rsDenominator, 2)
            + Math.pow(rpNumerator / rpDenominator, 2)
          );
          const surfaceAmplitude = Math.sqrt(Math.max(0, reflectance));
          const returnedAmplitude = 0.92 * (1 - reflectance) * surfaceAmplitude;
          const internalChord = 2 * radiusMicron * cosTransmit;
          const phaseDelay = TAU * n * internalChord / wavelengthMicron + Math.PI;
          const recombined = surfaceAmplitude * surfaceAmplitude
            + returnedAmplitude * returnedAmplitude
            + 2 * surfaceAmplitude * returnedAmplitude * Math.cos(phaseDelay);
          const unphasedTransmission = 0.08 * (1 - reflectance);
          return geometricThroughput * Math.max(0, recombined + unphasedTransmission);
        });
      }
      function spectrumToLinearRgb(spectrum) {
        let X = 0;
        let Y = 0;
        let Z = 0;
        for (let k = 0; k < WAVELENGTHS_NM.length; k += 1) {
          X += spectrum[k] * CMF[k][0];
          Y += spectrum[k] * CMF[k][1];
          Z += spectrum[k] * CMF[k][2];
        }
        X /= EQUAL_ENERGY_Y;
        Y /= EQUAL_ENERGY_Y;
        Z /= EQUAL_ENERGY_Y;
        const raw = [
          3.2406 * X - 1.5372 * Y - 0.4986 * Z,
          -0.9689 * X + 1.8758 * Y + 0.0415 * Z,
          0.0557 * X - 0.2040 * Y + 1.0570 * Z
        ].map(x => Math.max(0, x));
        return raw.map(x => 1 - Math.exp(-3.1 * x));
      }
      function linearToDisplayRgb(linear) {
        return linear.map(value => {
          const x = Math.max(0, Math.min(1, value));
          const encoded = x <= 0.0031308 ? 12.92 * x : 1.055 * Math.pow(x, 1 / 2.4) - 0.055;
          return Math.round(255 * encoded);
        });
      }
      function spectralRead(normal, radiusMicron, dispersionB, coherence = 1) {
        const spectrum = twoBeamSphereSpectrum(normal, radiusMicron, dispersionB, coherence);
        const linearRgb = spectrumToLinearRgb(spectrum);
        let peakIndex = 0;
        for (let k = 1; k < spectrum.length; k += 1) if (spectrum[k] > spectrum[peakIndex]) peakIndex = k;
        return {
          spectrum,
          linearRgb,
          displayRgb: linearToDisplayRgb(linearRgb),
          peakNm: WAVELENGTHS_NM[peakIndex],
          spectralPower: spectrum.reduce((sum, value) => sum + value, 0) / spectrum.length
        };
      }
      function opticalWitness(normal, radiusMicron, dispersionB, wavelengthNm) {
        const cosine = Math.max(0.025, Math.min(0.999999, Math.abs(
          normal[0] * SOURCE_DIRECTION[0]
          + normal[1] * SOURCE_DIRECTION[1]
          + normal[2] * SOURCE_DIRECTION[2]
        )));
        const n = cauchyIndex(wavelengthNm, dispersionB);
        const cosTransmit = Math.sqrt(Math.max(0, 1 - (1 - cosine * cosine) / (n * n)));
        const chordMicron = 2 * radiusMicron * cosTransmit;
        return {
          wavelengthNm,
          index: n,
          cosineIncidence: cosine,
          internalChordMicron: chordMicron,
          phaseDelayRadians: TAU * n * chordMicron / (wavelengthNm / 1000) + Math.PI
        };
      }
      function spectrumDistance(a, b) {
        return Math.sqrt(a.reduce((sum, value, k) => sum + Math.pow(value - b[k], 2), 0) / a.length);
      }
root.EyeNative=Object.freeze({WAVELENGTHS_NM,sphereNormal,cauchyIndex,twoBeamSphereSpectrum,spectrumToLinearRgb,linearToDisplayRgb,spectralRead,opticalWitness});
})(globalThis);
