#include <mirror_audit/mirror_audit.hpp>
using namespace mirror_audit;

constexpr auto R0 = token("reference:R0");
constexpr auto A  = token("office:phi");
constexpr auto J  = token("jurisdiction:root-algebra");
constexpr auto T  = token("type:operator-office");
constexpr auto V0 = token("singular-enclosing-operator-whole");
constexpr auto V1 = token("refined-operator-office");

using Lock = ReferenceLock<A,J,T,V0,Evidence::certified,Status::closed_exact>;
using Preserve = CandidateMove<R0,A,J,T,V0,Action::preserve>;
using Update = CandidateMove<R0,A,J,T,V1,Action::update,Evidence::derived>;
using Substitute = CandidateMove<R0,A,J,T,V1,Action::substitute,Evidence::derived>;
using FalsePreserve = CandidateMove<R0,A,J,T,V1,Action::preserve>;
using Stale = CandidateMove<token("reference:stale"),A,J,T,V0,Action::preserve>;

static_assert(audit_move<R0,Lock,Preserve>().gate == Gate::can);
static_assert(audit_move<R0,Lock,Update>().gate == Gate::can);
static_assert(audit_move<R0,Lock,Update>().resulting_status == Status::conditional_adapter);
static_assert(audit_move<R0,Lock,Substitute>().gate == Gate::refuse);
static_assert(audit_move<R0,Lock,FalsePreserve>().finding == Finding::false_preserve);
static_assert(audit_move<R0,Lock,Stale>().finding == Finding::stale_reference);

using C = Claim<token("claim:C1"), J, token("condition:C"), token("constraint:K"),
                T, Evidence::derived, Status::closed_exact, token("receipt:001")>;
static_assert(reusable<C>());
static_assert(status_is_well_typed<C>());
static_assert(gate_claim<C>() == Gate::can);

int main() { return 0; }
