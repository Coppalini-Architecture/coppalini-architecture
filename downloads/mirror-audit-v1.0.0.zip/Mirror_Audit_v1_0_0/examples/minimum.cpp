#include <mirror_audit/mirror_audit.hpp>
using namespace mirror_audit;

constexpr auto REF = token("sha256:external-manifest-pins-bytes");
constexpr auto ADDR = token("thermodynamics:entropy-office");
constexpr auto JUR  = token("statistical-mechanics");
constexpr auto TYPE = token("coarse-read");
constexpr auto OLD  = token("entropy=log-compatible-multiplicity");

using Active = ReferenceLock<ADDR,JUR,TYPE,OLD,
    Evidence::certified,Status::closed_typed>;
using Candidate = CandidateMove<REF,ADDR,JUR,TYPE,OLD,Action::preserve>;

static_assert(audit_move<REF,Active,Candidate>().gate == Gate::can);
int main() {}
