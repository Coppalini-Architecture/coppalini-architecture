# Mirror_Audit Formal Language v1.0

## Canonical dependency

`Address -> Jurisdiction -> Condition -> Constraint -> TYPE -> Gate -> Form -> Fit -> Function -> Return -> Receipt -> Reuse`

Mirror_Audit is a read-only reference-discipline compiler. It audits a proposed motion against one declared active reference. It may admit preservation, admit an evidence-backed proposed update, hold an unbuilt candidate, defer an unavailable read, or refuse a type-breaking substitution. Auditing never commits the candidate into the active reference.

## Primitive records

**ReferenceLock** = `(address, jurisdiction, type, value, evidence, status)`.

**CandidateMove** = `(base_reference, address, jurisdiction, type, value, action, evidence)`.

**Claim** = `(address, jurisdiction, condition, constraint, type, evidence, status, receipt)`.

## Actions

- `preserve`: lawful only when the candidate value equals the active locked value.
- `update`: lawful as a proposed motion only with `CERTIFIED` or `DERIVED` evidence. The auditor emits a proposal; it does not mutate the reference.
- `substitute`: always refused. A new meaning must enter as an explicit update under evidence, never under an old name.

## Gates

- `can`: continuation admitted.
- `fold`: typed candidate remains open/unbuilt; hold without erasure.
- `refuse`: continuation violates the active reference, jurisdiction, type, or evidence rule.
- `defer`: required information is unavailable; no result is invented.

## Status ladder

`DEFINED_OFFICE -> DECLARED_PLACEMENT -> UNBUILT_CANDIDATE -> CONDITIONAL_ADAPTER -> CLOSED_TYPED -> CLOSED_EXACT`

`CLOSED_EXACT` requires certified or directly derived evidence. `CLOSED_TYPED` requires an available declared evidence class. `UNBUILT_CANDIDATE` gates to `fold`, retaining the typed burden without pretending execution.

## Reference rule

The compile-time `token()` is a stable literal address only. It is deliberately not represented as cryptographic provenance. Artifact bytes are pinned separately with SHA-256 in `MANIFEST.sha256`. This prevents an identity tag from masquerading as a byte-level source receipt.

## Non-erasure law

A successful audit returns an `AuditResult`. It never modifies `ReferenceLock`. An update therefore has two distinct operations:

1. `audit(candidate | active_reference) -> proposed motion receipt`;
2. an external authorized commit creates a new reference version.

Correction is append-only. Prior reference and prior receipt remain addressable.

## Minimum exact cut

A candidate is admissible exactly when:

1. its declared base reference is current;
2. address, jurisdiction, and type resolve to the active lock;
3. preservation preserves the value, or an update carries admitted evidence;
4. the resulting claim status is supported by its evidence class;
5. a receipt exists before reuse.

Everything else is `fold`, `defer`, or `refuse` according to the typed reason.
