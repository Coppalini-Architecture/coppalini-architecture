# Mirror_Audit v1.0.0

Canonical zero-dependency C++20 reference-discipline kernel.

Mirror_Audit converts the project's boundary discipline into a small compile-time utility. Its job is intentionally narrow: **hold one active reference, mirror one proposed motion against it, cut on admissibility, and preserve a receipt boundary without silent mutation.**

The build preserves the earlier MIRROR_CUT v0.1 behavior as provenance under `legacy/`, while tightening the language into explicit compile-time types.

## Build

```bash
c++ -std=c++20 -Wall -Wextra -Werror -pedantic -Iinclude tests/test_compile.cpp -o mirror_audit_test
./mirror_audit_test
```

## Core guarantees

1. A candidate names the exact reference it was composed against.
2. Address, jurisdiction, and type are checked before value semantics.
3. `preserve` cannot change a locked value.
4. `substitute` is refused.
5. `update` requires certified/derived evidence and remains a proposal.
6. `UNBUILT_CANDIDATE` is a typed hold (`fold`), not a failure or a closure claim.
7. `CLOSED_EXACT` cannot be paired with weak/unavailable evidence.
8. Receipt is required before a claim can enter reuse.
9. The audit operation is read-only: active reference state is a type, not mutable storage.
10. Compile-time literal IDs and external cryptographic provenance are explicitly separate offices.

## Canonical grammar

`Address -> Jurisdiction -> Condition -> Constraint -> TYPE -> Gate -> Form -> Fit -> Function -> Return -> Receipt -> Reuse`

See `spec/MIRROR_AUDIT_LANGUAGE.md`.

## Files

- `include/mirror_audit/mirror_audit.hpp` — header-only C++20 kernel.
- `tests/test_compile.cpp` — compile-time regression suite.
- `examples/minimum.cpp` — minimum use.
- `spec/MIRROR_AUDIT_LANGUAGE.md` — canonical language and laws.
- `legacy/` — preserved MIRROR_CUT v0.1 Python source/tests, unmodified.
- `MANIFEST.sha256` — byte-level package receipt.
