# Changelog

## 1.0.0 — 2026-08-29

- Canonicalized reference discipline around Address/Jurisdiction/Condition/Constraint/TYPE/Gate/Receipt.
- Split stable compile-time literal identity tags from cryptographic artifact provenance.
- Added explicit status ladder through CLOSED_EXACT.
- Added typed `fold` for UNBUILT/CANDIDATE rather than conflating open burden with refusal.
- Made silent substitution mechanically impossible under the canonical action model.
- Restricted evidence-backed updates to proposals; audit remains read-only.
- Required a receipt address before claim reuse.
- Preserved MIRROR_CUT v0.1 unchanged as lineage evidence.
