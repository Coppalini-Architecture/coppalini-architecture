#pragma once
#include <array>
#include <cstdint>
#include <string_view>
#include <type_traits>

namespace mirror_audit {

inline constexpr std::string_view version = "1.0.0";

enum class Gate : std::uint8_t { can, fold, refuse, defer };
enum class Status : std::uint8_t {
    defined_office,
    declared_placement,
    unbuilt_candidate,
    conditional_adapter,
    closed_typed,
    closed_exact
};
enum class Evidence : std::uint8_t {
    certified,
    derived,
    declared,
    policy,
    open,
    unavailable
};
enum class Action : std::uint8_t { preserve, update, substitute };
enum class Finding : std::uint8_t {
    exact_preservation,
    evidence_backed_update,
    silent_substitution,
    false_preserve,
    unearned_update,
    stale_reference,
    missing_reference,
    type_mismatch,
    scope_missing,
    receipt_missing
};

// Stable compile-time address for a literal token. This is an identity tag,
// not a cryptographic content digest. Artifact bytes should additionally be
// pinned by SHA-256 in the external manifest.
consteval std::uint64_t token(std::string_view s) {
    std::uint64_t h = 14695981039346656037ull;
    for (char c : s) {
        h ^= static_cast<unsigned char>(c);
        h *= 1099511628211ull;
    }
    return h;
}

template<std::uint64_t V>
struct Id { static constexpr std::uint64_t value = V; };

template<std::uint64_t Address,
         std::uint64_t Jurisdiction,
         std::uint64_t Type,
         std::uint64_t Value,
         Evidence E,
         Status S>
struct ReferenceLock {
    static constexpr auto address = Address;
    static constexpr auto jurisdiction = Jurisdiction;
    static constexpr auto type = Type;
    static constexpr auto value = Value;
    static constexpr auto evidence = E;
    static constexpr auto status = S;
};

template<std::uint64_t BaseReference,
         std::uint64_t Address,
         std::uint64_t Jurisdiction,
         std::uint64_t Type,
         std::uint64_t Value,
         Action A,
         Evidence E = Evidence::unavailable>
struct CandidateMove {
    static constexpr auto base_reference = BaseReference;
    static constexpr auto address = Address;
    static constexpr auto jurisdiction = Jurisdiction;
    static constexpr auto type = Type;
    static constexpr auto value = Value;
    static constexpr auto action = A;
    static constexpr auto evidence = E;
};

struct AuditResult {
    Gate gate;
    Finding finding;
    Status resulting_status;
    constexpr bool admitted() const { return gate == Gate::can || gate == Gate::fold; }
};

constexpr bool evidence_can_update(Evidence e) {
    return e == Evidence::certified || e == Evidence::derived;
}

template<std::uint64_t ActiveReference, class Lock, class Move>
consteval AuditResult audit_move() {
    if constexpr (Move::base_reference != ActiveReference)
        return {Gate::refuse, Finding::stale_reference, Lock::status};
    if constexpr (Move::address != Lock::address)
        return {Gate::defer, Finding::missing_reference, Lock::status};
    if constexpr (Move::jurisdiction != Lock::jurisdiction || Move::type != Lock::type)
        return {Gate::refuse, Finding::type_mismatch, Lock::status};
    if constexpr (Move::action == Action::substitute)
        return {Gate::refuse, Finding::silent_substitution, Lock::status};
    if constexpr (Move::action == Action::preserve) {
        if constexpr (Move::value == Lock::value)
            return {Gate::can, Finding::exact_preservation, Lock::status};
        else
            return {Gate::refuse, Finding::false_preserve, Lock::status};
    }
    if constexpr (Move::action == Action::update) {
        if constexpr (!evidence_can_update(Move::evidence))
            return {Gate::refuse, Finding::unearned_update, Lock::status};
        else
            return {Gate::can, Finding::evidence_backed_update, Status::conditional_adapter};
    }
    return {Gate::defer, Finding::missing_reference, Lock::status};
}

// Canonical claim shell. Every claim entering reuse must carry the complete
// read-path address: address, jurisdiction, condition, constraint, type,
// evidence, status, and receipt.
template<std::uint64_t Address,
         std::uint64_t Jurisdiction,
         std::uint64_t Condition,
         std::uint64_t Constraint,
         std::uint64_t Type,
         Evidence E,
         Status S,
         std::uint64_t Receipt>
struct Claim {
    static_assert(Address != 0, "Mirror_Audit: claim address required");
    static_assert(Jurisdiction != 0, "Mirror_Audit: jurisdiction required");
    static_assert(Condition != 0, "Mirror_Audit: condition required");
    static_assert(Constraint != 0, "Mirror_Audit: constraint required");
    static_assert(Type != 0, "Mirror_Audit: type required");
    static_assert(Receipt != 0, "Mirror_Audit: receipt required before reuse");
    static constexpr auto address = Address;
    static constexpr auto jurisdiction = Jurisdiction;
    static constexpr auto condition = Condition;
    static constexpr auto constraint = Constraint;
    static constexpr auto type = Type;
    static constexpr auto evidence = E;
    static constexpr auto status = S;
    static constexpr auto receipt = Receipt;
};

template<class ClaimT>
consteval bool reusable() {
    return ClaimT::status == Status::closed_typed || ClaimT::status == Status::closed_exact;
}

// CLOSED-EXACT is reserved for exact proof/certification evidence.
template<class ClaimT>
consteval bool status_is_well_typed() {
    if constexpr (ClaimT::status == Status::closed_exact)
        return ClaimT::evidence == Evidence::certified || ClaimT::evidence == Evidence::derived;
    if constexpr (ClaimT::status == Status::closed_typed)
        return ClaimT::evidence != Evidence::unavailable;
    return true;
}

template<class ClaimT>
consteval Gate gate_claim() {
    if constexpr (!status_is_well_typed<ClaimT>()) return Gate::refuse;
    if constexpr (ClaimT::evidence == Evidence::unavailable) return Gate::defer;
    if constexpr (ClaimT::status == Status::unbuilt_candidate) return Gate::fold;
    return Gate::can;
}

} // namespace mirror_audit
