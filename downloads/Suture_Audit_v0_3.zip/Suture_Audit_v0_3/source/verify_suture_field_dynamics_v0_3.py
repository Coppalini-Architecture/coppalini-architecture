"""Exact receipt for Suture Field Dynamics v0.3 (Card 5a).

Rational arithmetic throughout.  Computed here (not source tokens):
  * Delta_{AB}^{mu nu}(lambda,B) as a 32x32 matrix: Delta(0,0)=0 by construction of the formula,
    Delta != 0 and full rank for nonzero lambda (SD.13, SD.14);
  * Psi(lambda,B) = m . D S as a 32-vector, equal to m^T J with the SD.17 weights, and the
    m -> Psi map has rank 16 (injective) at Pi_star and Pi_vac, so Psi = 0 forces m = 0 (SD.14b);
  * constraint/DoF arithmetic from the displayed lists (SD.15 chart, SD.28-SD.30);
  * the bracket matrix of (pi_a, P_q, C; P_m, m): rank 64, kernel 4 spanned by pi~_a (SD.20e-f);
  * exact nullspace of the eta,C stabilizer (dim 10), orbit rank 10 at Pi_star and Pi_vac,
    and the exact regular isotropy counterexample Pi_iso with rank DS=16 but orbit rank 9;
  * the explicit nonzero stabilizer generator X_iso=0_6 (+) C with X_iso Pi_iso=0;
  * the inverse SD.20e second-class kernel and vanishing Dirac correction for physical observables,
    plus exact multiplier solvability for an arbitrary {C,H_phys} vector;
  * source guards.  The cap and image checks remain separate active cards in verify_all.py.
The remaining finite-model boundary is stated in the residual ledger; whole-branch freeness is
closed negatively by Pi_iso, while the full 16-dimensional regular fibre remains unchanged.
"""
from __future__ import annotations

from fractions import Fraction as Fr
from pathlib import Path

import verify_magnetic_cap_v0_1 as cap
import verify_suture_image_v0_1 as image
from verify_suture_field_dynamics_v0_1 import (
    M, N, rank, root_forms, suture_jacobian,
)

ROOT = Path(__file__).resolve().parent

PI_STAR = (
    (-1, -2, 1, 0), (2, -1, 1, 0), (-1, -2, 1, -2), (-1, 1, -1, 0),
    (-1, 0, 0, -1), (0, 1, 1, -1), (2, 2, 1, -2), (-1, -1, 0, -1),
)
PI_VAC = (
    (1, 0, 0, 0), (0, 0, 0, 0), (0, 1, 0, 0), (0, 0, 0, 0),
    (0, 0, 1, 0), (0, 0, 0, 0), (0, 0, 0, 1), (0, 0, 0, 0),
)
PI_ISO = (
    (1, 0, 0, 0), (0, 1, 0, 0), (0, 1, 0, 0), (0, 0, 1, 0),
    (0, 0, 0, 1), (0, 0, 0, 0), (0, 0, 0, 0), (0, 0, 0, 0),
)


def zeros(r, c):
    return [[Fr(0)] * c for _ in range(r)]


def nullspace(rows, ncols):
    """Exact right nullspace basis of a Fraction matrix."""
    a = [[Fr(x) for x in row] for row in rows]
    piv, r = [], 0
    for c in range(ncols):
        p = next((i for i in range(r, len(a)) if a[i][c]), None)
        if p is None:
            continue
        a[r], a[p] = a[p], a[r]
        d = a[r][c]
        a[r] = [x / d for x in a[r]]
        for i in range(len(a)):
            if i != r and a[i][c]:
                f = a[i][c]
                a[i] = [x - f * y for x, y in zip(a[i], a[r])]
        piv.append(c)
        r += 1
        if r == len(a):
            break
    free = [c for c in range(ncols) if c not in piv]
    basis = []
    for fcol in free:
        v = [Fr(0)] * ncols
        v[fcol] = Fr(1)
        for i, pc in enumerate(piv):
            v[pc] = -a[i][fcol]
        basis.append(v)
    return basis


# ---------- Delta and Psi ----------
def delta_matrix(lam, B, chi, eta, C):
    """32x32 Delta_{(A mu),(B nu)} = 2( lam^{mu nu} eta_AB + chi/2 B^{mu nu} C_AB ), sqrt(-g)=1."""
    D = zeros(N * M, N * M)
    for A in range(N):
        for mu in range(M):
            for Bi in range(N):
                for nu in range(M):
                    D[A * M + mu][Bi * M + nu] = 2 * (lam[mu][nu] * eta[A][Bi] + Fr(chi, 2) * B[mu][nu] * C[A][Bi])
    return D


def psi_vector(lam, B, chi, pi, eta, C):
    """Psi_A^mu = 2 lam^{mu nu} eta_AB Pi^B_nu + chi B^{mu nu} C_AB Pi^B_nu  (SD.12)."""
    out = [Fr(0)] * (N * M)
    for A in range(N):
        for mu in range(M):
            s = Fr(0)
            for nu in range(M):
                for Bi in range(N):
                    s += 2 * lam[mu][nu] * eta[A][Bi] * pi[Bi][nu] + chi * B[mu][nu] * C[A][Bi] * pi[Bi][nu]
            out[A * M + mu] = s
    return out


def sym_basis():
    pairs = [(m, n) for m in range(M) for n in range(m, M)]
    out = []
    for (m, n) in pairs:
        l = zeros(M, M)
        l[m][n] = Fr(1)
        l[n][m] = Fr(1)
        out.append(l)
    return pairs, out


def verify_delta_and_psi() -> None:
    eta, C = root_forms()
    chi = 3
    z = zeros(M, M)
    d0 = delta_matrix(z, z, chi, eta, C)
    assert rank(d0) == 0                                   # SD.14: computed, not constructed as a zero matrix
    ident = [[Fr(int(i == j)) for j in range(M)] for i in range(M)]
    assert rank(delta_matrix(ident, z, chi, eta, C)) == 32     # lambda = 1: eta nondegenerate
    B = zeros(M, M)
    B[0][1], B[1][0], B[2][3], B[3][2] = Fr(1), Fr(-1), Fr(2), Fr(-2)
    assert rank(delta_matrix(z, B, chi, eta, C)) > 0
    # linearity: Delta(a lam + b lam', B) in (lam, B)
    d1 = delta_matrix(ident, B, chi, eta, C)
    d2 = delta_matrix(z, B, chi, eta, C)
    d3 = delta_matrix(ident, z, chi, eta, C)
    assert all(d1[i][j] == d2[i][j] + d3[i][j] for i in range(32) for j in range(32))

    pairs, sym = sym_basis()
    anti_pairs = [(m, n) for m in range(M) for n in range(m + 1, M)]
    for name, pi in (("Pi_star", PI_STAR), ("Pi_vac", PI_VAC)):
        # m -> Psi, columns: 10 symmetric (weight 2-delta on lambda) + 6 antisymmetric (B)
        cols = []
        for (mm, nn), l in zip(pairs, sym):
            w = Fr(2 - int(mm == nn))
            lam = zeros(M, M)
            lam[mm][nn] = Fr(1) / w
            lam[nn][mm] = Fr(1) / w
            cols.append(psi_vector(lam, zeros(M, M), chi, pi, eta, C))
        for (mm, nn) in anti_pairs:
            Bm = zeros(M, M)
            Bm[mm][nn], Bm[nn][mm] = Fr(1), Fr(-1)
            cols.append(psi_vector(zeros(M, M), Bm, chi, pi, eta, C))
        assert len(cols) == 16
        rows_T = [[cols[j][i] for j in range(16)] for i in range(32)]    # 32 x 16
        assert rank(rows_T) == 16, name                                  # Psi = 0  =>  m = 0
        # agreement with m^T J: J has 16 rows (10 h, 6 f) with f rows scaled by chi
        J = suture_jacobian(pi, eta, C)
        scaled = [[Fr(x) * (chi if r >= 10 else 1) for x in row] for r, row in enumerate(J)]
        for j in range(16):
            for i in range(32):
                assert cols[j][i] == scaled[j][i] * (1 if j >= 10 else Fr(1)), (name, j, i)
        # negative control: dropping a Jacobian row loses injectivity
        assert rank([row[:15] for row in rows_T]) <= 15


# ---------- constraint arithmetic ----------
def verify_counts() -> None:
    sectors = {"gamma,N,N^i": 20, "A_mu": 8, "Pi": 64, "B": 12, "lambda": 20}
    total = sum(sectors.values())
    assert total == 124
    primary = (5, 32, 6, 10)
    secondary = (5, 6, 10, 16)
    assert sum(primary) == 53 and sum(secondary) == 37 and 53 + 37 == 90
    fc_em, fc_vert, sc = 10, 16, 64
    fc = fc_em + fc_vert
    assert fc == 26 and fc + sc == 90 and sc == 4 * 16
    assert (total - 2 * fc - sc) % 2 == 0 and (total - 2 * fc - sc) // 2 == 4        # SD.29
    assert (28 - 2 * 10) // 2 == 4                                                   # SD.30
    # SD.15 chart: 148 = 124 + 24, 26 FC, 88 SC
    assert 148 - 124 == 24 and 64 + 24 == 88 and (148 - 2 * 26 - 88) // 2 == 4
    # 16 of the 32 Psi components independent: 32 - 16 = 16 vertical xi
    assert N * M - 16 == 16


# ---------- bracket matrix ----------
def verify_bracket_matrix() -> None:
    # Lapse/shift: g_00 = -N^2 + gamma_ij N^i N^j, g_0i = gamma_ij N^j, gamma = identity here.
    Nn, shift = Fr(2), (Fr(1), Fr(2), Fr(3))
    # X ordering: sym (00,01,02,03,11,12,13,22,23,33), then antisym (01,02,03,12,13,23)
    K = zeros(16, 4)
    K[0][0] = -2 * Nn
    for k in range(3):
        K[0][1 + k] = 2 * shift[k]
        K[1 + k][1 + k] = Fr(1)
    assert rank(K) == 4
    # variables: pi_a (0..3), P_q (4..19), C (20..35), P_m (36..51), m (52..67)
    n = 68
    G = zeros(n, n)
    def put(i, j, v):
        G[i][j] += v
        G[j][i] -= v
    for a in range(4):
        for J in range(16):
            put(a, 20 + J, K[J][a])             # {pi_a, C_J} = dX^J/dn^a
    for I in range(16):
        put(4 + I, 20 + I, Fr(-1))              # {P_q, C} = -1   (SD.20e)
        put(36 + I, 52 + I, Fr(-1))             # {P_m, m} = -1
    assert all(G[i][j] == -G[j][i] for i in range(n) for j in range(n))
    assert rank(G) == 64
    ker = nullspace(G, n)
    assert len(ker) == 4
    for a in range(4):                           # pi~_a = pi_a + sum_I dX^I/dn^a P_qI
        v = [Fr(0)] * n
        v[a] = Fr(1)
        for I in range(16):
            v[4 + I] = K[I][a]
        assert all(sum(G[i][j] * v[j] for j in range(n)) == 0 for i in range(n))
    assert rank([v for v in ker]) == 4
    # without the P_q correction the pi_a themselves are not in the kernel
    v = [Fr(0)] * n
    v[0] = Fr(1)
    assert any(sum(G[i][j] * v[j] for j in range(n)) != 0 for i in range(n))
    # SD.20e block alone: invertible 64x64
    # SD.20e block (P_q,C;P_m,m) alone is invertible
    idx = [i for i in range(n) if i >= 4]
    assert rank([[G[i][j] for j in idx] for i in idx]) == 64


# ---------- stabilizer ----------
def stabilizer_nullspace(eta, C):
    rows = []
    for B in (eta, C):
        for i in range(N):
            for j in range(N):
                row = [0] * (N * N)
                for k in range(N):
                    if B[k][j]:
                        row[k * N + i] += B[k][j]
                    if B[i][k]:
                        row[k * N + j] += B[i][k]
                rows.append(row)
    return nullspace(rows, N * N)


def matmul(A, B):
    return [[sum(Fr(A[i][k]) * Fr(B[k][j]) for k in range(len(B)))
             for j in range(len(B[0]))] for i in range(len(A))]


def transpose(A):
    return [list(row) for row in zip(*A)]


def verify_stabilizer_orbit() -> None:
    eta, C = root_forms()
    ker = stabilizer_nullspace(eta, C)
    assert len(ker) == 10                                       # dim k
    for name, pi in (("Pi_star", PI_STAR), ("Pi_vac", PI_VAC)):
        J = suture_jacobian(pi, eta, C)
        assert rank(J) == 16
        tang = []
        for v in ker:
            X = [[v[r * N + c] for c in range(N)] for r in range(N)]
            d = [sum(X[r][ss] * Fr(pi[ss][a]) for ss in range(N)) for r in range(N) for a in range(M)]
            tang.append(d)
            assert all(sum(Fr(Jr[t]) * d[t] for t in range(N * M)) == 0 for Jr in J), name
        assert rank(tang) == 10, name

    # SD.10a-b: regular point with nontrivial isotropy.
    J = suture_jacobian(PI_ISO, eta, C)
    assert rank(J) == 16
    tang = []
    for v in ker:
        X = [[v[r * N + c] for c in range(N)] for r in range(N)]
        d = [sum(X[r][ss] * Fr(PI_ISO[ss][a]) for ss in range(N)) for r in range(N) for a in range(M)]
        tang.append(d)
        assert all(sum(Fr(Jr[t]) * d[t] for t in range(N * M)) == 0 for Jr in J)
    assert rank(tang) == 9

    # h(Pi_iso) = [[-2,1],[1,3]] (+) I2, hence Lorentzian (block det -7).
    P = [[Fr(x) for x in row] for row in PI_ISO]
    h = matmul(matmul(transpose(P), eta), P)
    expected = [[Fr(-2), Fr(1), 0, 0], [Fr(1), Fr(3), 0, 0],
                [0, 0, Fr(1), 0], [0, 0, 0, Fr(1)]]
    assert h == expected and h[0][0] * h[1][1] - h[0][1] * h[1][0] == -7

    # Explicit nonzero isotropy generator X_iso = 0_6 (+) C.
    Xiso = zeros(N, N)
    for i in range(6, 8):
        for j in range(6, 8):
            Xiso[i][j] = C[i][j]
    assert any(any(v for v in row) for row in Xiso)
    XP = matmul(Xiso, P)
    assert all(v == 0 for row in XP for v in row)
    XT = transpose(Xiso)
    eta_test = [[matmul(XT, eta)[i][j] + matmul(eta, Xiso)[i][j] for j in range(N)] for i in range(N)]
    C_test = [[matmul(XT, C)[i][j] + matmul(C, Xiso)[i][j] for j in range(N)] for i in range(N)]
    assert all(v == 0 for row in eta_test for v in row)
    assert all(v == 0 for row in C_test for v in row)

    # negative control: a non-stabilizer direction is not tangent to the fibre
    X = [[Fr(int(r == c == 0)) for c in range(N)] for r in range(N)]
    d = [sum(X[r][ss] * Fr(PI_STAR[ss][a]) for ss in range(N)) for r in range(N) for a in range(M)]
    J = suture_jacobian(PI_STAR, eta, C)
    assert any(sum(Fr(Jr[t]) * d[t] for t in range(N * M)) != 0 for Jr in J)


def verify_dirac_reduction_block() -> None:
    # SD.20e with ordering (P_q,C;P_m,m), each block dimension 16.
    n = 64
    Cmat = zeros(n, n)
    for i in range(16):
        Cmat[i][16 + i] = Fr(-1)
        Cmat[16 + i][i] = Fr(1)
        Cmat[32 + i][48 + i] = Fr(-1)
        Cmat[48 + i][32 + i] = Fr(1)
    assert rank(Cmat) == 64
    Cinv = [[-Cmat[i][j] for j in range(n)] for i in range(n)]
    I = matmul(Cmat, Cinv)
    assert all(I[i][j] == Fr(int(i == j)) for i in range(n) for j in range(n))

    # A physical observable can bracket C=q-X but commutes with P_q,P_m,m.
    # Therefore its constraint-bracket vector has support only in the C block.
    a = [Fr(0)] * n
    b = [Fr(0)] * n
    for i in range(16):
        a[16 + i] = Fr(i + 1, 3)
        b[16 + i] = Fr(2 * i - 5, 7)
    correction = sum(a[i] * Cinv[i][j] * b[j] for i in range(n) for j in range(n))
    assert correction == 0

    # Arbitrary v_I={C_I,H_phys} is absorbed by u_q^I=-v_I, not promoted to a new constraint.
    v = [Fr(3 * i - 11, 5) for i in range(16)]
    uq = [-x for x in v]
    assert all(v[i] + uq[i] == 0 for i in range(16))


def verify_source() -> None:
    s = (ROOT / "05a_suture_field_dynamics.tex").read_text(encoding="utf-8")
    required = (
        "\\rankop D\\mathscr S_\\Pi=16", "\\dim\\mathfrak k=10",
        "\\tag{SD.11a}", "\\tag{SD.11b}", "\\tag{SD.11c}", "\\tag{SD.11d}", "\\tag{SD.11e}",
        "\\tag{SD.14b}", "\\lambda^{\\mu\\nu}=B^{\\mu\\nu}=0,\\qquad \\Delta=0",
        "m_{(\\mu\\nu)}=(2-\\delta_{\\mu\\nu})\\lambda^{\\mu\\nu}", "m_{[\\mu\\nu]}=B^{\\mu\\nu}",
        "\\tilde\\pi_a:=\\pi_a+\\frac{\\partial X^I}{\\partial n^a}P_{qI}",
        "b(g,F)<|\\chi|", "primary $5+32+6+10=53$, secondary $5+6+10+16=37$, total",
        "\\DoF=\\frac12(148-2\\cdot26-88)=4",
        "\\frac12\\bigl(124-2(10+16)-64\\bigr)=4", "\\frac12\\bigl(28-2\\cdot10\\bigr)=4",
        "\\diag(-2,1,1,1)", "(P_{qI},q^I-X^I)", "(P_{mI},m_I)", "P_{\\xi a}\\approx0",
        "No empirical comparison is asserted.",
    )
    missing = [t for t in required if t not in s]
    assert not missing, missing
    low = s.lower()
    assert "64\\times64" not in s and "no new physics" not in low and "no new math" not in low


def main() -> None:
    verify_delta_and_psi()
    verify_counts()
    verify_bracket_matrix()
    verify_stabilizer_orbit()
    verify_dirac_reduction_block()
    verify_source()
    print("PASS: Suture Field Dynamics v0.3")
    print("Delta(0)=0 computed, Delta(lambda=1) rank 32; m->Psi rank 16 at Pi_star,Pi_vac (Psi=0 => m=0); "
          "counts 53+37=90=26+64, DoF 4 (SD.15, SD.28-30); bracket rank 64, kernel 4 = span(pi~_a); "
          "k dim 10; orbit rank 10 at Pi_star,Pi_vac and 9 at regular Pi_iso with X_iso Pi_iso=0; "
          "Dirac inverse exact, physical correction 0, arbitrary {C,H_phys} absorbed by u_q")


if __name__ == "__main__":
    main()
