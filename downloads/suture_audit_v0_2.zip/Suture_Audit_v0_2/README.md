# Suture Audit v0.2 (Card 5 Suture Field + Card 5a Suture Field Dynamics)

Single source revision; the two cards advance together.

- `source/` — `common.tex`, `05_suture_field.tex`, `05a_suture_field_dynamics.tex`, and eight verifiers
  plus `verify_all.py`. (`verify_suture_field_dynamics_v0_1.py` is kept as the helper library for the v0_2 verifier.)
- `pdf/` — compiled cards (5 and 7 pages).
- `receipts/` — captured stdout of each verifier on 9 Nov 2026 (Python 3.13, sympy 1.14, numpy 2.5; sympy is
  used only for the optional symbolic minor in the image verifier).
- `RESIDUAL_LEDGER_v0_2.md` — what is closed, carried and open, with equation addresses.
- `SHA256SUMS` — hashes of every file above.

Run: `cd source && python3 verify_all.py` (each verifier runs in its own interpreter; exit 0 only if all print PASS).
Build: `pdflatex 05_suture_field.tex` and `pdflatex 05a_suture_field_dynamics.tex` in `source/` (run twice).

Boundary: the regular-branch condition rank D𝒮_Π = 16 and the image {b < |χ|} qualify every reduction claim.
No empirical comparison is asserted; calibration of χ is open (ledger R-5, R-6).
