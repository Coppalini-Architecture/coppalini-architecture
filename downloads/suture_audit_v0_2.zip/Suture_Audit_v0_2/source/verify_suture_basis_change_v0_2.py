"""Exact check of SF.4 -> SF.6 (Suture Field v0.2): the real Fourier basis change.

Everything is an explicit 8-vector in the address basis (e_inf, e_0..e_6) with entries in
Q(zeta_7) (polynomials mod x^6+...+1, Fraction coefficients).  cos(a) = (z^a+z^-a)/2.
Sines enter only as S_a := z^a - z^-a = 2i sin(a), so i never appears; the scaled vectors are
  c'_j = (cos(2 pi j k/7))_k,   S_j = (S_{jk})_k = 2i s'_j,   u' = (1,...,1),   e_inf.
Unnormalized lengths: <e_inf,e_inf> = 1, <u',u'> = 7, <c'_j,c'_j> = 7/2, <S_j,S_j> = -14
(= (2i)^2 * 7/2), which fix the normalizations in SF.4.

Checks
  G1  the 8 vectors are pairwise orthogonal with the diagonal Gram above (so they span V_8).
  T1  tau e_inf = e_inf and tau u' = u'          (the fixed block span(e_inf,u0): I_2).
  T2  tau c'_j = cos(th) c'_j - (S_th/4) S_j     (tau c = cos c + sin s).
  T3  tau S_j  = -S_th c'_j + cos(th) S_j        (tau s = -sin c + cos s).
        so tau acts as R_{2 pi j/7} = e^{(2 pi j/7)C} on (c_j,s_j), j = 1,2,3.
  P1  sigma: k -> -k fixes e_inf, u', c'_j and negates S_j  (= I_2 + D + D + D, D = diag(1,-1)).
  N   negative controls, each of which must be rejected by the same predicates:
        wrong angle (2 th), wrong fixed block (tau u' = 2u'), omitted e_inf in the Gram,
        wrong parity (sigma S_j = +S_j), and a Gram with <c',c'> = 3.
"""
from fractions import Fraction as Fr

P = 7


class Q:
    def __init__(self, c=None): self.c = [Fr(0)] * P if c is None else [Fr(x) for x in c]
    @staticmethod
    def zpow(m, coef=1):
        v = [Fr(0)] * P; v[m % P] = Fr(coef); return Q(v)
    @staticmethod
    def const(x): return Q.zpow(0, x)
    def __add__(s, o): return Q([a + b for a, b in zip(s.c, o.c)])
    def __sub__(s, o): return Q([a - b for a, b in zip(s.c, o.c)])
    def __neg__(s): return Q([-a for a in s.c])
    def __mul__(s, o):
        if not isinstance(o, Q): return Q([a * Fr(o) for a in s.c])
        v = [Fr(0)] * P
        for i, a in enumerate(s.c):
            if a:
                for j, b in enumerate(o.c):
                    if b: v[(i + j) % P] += a * b
        return Q(v)
    def red(s): t = s.c[6]; return tuple(s.c[i] - t for i in range(6))
    def __eq__(s, o): return s.red() == o.red()


def cos_(a): return (Q.zpow(a) + Q.zpow(-a)) * Fr(1, 2)
def S_(a): return Q.zpow(a) - Q.zpow(-a)
def zero(): return Q()

# addresses: index 0 = infinity, index 1+k = e_k (k in Z_7)
def vec(f_inf, f_k): return [f_inf] + [f_k(k) for k in range(7)]
def dot(u, v):
    t = zero()
    for a, b in zip(u, v): t = t + a * b
    return t
def tau(v): return [v[0]] + [v[1 + (k - 1) % 7] for k in range(7)]        # (tau v)_k = v_{k-1}
def sigma(v): return [v[0]] + [v[1 + (-k) % 7] for k in range(7)]
def lin(coefQ, v): return [coefQ * x for x in v]
def vadd(u, v): return [a + b for a, b in zip(u, v)]
def veq(u, v): return all(a == b for a, b in zip(u, v))

def vectors():
    one, z = Q.const(1), zero()
    e_inf = [one] + [z] * 7
    u = vec(z, lambda k: one)
    c = {j: vec(z, lambda k, j=j: cos_(j * k)) for j in (1, 2, 3)}
    S = {j: vec(z, lambda k, j=j: S_(j * k)) for j in (1, 2, 3)}
    return e_inf, u, c, S


def gram_ok(basis, diag):
    for i, v in enumerate(basis):
        for j, w in enumerate(basis):
            want = diag[i] if i == j else zero()
            if not (dot(v, w) == want): return False
    return True


def tau_blocks_ok(e_inf, u, c, S, mult=1, fixed=1):
    ok = veq(tau(e_inf), e_inf) and veq(tau(u), lin(Q.const(fixed), u))
    for j in (1, 2, 3):
        ct, St = cos_(mult * j), S_(mult * j)
        ok = ok and veq(tau(c[j]), vadd(lin(ct, c[j]), lin(-(St * Fr(1, 4)), S[j])))
        ok = ok and veq(tau(S[j]), vadd(lin(-St, c[j]), lin(ct, S[j])))
    return ok


def sigma_ok(e_inf, u, c, S, sign=-1):
    ok = veq(sigma(e_inf), e_inf) and veq(sigma(u), u)
    for j in (1, 2, 3):
        ok = ok and veq(sigma(c[j]), c[j]) and veq(sigma(S[j]), lin(Q.const(sign), S[j]))
    return ok


def main():
    e_inf, u, c, S = vectors()
    basis = [e_inf, u, c[1], S[1], c[2], S[2], c[3], S[3]]
    diag = [Q.const(1), Q.const(7)] + [x for _ in range(3) for x in (Q.const(Fr(7, 2)), Q.const(-14))]
    assert gram_ok(basis, diag)                                   # G1
    assert tau_blocks_ok(e_inf, u, c, S)                          # T1-T3
    assert sigma_ok(e_inf, u, c, S)                               # P1
    # tau^7 = I on every basis vector (order 7)
    for v in basis:
        w = v
        for _ in range(7): w = tau(w)
        assert veq(w, v)
    # N: negative controls
    assert not tau_blocks_ok(e_inf, u, c, S, mult=2)              # wrong angle
    assert not tau_blocks_ok(e_inf, u, c, S, fixed=2)             # wrong fixed block
    assert not gram_ok(basis, [Q.const(0)] + diag[1:])            # e_inf row mis-set
    assert not sigma_ok(e_inf, u, c, S, sign=+1)                  # wrong parity
    bad = list(diag); bad[2] = Q.const(3)
    assert not gram_ok(basis, bad)                                # wrong Gram
    print("PASS: Suture basis change SF.4->SF.6 v0.2 (exact, Q(zeta_7), explicit 8-vectors)")
    print("Gram diag(1,7,7/2,-14,...); tau=I on span(e_inf,u0), R_{2 pi j/7} on (c_j,s_j); "
          "sigma=I2+D+D+D; 5 negative controls rejected")


if __name__ == "__main__":
    main()
