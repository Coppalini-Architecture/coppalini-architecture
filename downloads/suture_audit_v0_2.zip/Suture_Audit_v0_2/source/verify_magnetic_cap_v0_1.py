"""Exact receipts for the magnetic cap of the suture map (chi = 1).

Claim: for rank-4 Pi with g = Pi^T eta Pi Lorentzian and F = Pi^T C Pi,
  (1 - b^2)(1 + e^2) = det(g + iF) / det(g)  >= 0,
where the eigenvalues of g^{-1}F are +-ib, +-e.  Hence b <= 1.
Checks (exact, Gaussian rationals): sign of det(g+iF) on integer samples,
the attaining witness (det = 0, b = 1), and rank DS = 15 there.
"""
from __future__ import annotations
import random
from fractions import Fraction as Fr

N, M = 8, 4


class Z:  # Gaussian rational
    def __init__(s, a=0, b=0): s.a, s.b = Fr(a), Fr(b)
    def __add__(s, o): return Z(s.a + o.a, s.b + o.b)
    def __sub__(s, o): return Z(s.a - o.a, s.b - o.b)
    def __mul__(s, o): return Z(s.a * o.a - s.b * o.b, s.a * o.b + s.b * o.a)
    def inv(s): d = s.a ** 2 + s.b ** 2; return Z(s.a / d, -s.b / d)
    def zero(s): return s.a == 0 and s.b == 0


def det(m):
    w = [row[:] for row in m]; n = len(w); t = Z(1)
    for c in range(n):
        p = next((r for r in range(c, n) if not w[r][c].zero()), None)
        if p is None: return Z(0)
        if p != c: w[c], w[p] = w[p], w[c]; t = t * Z(-1)
        t = t * w[c][c]; iv = w[c][c].inv()
        for r in range(c + 1, n):
            f = w[r][c] * iv
            w[r] = [x - f * y for x, y in zip(w[r], w[c])]
    return t


def rank(rows):
    w = [[Fr(x) for x in r] for r in rows]; k = 0
    for c in range(len(w[0])):
        p = next((r for r in range(k, len(w)) if w[r][c]), None)
        if p is None: continue
        w[k], w[p] = w[p], w[k]; d = w[k][c]; w[k] = [x / d for x in w[k]]
        for r in range(len(w)):
            if r != k and w[r][c]:
                f = w[r][c]; w[r] = [x - f * y for x, y in zip(w[r], w[k])]
        k += 1
        if k == len(w): break
    return k


ETA = [[0] * N for _ in range(N)]; CH = [[0] * N for _ in range(N)]
ETA[0][:2] = [-2, 1]; ETA[1][:2] = [1, 2]
for b in range(4): CH[2 * b][2 * b + 1] = -1; CH[2 * b + 1][2 * b] = 1
for b in (1, 2, 3): ETA[2 * b][2 * b] = ETA[2 * b + 1][2 * b + 1] = 1


def pull(P, B):
    return [[sum(P[r][a] * B[r][s] * P[s][c] for r in range(N) for s in range(N))
             for c in range(M)] for a in range(M)]


def jac(P):
    rows = []
    for B, sym in ((ETA, True), (CH, False)):
        for a in range(M):
            for c in range(a if sym else a + 1, M):
                row = [0] * (N * M)
                for r in range(N):
                    for s in range(N):
                        if B[r][s]:
                            row[r * M + a] += B[r][s] * P[s][c]
                            row[s * M + c] += P[r][a] * B[r][s]
                rows.append(row)
    return rows


def det_g_iF(P):
    g, f = pull(P, ETA), pull(P, CH)
    d = det([[Z(g[i][j], f[i][j]) for j in range(M)] for i in range(M)])
    dg = det([[Z(g[i][j]) for j in range(M)] for i in range(M)])
    return d, dg


def main():
    random.seed(0); n = 0
    for _ in range(20000):
        P = [[random.randint(-3, 3) for _ in range(M)] for _ in range(N)]
        d, dg = det_g_iF(P)
        g = pull(P, ETA)
        # Lorentzian (3,1): det g < 0 and leading-minor sign pattern via LDL
        if dg.a >= 0: continue
        # exactly one negative eigenvalue <=> det<0 with 3 positive; require sig (3,1)
        # (det<0 gives 1 or 3 negatives; exclude 3 via trace-free test on pivots)
        from fractions import Fraction
        w = [[Fraction(x) for x in r] for r in g]; neg = 0; ok = True
        for c in range(4):
            if w[c][c] == 0: ok = False; break
            if w[c][c] < 0: neg += 1
            for r in range(c + 1, 4):
                fct = w[r][c] / w[c][c]
                w[r] = [x - fct * y for x, y in zip(w[r], w[c])]
        if not ok or neg != 1: continue
        n += 1
        assert d.b == 0 and d.a <= 0, (P, d.a, d.b)   # det(g+iF) real, <= 0
    assert n > 500
    # attaining witness: W = span(e2, e3, e0, e4); t = e0 (G(t,t) = -2)
    Pw = [[0] * M for _ in range(N)]
    Pw[2][0] = 1; Pw[3][1] = 1; Pw[0][2] = 1; Pw[4][3] = 1
    g, f = pull(Pw, ETA), pull(Pw, CH)
    assert g == [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, -2, 0], [0, 0, 0, 1]]
    d, dg = det_g_iF(Pw)
    assert d.zero() and dg.a == -2          # (1-b^2)(1+e^2) = 0
    assert f[0][1] == -1 and sum(abs(f[i][j]) for i in range(4) for j in range(4)) == 2
    assert rank(jac(Pw)) == 15              # critical point of the suture map
    # sharpness of regular branch: Pi_star regular, b < 1
    Ps = [[-1, -2, 1, 0], [2, -1, 1, 0], [-1, -2, 1, -2], [-1, 1, -1, 0],
          [-1, 0, 0, -1], [0, 1, 1, -1], [2, 2, 1, -2], [-1, -1, 0, -1]]
    d, dg = det_g_iF(Ps)
    assert rank(jac(Ps)) == 16 and d.b == 0 and d.a / dg.a > 0
    print("PASS: magnetic cap v0.1")
    print(f"samples_sig31={n}; det(g+iF)<=0 on all; witness b=1,e=0,rank DS=15; Pi_star ratio>0")


if __name__ == "__main__":
    main()
