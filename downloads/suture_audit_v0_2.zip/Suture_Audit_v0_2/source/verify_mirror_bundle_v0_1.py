"""Receipts for Card 5 items: first summand and the mirror bundle.

Address basis: (e_inf, e_0..e_6) = (Gr, Li, Me, Ti, Hz, Si, Sc, Mo).
tau e_k = e_{k+1}; sigma: k -> -k fixes inf and 0.
Adapted basis: e_inf, u0 = 7^{-1/2} sum e_k, and for j=1,2,3
  c_j = sqrt(2/7) sum cos(2 pi j k/7) e_k,  s_j = sqrt(2/7) sum sin(2 pi j k/7) e_k.
Assumption (stated, not on the card text I had): D = diag(1,-1) on each transverse plane.
"""
from __future__ import annotations
import math
from fractions import Fraction as Fr

TOL = 1e-12
def mm(A, B): return [[sum(A[i][k] * B[k][j] for k in range(len(B))) for j in range(len(B[0]))] for i in range(len(A))]
def T(A): return [list(r) for r in zip(*A)]
def sub(A, B): return [[a - b for a, b in zip(r, s)] for r, s in zip(A, B)]
def nrm(A): return max(abs(x) for r in A for x in r)
def blk(*bs):
    n = sum(len(b) for b in bs); Z = [[0.0] * n for _ in range(n)]; o = 0
    for b in bs:
        for i, r in enumerate(b):
            for j, x in enumerate(r): Z[o + i][o + j] = x
        o += len(b)
    return Z
def eye(n): return [[1.0 if i == j else 0.0 for j in range(n)] for i in range(n)]
def R(t): return [[math.cos(t), -math.sin(t)], [math.sin(t), math.cos(t)]]
def mpow(A, w):
    P = eye(len(A))
    for _ in range(w): P = mm(P, A)
    return P

# address permutation matrices on (inf,0..6)
def perm(f):  # f maps address index -> image index ; matrix sends e_a -> e_f(a)
    P = [[0.0] * 8 for _ in range(8)]
    for a in range(8): P[f(a)][a] = 1.0
    return P
ptau = perm(lambda a: 0 if a == 0 else 1 + (a - 1 + 1) % 7)
psig = perm(lambda a: 0 if a == 0 else 1 + (-(a - 1)) % 7)

# adapted orthonormal basis (columns)
cols = [[1.0] + [0.0] * 7, [0.0] + [1 / math.sqrt(7)] * 7]
for j in (1, 2, 3):
    cols.append([0.0] + [math.sqrt(2 / 7) * math.cos(2 * math.pi * j * k / 7) for k in range(7)])
    cols.append([0.0] + [math.sqrt(2 / 7) * math.sin(2 * math.pi * j * k / 7) for k in range(7)])
B = T(cols)
assert nrm(sub(mm(T(B), B), eye(8))) < TOL

rho_tau = blk(eye(2), R(2 * math.pi / 7), R(4 * math.pi / 7), R(6 * math.pi / 7))
D = [[1.0, 0.0], [0.0, -1.0]]
assert nrm(sub(mm(mm(T(B), ptau), B), rho_tau)) < TOL        # rho_hat(tau) = I2+R+R+R
assert nrm(sub(mm(mm(T(B), psig), B), blk(eye(2), D, D, D))) < TOL   # sigma = I2+D^3

# first summand: weights of e_Li
u0 = cols[1]; e_Li = [0.0, 1.0] + [0.0] * 6
w_first = sum(e_Li[a] * u0[a] for a in range(8)) ** 2
assert abs(w_first - 1 / 7) < TOL and abs((1 - w_first) - 6 / 7) < TOL
assert Fr(1, 7) + Fr(6, 7) == 1                                   # exact bookkeeping

# root block and Hhat
r5 = math.sqrt(5)
G = [[-2.0, 1.0], [1.0, 2.0]]; C = [[0.0, -1.0], [1.0, 0.0]]
H = [[x / r5 for x in r] for r in G]
eta = blk(G, eye(2), eye(2), eye(2)); Ch = blk(C, C, C, C)
Hh = blk(H, D, D, D); Hroot = blk(H, eye(2), eye(2), eye(2)); Psig = blk(eye(2), D, D, D)
assert nrm(sub(Hh, mm(Hroot, Psig))) < TOL                       # Hhat = (H+I6) * P_sigma
assert nrm(sub(mm(mm(T(Hh), eta), Hh), eta)) < TOL               # Hhat is an eta-isometry
assert nrm(sub(mm(mm(T(Hh), Ch), Hh), [[-x for x in r] for r in Ch])) < TOL   # Hhat^T C Hhat = -C
assert nrm(sub(mm(mm(H, C), H), [[-x for x in r] for r in C])) < TOL          # HCH = -C
assert nrm(sub(mm(H, C), [[-x for x in r] for r in mm(C, H)])) < TOL          # HC = -CH
assert nrm(sub(mm(Hh, Hh), eye(8))) < TOL
# intertwining: Hhat rho(tau^w) = rho(tau^{-w}) Hhat for all w; commutes only for w = 0
for w in range(7):
    lhs = mm(Hh, mpow(rho_tau, w)); rhs = mm(mpow(rho_tau, (-w) % 7), Hh)
    assert nrm(sub(lhs, rhs)) < TOL
    comm = nrm(sub(lhs, mm(mpow(rho_tau, w), Hh)))
    assert (comm < TOL) == (w == 0)
print("PASS: mirror bundle v0.1")
print("first_summand=span(e_Gr,u0); e_Li weights 1/7 (first) + 6/7 (transverse); "
      "Hhat=(H+I6)P_sigma; Hhat rho(tau^w)=rho(tau^-w) Hhat; commutes iff w=0; "
      "Hhat^T eta Hhat=eta; Hhat^T C Hhat=-C")
