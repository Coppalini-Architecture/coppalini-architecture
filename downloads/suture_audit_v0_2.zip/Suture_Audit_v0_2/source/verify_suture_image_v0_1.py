"""Exact receipts for the image of the suture map (05a, SD.32-SD.34), chi = 1.

Claim (non-null and null cases together):
  im S_reg = { (h,f) : h Lorentzian (3,1), b(h,f) < 1 }.
Inclusion '<=' is the cap (verify_magnetic_cap_v0_1.py).  This file certifies '>=':

(1) Family.  For a in {1,7,41} (so x = sqrt((1+a^2)/2) is rational: 1, 5, 29) and
    (c,s) Pythagorean, Pi(a,c,s) has columns, in address coordinates (rows 0..7 =
    root, E1, E2, E3 planes)
        p0 = x e_0 + a e_6,   p1 = e_7,   p2 = e_2,   p3 = c e_3 + s e_4.
    Then h = diag(-1,1,1,1), f_01 = -a, f_23 = -c, so (b,e) = (|c|,|a|), and
    rank DS = 16 iff s != 0.  The 16x16 minor on a fixed column set equals
    -16 sqrt(2) s^3 (a^2+1)^(7/2) (sympy, checked below when sympy is present).
    Every non-null (h,f) is GL(4)-congruent to some (diag(-1,1,1,1), bω23 + eω01);
    rank DS and the pair are GL(4)-equivariant (S(Pi A) = A^T S(Pi) A), so each
    non-null (h,f) with b<1 has a regular preimage.  c = +-1 (s = 0) gives b = 1, rank 15.
(2) Null witness.  In Q(sqrt2, sqrt3): x0 = sqrt6/2, x1 = sqrt6(4-sqrt2)/24, y1 = -sqrt3/6,
    b = sqrt2/4, with
        p0 = x0 e_0 + e_3 + e_6,   p1 = x1 e_0 + y1 e_1 + e_3 + b e_7,
        p2 = e_2,                  p3 = e_4.
    Exactly: h = diag(-1,1,1,1), f = e^0^e^2 + e^1^e^2 (nonzero, null, b = e = 0) and
    rank DS = 16.  All nonzero null f with Lorentzian h form one GL(4)-orbit of
    (h, f) up to the scalar k (boost rescales k, a reflection flips its sign).
(3) f = 0: Pi_vac (a = 0 member) is regular.
"""
from __future__ import annotations
from fractions import Fraction as Fr

N, M = 8, 4

# ---------- exact field Q(sqrt2, sqrt3): basis 1, r2, r3, r6 ----------
class QF:
    def __init__(s, a=0, b=0, c=0, d=0): s.v = (Fr(a), Fr(b), Fr(c), Fr(d))
    @staticmethod
    def co(x): return x if isinstance(x, QF) else QF(x)
    def __add__(s, o): o = QF.co(o); return QF(*[x + y for x, y in zip(s.v, o.v)])
    __radd__ = __add__
    def __neg__(s): return QF(*[-x for x in s.v])
    def __sub__(s, o): return s + (-QF.co(o))
    def __rsub__(s, o): return QF.co(o) - s
    def __mul__(s, o):
        o = QF.co(o); a, b, c, d = s.v; e, f, g, h = o.v
        return QF(a*e + 2*b*f + 3*c*g + 6*d*h,
                  a*f + b*e + 3*c*h + 3*d*g,
                  a*g + c*e + 2*b*h + 2*d*f,
                  a*h + d*e + b*g + c*f)
    __rmul__ = __mul__
    def conj(s, f2, f3):
        a, b, c, d = s.v
        return QF(a, b * (-1 if f2 else 1), c * (-1 if f3 else 1), d * (-1 if f2 != f3 else 1))
    def inv(s):
        y = s.conj(1, 0) * s.conj(0, 1) * s.conj(1, 1)
        n = s * y
        assert n.v[1] == n.v[2] == n.v[3] == 0 and n.v[0] != 0
        return y * (1 / n.v[0])
    def __truediv__(s, o): return s * QF.co(o).inv()
    def iszero(s): return all(x == 0 for x in s.v)
    def __eq__(s, o): return (s - QF.co(o)).iszero()
    def __bool__(s): return not s.iszero()
    def __hash__(s): return hash(s.v)

R2, R3, R6 = QF(0, 1), QF(0, 0, 1), QF(0, 0, 0, 1)

def rank(rows):
    w = [[x for x in r] for r in rows]; k = 0
    for c in range(len(w[0])):
        p = next((r for r in range(k, len(w)) if w[r][c]), None)
        if p is None: continue
        w[k], w[p] = w[p], w[k]
        d = w[k][c]
        w[k] = [x / d if isinstance(x, QF) else QF.co(x) / d for x in w[k]] if isinstance(d, QF) else [x / d for x in w[k]]
        for r in range(len(w)):
            if r != k and w[r][c]:
                f = w[r][c]; w[r] = [x - f * y for x, y in zip(w[r], w[k])]
        k += 1
        if k == len(w): break
    return k

ETA = [[0] * N for _ in range(N)]; CH = [[0] * N for _ in range(N)]
ETA[0][:2] = [-2, 1]; ETA[1][:2] = [1, 2]
for b in range(4): CH[2 * b][2 * b + 1] = -1; CH[2 * b + 1][2 * b] = 1
for b in (1, 2, 3): ETA[2 * b][2 * b] = ETA[2 * b + 1][2 * b + 1] = 1

def pull(P, B):
    z = None
    out = [[0] * M for _ in range(M)]
    for a in range(M):
        for c in range(M):
            t = 0
            for r in range(N):
                for s in range(N):
                    if B[r][s]: t = t + P[r][a] * B[r][s] * P[s][c]
            out[a][c] = t
    return out

def jac(P):
    rows = []
    for B, sym in ((ETA, True), (CH, False)):
        for a in range(M):
            for c in range(a if sym else a + 1, M):
                row = [0] * (N * M)
                for r in range(N):
                    for s in range(N):
                        if B[r][s]:
                            row[r * M + a] = row[r * M + a] + B[r][s] * P[s][c]
                            row[s * M + c] = row[s * M + c] + P[r][a] * B[r][s]
                rows.append(row)
    return rows

def eqm(A, B): return all((QF.co(A[i][j]) - QF.co(B[i][j])).iszero() for i in range(M) for j in range(M))

def family(a, c, s, x):
    P = [[Fr(0)] * M for _ in range(N)]
    P[0][0] = Fr(x); P[6][0] = Fr(a); P[7][1] = Fr(1); P[2][2] = Fr(1)
    P[3][3] = Fr(c); P[4][3] = Fr(s)
    return P

def main():
    eta4 = [[-1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]]
    # (1) family
    for a, x in ((1, 1), (7, 5), (41, 29)):
        assert 2 * x * x == 1 + a * a
        for c, s in ((Fr(3, 5), Fr(4, 5)), (Fr(4, 5), Fr(3, 5)), (Fr(0), Fr(1)),
                     (Fr(5, 13), Fr(12, 13)), (Fr(-8, 17), Fr(15, 17))):
            P = family(a, c, s, x)
            assert c * c + s * s == 1
            assert pull(P, ETA) == eta4
            f = pull(P, CH)
            assert f[0][1] == -a and f[2][3] == -c
            assert all(f[i][j] == -f[j][i] for i in range(M) for j in range(M))
            assert sum(abs(f[i][j]) for i in range(M) for j in range(M) if (i, j) not in ((0, 1), (1, 0), (2, 3), (3, 2))) == 0
            assert rank(jac(P)) == 16
        # b = 1 end of the family: critical
        assert rank(jac(family(a, Fr(1), Fr(0), x))) == 15
        assert rank(jac(family(a, Fr(-1), Fr(0), x))) == 15
    # (3) F = 0 member (a=1, c=0 gives b=0,e=1; F=0 is Pi_vac)
    Pv = [[0] * M for _ in range(N)]
    Pv[0][0] = Pv[2][1] = Pv[4][2] = Pv[6][3] = 1
    assert rank(jac(Pv)) == 16
    # (2) null witness
    x0 = R6 * Fr(1, 2)
    x1 = R6 * (4 - R2) * Fr(1, 24)
    y1 = -(R3 * Fr(1, 6))
    bb = R2 * Fr(1, 4)
    P = [[QF(0)] * M for _ in range(N)]
    P[0][0] = x0; P[3][0] = QF(1); P[6][0] = QF(1)
    P[0][1] = x1; P[1][1] = y1; P[3][1] = QF(1); P[7][1] = bb
    P[2][2] = QF(1)
    P[4][3] = QF(1)
    h = pull(P, ETA); f = pull(P, CH)
    assert eqm(h, eta4)
    want = [[0] * M for _ in range(M)]
    want[0][2] = 1; want[2][0] = -1; want[1][2] = 1; want[2][1] = -1
    assert eqm(f, want)
    assert rank(jac(P)) == 16
    # negative controls: a perturbed witness must fail at least one exact assertion
    P2 = [r[:] for r in P]; P2[7][1] = bb + Fr(1, 100)
    assert not eqm(pull(P2, ETA), eta4)
    P3 = [r[:] for r in P]; P3[4][3] = QF(0)
    assert rank(jac(P3)) < 16 or not eqm(pull(P3, ETA), eta4)
    # symbolic minor, if sympy is available
    try:
        import sympy as sp
        a_, c_, s_ = sp.symbols('a c s', real=True)
        etaS = sp.Matrix(ETA); CS = sp.Matrix(CH)
        Pm = sp.zeros(8, 4)
        Pm[0, 0] = sp.sqrt((1 + a_ ** 2) / 2); Pm[6, 0] = a_; Pm[7, 1] = 1; Pm[2, 2] = 1
        Pm[3, 3] = c_; Pm[4, 3] = s_
        J = sp.zeros(16, 32)
        for k in range(32):
            d = sp.zeros(8, 4); d[k // 4, k % 4] = 1
            hh = d.T * etaS * Pm + Pm.T * etaS * d; ff = d.T * CS * Pm + Pm.T * CS * d
            J[:, k] = sp.Matrix([hh[i, j] for i in range(4) for j in range(i, 4)] +
                                [ff[i, j] for i in range(4) for j in range(i + 1, 4)])
        cols = [0, 1, 2, 3, 5, 6, 7, 9, 10, 11, 13, 15, 17, 19, 21, 29]
        det = sp.simplify(J[:, cols].det())
        assert sp.simplify(det + 16 * sp.sqrt(2) * s_ ** 3 * (a_ ** 2 + 1) ** sp.Rational(7, 2)) == 0
        sym = "symbolic minor = -16 sqrt2 s^3 (a^2+1)^(7/2) verified"
    except ImportError:
        sym = "sympy absent: symbolic minor not rechecked"
    print("PASS: suture image v0.1")
    print("family regular iff s!=0 (rank16/15 at b=1), null witness exact (rank 16), F=0 regular; " + sym)


if __name__ == "__main__":
    main()
