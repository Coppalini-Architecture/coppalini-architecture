"""Exact receipt for Suture Field v0.2 (Card 5).

Over Q[zeta_7, i].  Carries the v0.1 carrier checks and adds:
  * the explicit SF.4 -> SF.6 basis change (verify_suture_basis_change_v0_2.py);
  * the Pi -> (g, F_sol) pullbacks computed on integer sample coframes, including
    cyclic invariance for all r in Z_7 and the mirror typing
    g(Hbar Pi) = g(Pi),  F(Hbar Pi) = -F(Pi)  with H = G/sqrt5 handled exactly through
    H^T G H = G^3/5 and H^T C H = G^T C G/5;
  * the retyping: Hhat rho(tau^w) = rho(tau^-w) Hhat, commuting only for w = 0;
  * source guards for the v0.2 edits (Pi-bar, E^sigma, Gr-Ubar, single A_8, L_Pi, J_em, U_alpha).
"""

from __future__ import annotations

from fractions import Fraction
from pathlib import Path

import verify_suture_basis_change_v0_2 as basis_change
import verify_z7_lorentz_extension_v0_1 as z7
from verify_z7_lorentz_extension_v0_1 import (
    C,
    D,
    G_ROOT,
    I2,
    CEntry,
    Zeta7,
    cblock_diag,
    cfrom_int_matrix,
    cidentity,
    cmatrix_mul,
    ctranspose,
    mmul,
    mscale,
    phase,
    transverse_rotation,
)

ROOT = Path(__file__).resolve().parent


def block4(a, b, c, d):
    return cblock_diag(cblock_diag(a, b), cblock_diag(c, d))


def crat(value: Fraction) -> CEntry:
    return CEntry.from_zeta(Zeta7.one().scale(Fraction(value)))


def cfrom_rat_matrix(rows) -> tuple:
    return tuple(tuple(crat(Fraction(x)) for x in row) for row in rows)


def rho(r: int):
    i2 = cidentity(2)
    return block4(i2, transverse_rotation(r), transverse_rotation(2 * r), transverse_rotation(3 * r))


def verify_real_fourier_character() -> None:
    weights = (0, 0, 1, 6, 2, 5, 3, 4)
    assert sorted(weights) == [0, 0, 1, 2, 3, 4, 5, 6]
    assert all(phase(weight).power(7) == Zeta7.one() for weight in weights)
    assert all(phase(weight) != Zeta7.one() for weight in (1, 2, 3, 4, 5, 6))


def forms():
    i2 = cidentity(2)
    eta = block4(cfrom_int_matrix(G_ROOT), i2, i2, i2)
    chat = block4(*([cfrom_int_matrix(C)] * 4))
    return eta, chat


def mirror_conjugates():
    """H^T eta H and H^T C H for H = G/sqrt5 (+) D (+) D (+) D, computed blockwise and exactly."""
    ggg = mmul(mmul(G_ROOT, G_ROOT), G_ROOT)          # G^T G G = G^3  (G symmetric)
    gcg = mmul(mmul(G_ROOT, C), G_ROOT)
    root_eta = cfrom_rat_matrix([[Fraction(v, 5) for v in row] for row in ggg])
    root_c = cfrom_rat_matrix([[Fraction(v, 5) for v in row] for row in gcg])
    d = cfrom_int_matrix(D)
    c = cfrom_int_matrix(C)
    i2 = cidentity(2)
    dtd = cmatrix_mul(cmatrix_mul(ctranspose(d), i2), d)
    dcd = cmatrix_mul(cmatrix_mul(ctranspose(d), c), d)
    return block4(root_eta, dtd, dtd, dtd), block4(root_c, dcd, dcd, dcd)


def verify_eight_dimensional_carrier() -> None:
    eta, chat = forms()
    assert mmul(G_ROOT, G_ROOT) == mscale(5, I2)
    assert mmul(mmul(G_ROOT, C), G_ROOT) == mscale(-5, C)
    assert mmul(mmul(G_ROOT, G_ROOT), G_ROOT) == mscale(5, G_ROOT)
    neg = tuple(tuple(-x for x in row) for row in chat)

    for r in range(7):
        rr = rho(r)
        rinv = rho(-r)
        assert cmatrix_mul(ctranspose(rr), rr) == cidentity(8)
        assert cmatrix_mul(cmatrix_mul(ctranspose(rr), eta), rr) == eta
        assert cmatrix_mul(cmatrix_mul(ctranspose(rr), chat), rr) == chat
        assert cmatrix_mul(rr, rinv) == cidentity(8)
    gen = rho(1)
    power = cidentity(8)
    for _ in range(7):
        power = cmatrix_mul(power, gen)
    assert power == cidentity(8)

    # mirror: isometry of eta, reverses C
    h_eta, h_c = mirror_conjugates()
    assert h_eta == eta and h_c == neg
    # retyping: Hhat rho(tau^w) = rho(tau^-w) Hhat on the transverse blocks (the root block of rho is I_2),
    # and Hhat commutes with rho(tau^w) only for w = 0.
    d = cfrom_int_matrix(D)
    for w in range(7):
        for m in (1, 2, 3):
            lhs = cmatrix_mul(d, transverse_rotation(m * w))
            assert lhs == cmatrix_mul(transverse_rotation(-m * w), d)
            commutes = lhs == cmatrix_mul(transverse_rotation(m * w), d)
            assert commutes == (w == 0)


SAMPLES = (
    # Pi_star of Suture Field Dynamics (regular branch), Pi_vac, and two further integer coframes
    ((-1, -2, 1, 0), (2, -1, 1, 0), (-1, -2, 1, -2), (-1, 1, -1, 0),
     (-1, 0, 0, -1), (0, 1, 1, -1), (2, 2, 1, -2), (-1, -1, 0, -1)),
    ((1, 0, 0, 0), (0, 0, 0, 0), (0, 1, 0, 0), (0, 0, 0, 0),
     (0, 0, 1, 0), (0, 0, 0, 0), (0, 0, 0, 1), (0, 0, 0, 0)),
    ((1, 2, 0, 1), (0, 1, 3, 0), (2, 0, 1, 1), (1, 1, 0, 2),
     (0, 3, 1, 0), (1, 0, 2, 1), (3, 1, 0, 0), (0, 2, 1, 1)),
    ((2, 0, 1, 0), (1, 1, 0, 3), (0, 2, 1, 1), (1, 0, 2, 0),
     (3, 1, 0, 1), (0, 0, 1, 2), (1, 2, 0, 0), (0, 1, 3, 1)),
)


def pullback(pi, form):
    return cmatrix_mul(cmatrix_mul(ctranspose(pi), form), pi)


def verify_pullback_typing() -> None:
    eta, chat = forms()
    h_eta, h_c = mirror_conjugates()
    for sample in SAMPLES:
        pi = tuple(tuple(CEntry.integer(x) for x in row) for row in sample)
        g = pullback(pi, eta)
        f = pullback(pi, chat)
        # symmetric / antisymmetric contractions
        assert g == ctranspose(g)
        assert all(f[i][j] == -f[j][i] for i in range(4) for j in range(4))
        for r in range(7):
            pr = cmatrix_mul(rho(r), pi)                      # Pi^(r)
            assert pullback(pr, eta) == g                     # SF.12
            assert pullback(pr, chat) == f                    # SF.17, first half
        # mirror field Pibar = Hhat Pi: g(Pibar) = Pi^T (H^T eta H) Pi, F(Pibar) = Pi^T (H^T C H) Pi
        assert pullback(pi, h_eta) == g                       # SF.13a
        neg_f = tuple(tuple(-x for x in row) for row in f)
        assert pullback(pi, h_c) == neg_f                     # SF.17, second half
    # negative control: a rotation with the wrong weight does not preserve F on a transverse-only coframe
    pi = tuple(tuple(CEntry.integer(x) for x in row) for row in SAMPLES[2])
    bad = block4(cidentity(2), transverse_rotation(1), transverse_rotation(1), transverse_rotation(1))
    assert pullback(cmatrix_mul(bad, pi), chat) == pullback(pi, chat)   # equal weights also preserve C ...
    bad_eta = block4(cfrom_int_matrix(G_ROOT), cidentity(2), cidentity(2), cfrom_int_matrix(D))
    assert pullback(pi, bad_eta) != pullback(pi, eta)                    # ... but a wrong metric block is detected


def verify_source() -> None:
    source = (ROOT / "05_suture_field.tex").read_text(encoding="utf-8")
    common = (ROOT / "common.tex").read_text(encoding="utf-8")
    required = (
        "\\Pi=\\Pi^A{}_{\\mu}",
        "\\Pi_x:T_xM\\hookrightarrow E_x",
        "\\Pi:TM\\xrightarrow{\\ \\cong\\ }L_\\Pi",
        "\\mathcal V_8:=\\RR[\\mathcal A_8]",
        "\\sharedmatching",
        "\\tau\\mathsf M_r=\\mathsf M_{r+1}",
        "\\mathcal V_8=\\Span(e_\\infty,u_0)",
        "\\hatrho(\\tau^r)=I_2\\oplus U_{2\\pi r/7}",
        "\\hateta:=G\\oplus I_2\\oplus I_2\\oplus I_2",
        "\\hatC:=C\\oplus C\\oplus C\\oplus C",
        "$\\mathsf{Gr}$--$\\Ubar$ carrier",
        "weight $1/7$ on $u_0$ and $6/7$ on the transverse planes",
        "E^\\sigma:=P\\times_{\\hatrho\\circ\\sigma}\\mathcal V_8",
        "\\bar\\Pi:=\\hatH\\Pi\\in\\Omega^1(M,E^\\sigma)",
        "\\bar\\Pi^{(w)}=\\hatrho(\\tau^{-w})\\bar\\Pi=\\hatH\\Pi^{(w)}",
        "g(\\bar\\Pi)=g(\\Pi)",
        "\\Fsol(\\bar\\Pi)=-\\Fsol(\\Pi)",
        "\\Fsol:=\\frac12\\hatC_{AB}\\Pi^A\\wedge\\Pi^B",
        "F_{\\rm em}:=\\chi\\Fsol",
        "dF_{\\rm em}=0",
        "d\\star_gF_{\\rm em}=\\mu_0\\star_gJ_{\\rm em}",
        "W^{(7)}_\\gamma=\\hatrho(\\tau^{w_\\gamma})",
        "\\sharedoccurrence{SF.25}{SF.26}",
        "g=\\Pi^*\\hateta",
        "\\Fsol=\\Pi^*\\hatC",
    )
    assert all(token in source for token in required), [t for t in required if t not in source]
    forbidden = (
        "\\Pi^\\mu",                  # index collision
        "=Span(",                      # missing backslash
        "\\mathcal A_8=",              # defined once, in common.tex
        "R_\\alpha", "R_{2\\pi",       # Ricci vs rotation
        "\\star_gJ.",                  # bare current
        "gravity--light split carrier",
        "\\varnothing", "unified field theory",
    )
    lowered = source.lower()
    assert not [t for t in forbidden if t.lower() in lowered], [t for t in forbidden if t.lower() in lowered]
    assert "\\mathcal A_8:=" in common and "HC=-CH,\\qquad HCH=-C" in common
    assert "\\oint_\\gamma A" in source


def main() -> None:
    z7.main()
    verify_real_fourier_character()
    verify_eight_dimensional_carrier()
    basis_change.main()
    verify_pullback_typing()
    verify_source()
    print("PASS: Suture Field v0.2")
    print(
        "carrier=R[A8]; basis_change=SF.4->SF.6 exact; Z7_metric_phase_mirror=exact; "
        "mirror=Hhat:E->E^sigma (commutes iff w=0); Pi_to_g_and_Fsol=computed on 4 coframes"
    )


if __name__ == "__main__":
    main()
