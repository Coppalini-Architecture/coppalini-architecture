"""Receipts: CHSH over root-algebra reflections; C is the commutator of reflections.

H_theta = cos2t*sz + sin2t*sx  (real, H^2 = I, 'reader' reflection, 2T-1 = cos2t on Malus).
Checks (float, tol 1e-12): H_a H_b = cos2D I + sin2D C; [H_a,H_b] = 2 sin2D C;
S^2 = 4 I - [A,A'] (x) [B,B'] for A,A',B,B' reflections; E(a,b) = cos 2(a-b) on the real
Bell state; CHSH = 2 sqrt 2 at the 45-degree settings; local deterministic maximum = 2.
"""
import itertools
import math

TOL = 1e-12
I2 = [[1.0, 0.0], [0.0, 1.0]]
C = [[0.0, -1.0], [1.0, 0.0]]


def mm(A, B):
    return [[sum(A[i][k] * B[k][j] for k in range(len(B))) for j in range(len(B[0]))] for i in range(len(A))]


def add(A, B, s=1.0):
    return [[a + s * b for a, b in zip(r, t)] for r, t in zip(A, B)]


def sc(A, s):
    return [[s * x for x in r] for r in A]


def kron(A, B):
    return [[A[i // 2][j // 2] * B[i % 2][j % 2] for j in range(4)] for i in range(4)]


def err(A, B):
    return max(abs(x - y) for r, t in zip(A, B) for x, y in zip(r, t))


def H(t):
    return [[math.cos(2 * t), math.sin(2 * t)], [math.sin(2 * t), -math.cos(2 * t)]]


def comm(X, Y):
    return add(mm(X, Y), mm(Y, X), -1.0)


def main():
    for a, b in itertools.product((0.0, 0.3, 0.9, 1.7), (0.1, 0.5, 1.2, -0.4)):
        d = a - b
        assert err(mm(H(a), H(a)), I2) < TOL
        assert err(mm(H(a), H(b)), add(sc(I2, math.cos(2 * d)), sc(C, math.sin(2 * d)))) < TOL
        assert err(comm(H(a), H(b)), sc(C, 2 * math.sin(2 * d))) < TOL
    A, Ap, B, Bp = H(0.0), H(math.pi / 4), H(math.pi / 8), H(-math.pi / 8)
    S = add(kron(A, add(B, Bp)), kron(Ap, add(B, Bp, -1.0)))
    rhs = add(sc(kron(I2, I2), 4.0), kron(comm(A, Ap), comm(B, Bp)), -1.0)
    assert err(mm(S, S), rhs) < TOL
    phi = [1 / math.sqrt(2), 0.0, 0.0, 1 / math.sqrt(2)]
    ev = lambda M: sum(phi[i] * sum(M[i][j] * phi[j] for j in range(4)) for i in range(4))
    for x, y in itertools.product((0.0, 0.3, 0.9), (0.1, 0.5, 1.2)):
        assert abs(ev(kron(H(x), H(y))) - math.cos(2 * (x - y))) < TOL
    assert abs(ev(S) - 2 * math.sqrt(2)) < TOL
    local = max(abs(a * (b + bp) + ap * (b - bp)) for a, ap, b, bp in itertools.product((1, -1), repeat=4))
    assert local == 2
    # C (x) C has norm 1, so ||S||^2 <= 4 + 4|sin2D_A sin2D_B| <= 8
    print("PASS: CHSH over root reflections v0.1")
    print("[H_a,H_b]=2 sin2(a-b) C; S^2=4I-[A,A']x[B,B']; E=cos2(a-b); CHSH=2sqrt2; local max=2")


if __name__ == "__main__":
    main()
