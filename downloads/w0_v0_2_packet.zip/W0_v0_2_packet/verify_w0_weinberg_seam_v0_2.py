#!/usr/bin/env python3
"""W-0 v0.2: exact Higgs-vacuum and Weinberg-seam card.

Declared convention: Q = T3 + Y, Y_phi = 1/2, phi_0 = (0,v/sqrt(2))^T,
with positive supplied g, gprime, v.  Arithmetic is exact SymPy; no floats
or empirical inputs occur here.
"""

from __future__ import annotations

import sympy as sp


checks: list[tuple[str, str]] = []


def zero(value: sp.Matrix | sp.Expr) -> bool:
    if isinstance(value, sp.MatrixBase):
        return all(sp.simplify(entry) == 0 for entry in value)
    return sp.simplify(value) == 0


def same(left: sp.Matrix | sp.Expr, right: sp.Matrix | sp.Expr) -> bool:
    return zero(left - right)


def nonzero(value: sp.Matrix | sp.Expr) -> bool:
    if isinstance(value, sp.MatrixBase):
        return any(sp.simplify(entry) != 0 for entry in value)
    return sp.simplify(value) != 0


def check(identifier: str, statement: str, condition: bool) -> None:
    if not condition:
        raise AssertionError(f"{identifier} failed: {statement}")
    checks.append((identifier, statement))
    print(f"[{identifier}] PASS  {statement}")


def wedge2(matrix: sp.Matrix) -> sp.Matrix:
    """Induced map on 12,13,14,23,24,34 wedge coordinates."""
    pairs = ((0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3))
    return sp.Matrix(
        6,
        6,
        lambda row, col: sp.simplify(
            matrix[pairs[row][0], pairs[col][0]]
            * matrix[pairs[row][1], pairs[col][1]]
            - matrix[pairs[row][0], pairs[col][1]]
            * matrix[pairs[row][1], pairs[col][0]]
        ),
    )


g, gp, v = sp.symbols("g gprime v", positive=True, nonzero=True)
w1, w2, w3, b = sp.symbols("W1 W2 W3 B", real=True)
n2 = g**2 + gp**2
n = sp.sqrt(n2)
c_w, s_w = g / n, gp / n

# 1. Native bracket office.
bracket = sp.Matrix(
    [[0, 0, 0, 1, 0, 0], [0, -1, 0, 0, 0, 0], [1, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0]]
)
check("W0-1", "beta_EW has rank 3 and kernel dimension 3", bracket.rank() == 3 and len(bracket.nullspace()) == 3)

r_neutral = sp.Matrix([[c_w, -s_w], [s_w, c_w]])  # (W3,B) -> (Z,A)
check("W0-2", "R_W is orientation-preserving and orthogonal", same(r_neutral * r_neutral.T, sp.eye(2)) and sp.simplify(r_neutral.det() - 1) == 0)

r_four = sp.eye(4)
r_four[2, 2], r_four[2, 3] = c_w, -s_w
r_four[3, 2], r_four[3, 3] = s_w, c_w
bracket_za = sp.simplify(r_four * bracket * wedge2(r_four.inv()))
expected_bracket_za = sp.Matrix(
    [[0, 0, 0, c_w, s_w, 0], [0, -c_w, -s_w, 0, 0, 0], [c_w, 0, 0, 0, 0, 0], [s_w, 0, 0, 0, 0, 0]]
)
check("W0-3", "the bracket rewrites exactly in (T1,T2,Z,A) coordinates", same(bracket_za, expected_bracket_za))

# 2. Higgs representation and vacuum: the mass operator is derived here.
sigma1 = sp.Matrix([[0, 1], [1, 0]])
sigma2 = sp.Matrix([[0, -sp.I], [sp.I, 0]])
sigma3 = sp.Matrix([[1, 0], [0, -1]])
t1, t2, t3 = sigma1 / 2, sigma2 / 2, sigma3 / 2
y_phi = sp.eye(2) / 2
q_em = t3 + y_phi
phi0 = sp.Matrix([0, v / sp.sqrt(2)])
gauge_action = g * (w1 * t1 + w2 * t2 + w3 * t3) + gp * b * y_phi
kinetic_vacuum = sp.simplify(((gauge_action * phi0).conjugate().T * (gauge_action * phi0))[0])
expected_kinetic = v**2 * (g**2 * (w1**2 + w2**2) + (g * w3 - gp * b) ** 2) / 8
fields = sp.Matrix([w1, w2, w3, b])
derived_mass = sp.hessian(kinetic_vacuum, fields)
declared_mass = v**2 * sp.Matrix(
    [[g**2, 0, 0, 0], [0, g**2, 0, 0], [0, 0, g**2, -g * gp], [0, 0, -g * gp, gp**2]]
) / 4
check("W0-4", "the Higgs kinetic term at phi_0 yields the declared charged/neutral quadratic form", same(kinetic_vacuum, expected_kinetic))
check("W0-5", "the Hessian of the derived quadratic form equals the displayed M_EW^2", same(derived_mass, declared_mass))

check("W0-6", "M_EW^2 has rank 3 and the photon kernel is one-dimensional", declared_mass.rank() == 3 and len(declared_mass.nullspace()) == 1 and zero(declared_mass * sp.Matrix([0, 0, gp, g])))
m_neutral = sp.Matrix([[g**2, -g * gp], [-g * gp, gp**2]])
photon, z_direction = sp.Matrix([gp, g]), sp.Matrix([g, -gp])
check("W0-7", "the photon and Z directions are exact neutral eigenvectors", zero(m_neutral * photon) and same(m_neutral * z_direction, n2 * z_direction))
check("W0-8", "R_W diagonalizes the neutral quadratic form as (Z,A)", same(r_neutral * m_neutral * r_neutral.T, sp.diag(n2, 0)))

m_w, m_z = g * v / 2, v * n / 2
check("W0-9", "the declared tree-level identities e = g s_W = g' c_W and m_W/m_Z = c_W hold", sp.simplify(g * s_w - gp * c_w) == 0 and sp.simplify(m_w / m_z - c_w) == 0)

check("W0-10", "Q_em is diag(1,0) on the Higgs doublet and annihilates phi_0", same(q_em, sp.diag(1, 0)) and zero(q_em * phi0))
photon_connection_action = g * gp * t3 + gp * g * y_phi
check("W0-11", "the photon connection direction (W3,B)=(g',g) acts by gg' Q_em and annihilates phi_0", same(photon_connection_action, g * gp * q_em) and zero(photon_connection_action * phi0))

# Deliberate failing cases: each is rejected inside the declared convention.
wrong_rotation = sp.Matrix([[c_w, s_w], [-s_w, c_w]])
wrong_offdiag = sp.simplify((wrong_rotation * m_neutral * wrong_rotation.T)[0, 1])
check("N1", "REJECTED as expected: opposite-sign neutral map fails to diagonalize at exact g:g'=3:4", nonzero(wrong_offdiag.subs({g: 3, gp: 4})))
check("N2", "REJECTED as expected: the massive Z direction is not the photon null direction", nonzero(m_neutral * z_direction))
check("N3", "REJECTED as expected: equal rank does not identify bracket and mass operators because their kernels have dimensions 3 and 1", len(bracket.nullspace()) != len(declared_mass.nullspace()))
mixed_charge = t3 + y_phi / 2
check("N4", "REJECTED as expected: Q = T3 + Y/2 paired with Y_phi = 1/2 fails to stabilize phi_0", nonzero(mixed_charge * phi0))

print()
print("BOUNDARY: exact tree-level consequences of the declared Higgs representation, vacuum, convention, and supplied g, gprime, v.")
print("  carried: finite-dimensional bracket rewrite, kinetic derivation, vacuum stabilizer, and mass diagonalization")
print("  held: numerical theta_W or mass prediction, empirical comparison, running/scheme effects, and Architecture-to-particle identification")
print(f"checks: {len(checks)}/{len(checks)} satisfied")
print("OVERALL: PASS")
