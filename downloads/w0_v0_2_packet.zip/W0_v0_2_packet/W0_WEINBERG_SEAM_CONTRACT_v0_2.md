# W-0 · Weinberg seam contract · v0.2

**Status:** local revision of W-0 v0.1.  v0.1 remains preserved.

## Delta

W0-8 is replaced by an explicit matrix calculation on the Higgs doublet.  The mass matrix is now derived in the executable card from \((D_\mu\phi_0)^\dagger D^\mu\phi_0\), rather than only received as the displayed quadratic operator.  W0-3 is relabelled as an exact coordinate rewrite: rank and kernel preservation are consequences of its invertibility, rather than an independent result.  The manifest binds the receipt as well as the contract and verifier.

## Jurisdiction

The declared tree-level model uses

\[
Q_{\rm em}=T_3+Y,\qquad
Y_\phi=\tfrac12,\qquad
\phi_0=\frac1{\sqrt2}\binom0v,
\qquad g,g',v>0.
\]

The alternate convention \(Q=T_3+Y/2,\;Y_\phi=1\) is equivalent after a corresponding rescaling of hypercharge and its coupling.  This card carries the first convention throughout.

## Exact statements

1. \(\beta_{\rm EW}\) has rank 3 and kernel dimension 3.
2. The Weinberg map rewrites that bracket in \((T_1,T_2,Z,A)\) coordinates exactly.  This is a coordinate identity.
3. The declared Higgs representation and vacuum give

   \[
   (D_\mu\phi_0)^\dagger D^\mu\phi_0
   =\frac{v^2}{8}\left[g^2\bigl((W^1)^2+(W^2)^2\bigr)+(gW^3-g'B)^2\right].
   \]

   Its Hessian in \((W^1,W^2,W^3,B)\) is the stated \(\mathsf M^2_{\rm EW}\).
4. \(Q_{\rm em}\) is \(\operatorname{diag}(1,0)\) on the scalar doublet and annihilates \(\phi_0\).  The photon connection direction \((W^3,B)=(g',g)\) acts by \(gg'Q_{\rm em}\) and also annihilates \(\phi_0\).
5. \(\mathsf M^2_{\rm EW}\) has rank 3, a one-dimensional photon kernel, and the exact \((Z,A)\) diagonalization.

## Boundary

The representation, vacuum, \(g,g'\), and \(v\) are supplied model data.  The card derives their displayed tree-level consequences.  It carries no numerical mixing angle, mass ratio, or empirical comparison.  The physical carrier adapter and any forced-number claim remain later gates.

## Sources

- *The Electroweak Seam* v0.1, §§1–6.
- *The Electroweak Two-Operator Certificate* v0.1, §§1–4.
- *The Empirical Input Register* v0.1, §§8.1–8.4 and §14.

The verifier contains the complete displayed finite-dimensional derivation.  These citations retain provenance for the declared model convention and its wider source register.
