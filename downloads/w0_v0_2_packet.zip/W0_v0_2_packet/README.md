# W-0 Weinberg seam · v0.2 packet

This packet preserves the W-0 v0.2 contract, exact symbolic verifier, receipt, and their hash manifest.

Run:

```sh
sha256sum --check SHA256SUMS
python3 -I verify_w0_weinberg_seam_v0_2.py
```

The verifier checks 15 declared tree-level consequences of the supplied Higgs representation, vacuum, convention, and symbolic \(g,g',v\). It carries no numerical mixing-angle or mass prediction, empirical comparison, running/scheme effect, or carrier-to-particle identification. The three named source texts remain provenance citations and are not bundled here.
