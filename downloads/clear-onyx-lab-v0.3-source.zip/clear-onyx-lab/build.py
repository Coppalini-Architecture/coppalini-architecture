from pathlib import Path
from html.parser import HTMLParser
import re,json,subprocess,hashlib

R=Path(__file__).resolve().parent
t=(R/'index.html').read_text()
t=t.replace('<link rel="stylesheet" href="src/lab.css">','<style>'+(R/'src/lab.css').read_text()+'</style>')
def inline(m):
    path=R/m[1]
    subprocess.run(['node','--check',str(path)],check=True,capture_output=True)
    return '<script>'+path.read_text().replace('</script','<\\/script')+'</script>'
t=re.sub(r'<script src="([^"]+)"></script>',inline,t)
manifest=json.loads((R/'source-manifest.json').read_text())
t=t.replace('</body>','<script id="source-manifest" type="application/json">'+json.dumps(manifest).replace('<','\\u003c')+'</script></body>')
class IDs(HTMLParser):
    def __init__(self):super().__init__();self.ids=[]
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if a.get('id'):self.ids.append(a['id'])
p=IDs();p.feed(t);assert len(p.ids)==len(set(p.ids))
assert not re.search(r'<script[^>]+src=',t)
(R/'dist').mkdir(exist_ok=True)
for path in [R/'dist/index.html',R/'clear-onyx-lab-v0.3.html']:path.write_text(t)
print(json.dumps({'file':'clear-onyx-lab-v0.3.html','bytes':len(t.encode()),'sha256':hashlib.sha256(t.encode()).hexdigest()}))
