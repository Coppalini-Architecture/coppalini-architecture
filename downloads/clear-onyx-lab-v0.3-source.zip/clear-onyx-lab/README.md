# Clear Onyx — kernel laboratory 0.3

An inspectable successor candidate for Atomic Music, Water and the recovered
Higgs Mirror Scope, with a separate exact root-kernel instrument. Open
`clear-onyx-lab-v0.3.html` in a current browser. It is self-contained and works
offline. The source development page is `index.html`.

## Instruments

| Instrument | Native calculation retained | Additions |
| --- | --- | --- |
| Atomic Music | Exact D7 action on the seven p-occupation descriptors | Integer lift, negative registers, full finite-group audit, retained receipts, origin return that keeps history |
| Water | Original orbital functions and original two-center preparation | Cached spatial basis, full within-beat phase, BigInt occurrence, 108-address read, current, all 28 signed seams, seven perfect-matching bands, raw-frame covariance |
| Higgs scope | Archived nonzero-doublet polar/projective construction | Shared Water probe or editable doublet, central i action, radius/U/projective readers, declared radial potential, exact-zero and tiny-positive distinction |
| Root kernel | Q, Omega, G, H, S and Lax from the v66 proof | Exact Q(sqrt5) arithmetic, executable identities, quarter-phase return with axial lift retained |

The Water carrier is the declared two-center Hydrogen construction in fixed
empirical geometry. The generic doublet reader and its declared potential do
not supply Standard Model dynamics or a new physical identification. See
`AUDIT.md` for the owning equations, source comparison and verification scope.

## Build and verify

Requires Python 3 and Node, with no third-party packages:

```sh
node tests/check-kernels.cjs
python3 build.py
```

The build emits `dist/index.html` and `clear-onyx-lab-v0.3.html`. Native source
HTML and byte-preserved extracted mathematical modules are retained separately
under `source/` and `src/native-*.js`. `source-manifest.json` records their hashes.

`src/kernel.js` contains the exact root, finite action, integer phase registers,
seam/band reader and frozen receipt ledgers. `src/field.js` contains the numerical
field, cache and doublet adapters. `src/app.js` owns controls and scheduling;
drawing never advances a mathematical state.

## Receipt and controls

Export receipt opens a readable JSON inspector with a Download JSON link.
It retains source identities, current exact states, each instrument's operation
ledger and a globally ordered command/view journal. Water preview interpolation
is a separately named display coordinate. Source/preparation/view changes are
recorded separately from beat and central-phase steps.

State is held in the current browser session. Export the receipt to retain it
outside that session. This version inspects and exports receipts; importing and
resuming a saved receipt is a future interface.

Play requests four integer Water steps per second of display time. Each step is
recorded; a delayed timer does not invent or skip steps. Changing instruments or
hiding the document holds playback. A completed 108-beat traversal returns the
finite phase register while its exact beat and return count continue.

## Status and ownership

This is a prepared review build. No GitHub branch, public repository or website
deployment was changed by its construction. The existing published Hydrogen,
Helium, Tourbillon, Mechanical Eye and other site files are unaffected.

Research and original source: Anthony Vito Coppa / Coppalini Architecture.
The inherited Clear Onyx `LICENSE` is retained. No new general reuse license is
assigned by this package. The new implementation is an additive review candidate.

See `receipts/kernel-tests.json` for reproduced results and
`receipts/browser-checks.json` for actual UI observations and remaining limits.
