
(function (root) {
  "use strict";
"use strict";
// ClearOnyxWaterFieldV01 -- core physics (no DOM). Tested standalone.

function assert(cond, msg) { if (!cond) throw new TypeError(msg); }
function cmul(a, b) { return { re: a.re * b.re - a.im * b.im, im: a.re * b.im + a.im * b.re }; }
function cadd(a, b) { return { re: a.re + b.re, im: a.im + b.im }; }
function csub(a, b) { return { re: a.re - b.re, im: a.im - b.im }; }
function conj(a) { return { re: a.re, im: -a.im }; }
function cabs2(a) { return a.re * a.re + a.im * a.im; }
function cscale(a, s) { return { re: a.re * s, im: a.im * s }; }

function gcd(a, b) { a = Math.abs(a); b = Math.abs(b); while (b) { [a, b] = [b, a % b]; } return a; }
function reduceFraction(n, d) { const g = gcd(n, d) || 1; return { n: n / g, d: d / g }; }
// Verified relative-energy fraction (E1-En)/(E1-E2) = 4(n^2-1)/(3n^2).
function energyPhaseFraction(n) {
  const f = reduceFraction(4 * (n * n - 1), 3 * n * n);
  return { numerator: f.n, denominator: f.d };
}

// The exact period (in base-beats) at which the RELATIVE phase between two
// channels' underlying n-values returns to its starting value: the
// denominator of the reduced difference of their phase fractions.
function seamPeriod(nA, nB) {
  const ra = reduceFraction(energyPhaseFraction(nA).numerator, energyPhaseFraction(nA).denominator);
  const rb = reduceFraction(energyPhaseFraction(nB).numerator, energyPhaseFraction(nB).denominator);
  const num = ra.n * rb.d - rb.n * ra.d;
  const den = ra.d * rb.d;
  return reduceFraction(num, den).d;
}

// Verified once, on load: 108-address endpoint residues after one completed
// base beat, and the exact 8/8/8/4 seam-period census. If either check ever
// fails (e.g. someone changes CHANNEL_STATES), this throws rather than
// silently rendering a wrong census.
const EXPECTED_RESIDUES = [0, 0, 20, 27];
const EXPECTED_PERIOD_CENSUS = { 1: 8, 4: 8, 27: 8, 108: 4 };
function verifyRecurrenceCensus() {
  const residues = [1, 2, 3, 4].map(n => {
    const f = energyPhaseFraction(n);
    return Math.round((f.numerator * (108 / f.denominator)) % 108);
  });
  for (let i = 0; i < 4; i++) {
    assert(residues[i] === EXPECTED_RESIDUES[i], "108-address residue mismatch at n=" + (i + 1));
  }
  const channelN = [1, 2, 3, 4, 1, 2, 3, 4];
  const census = {};
  let seamCount = 0;
  for (let a = 0; a < 8; a++) for (let b = a + 1; b < 8; b++) {
    const period = seamPeriod(channelN[a], channelN[b]);
    census[period] = (census[period] || 0) + 1;
    seamCount++;
  }
  assert(seamCount === 28, "Expected exactly 28 pairwise seams.");
  for (const key of Object.keys(EXPECTED_PERIOD_CENSUS)) {
    assert(census[key] === EXPECTED_PERIOD_CENSUS[key], "Seam period census mismatch at period " + key + ": got " + census[key]);
  }
  return { residues, census, seamCount };
}
const RECURRENCE_CENSUS = verifyRecurrenceCensus();

// The four channel assignment per center -- same convention already used and
// verified in tonight's Superposition Generator (real, axial, m=0 states).
const CHANNEL_STATES = [
  { n: 1, l: 0, m: 0 },
  { n: 2, l: 1, m: 0 },
  { n: 3, l: 2, m: 0 },
  { n: 4, l: 3, m: 0 }
];

function makeWaterField(K, geometry) {
  // geometry: { bondLengthAH, bondAngleRad } in a_H units / radians
  const half = geometry.bondAngleRad / 2;
  const leftCenter = { x: -geometry.bondLengthAH * Math.sin(half), y: 0, z: -geometry.bondLengthAH * Math.cos(half) };
  const rightCenter = { x: geometry.bondLengthAH * Math.sin(half), y: 0, z: -geometry.bondLengthAH * Math.cos(half) };

  function channelAmplitude(center, state, x, y, z, basePhase) {
    const lx = x - center.x, ly = y - center.y, lz = z - center.z;
    const psi = K.orbitalValue(state.n, state.l, state.m, lx, ly, lz);
    const frac = energyPhaseFraction(state.n);
    const angle = -(frac.numerator / frac.denominator) * basePhase;
    return cscale({ re: Math.cos(angle), im: Math.sin(angle) }, 0.5 * psi);
  }

  // Full eight-channel sample at one point and time. Returns everything
  // downstream modes need, plus reconstruction residuals computed live
  // (not asserted -- checked, every call).
  function sample(x, y, z, basePhase) {
    const u = new Array(8);
    for (let i = 0; i < 4; i++) u[i] = channelAmplitude(leftCenter, CHANNEL_STATES[i], x, y, z, basePhase);
    for (let i = 0; i < 4; i++) u[4 + i] = channelAmplitude(rightCenter, CHANNEL_STATES[i], x, y, z, basePhase);

    let psiL = { re: 0, im: 0 }, psiR = { re: 0, im: 0 };
    for (let i = 0; i < 4; i++) psiL = cadd(psiL, u[i]);
    for (let i = 4; i < 8; i++) psiR = cadd(psiR, u[i]);
    // RAW_CONSTRUCTIVE / RAW_NODAL: valid raw symmetry reads of the two-center
    // field, not a claim of a computed molecular orbital.
    const rawConstructive = cscale(cadd(psiL, psiR), Math.SQRT1_2);
    const rawNodal = cscale(csub(psiL, psiR), Math.SQRT1_2);
    const bondDensity = cabs2(rawConstructive);
    const nodeDensity = cabs2(rawNodal);
    const totalDensityIncoherent = cabs2(psiL) + cabs2(psiR);

    // 28 pairwise seams: block (left-internal / right-internal / cross) AND
    // exact recurrence period (1, 4, 27, or 108 base-beats), both tagged on
    // every term, computed once.
    const channelN = [1, 2, 3, 4, 1, 2, 3, 4];
    const seams = [];
    let diagonalSum = 0;
    for (let i = 0; i < 8; i++) diagonalSum += cabs2(u[i]);
    let coherentReconstruction = diagonalSum;
    let crossReSum = 0;
    const periodCounts = {};
    for (let a = 0; a < 8; a++) {
      for (let b = a + 1; b < 8; b++) {
        const s = cmul(u[a], conj(u[b]));
        const block = a < 4 && b < 4 ? "leftInternal" : (a >= 4 && b >= 4 ? "rightInternal" : "cross");
        const period = seamPeriod(channelN[a], channelN[b]);
        seams.push({ a, b, block, period, re: s.re, im: s.im, magnitude: Math.hypot(s.re, s.im), phase: Math.atan2(s.im, s.re) });
        coherentReconstruction += 2 * s.re;
        if (block === "cross") crossReSum += 2 * s.re;
        periodCounts[period] = (periodCounts[period] || 0) + 1;
      }
    }
    assert(seams.length === 28, "Expected exactly 28 pairwise seams.");

    let sumU = { re: 0, im: 0 };
    for (const a of u) sumU = cadd(sumU, a);
    const totalCoherentDensity = cabs2(sumU);
    const totalCoherentResidual = Math.abs(totalCoherentDensity - coherentReconstruction);
    const bondNodeContrastDirect = bondDensity - nodeDensity;
    const bondNodeReconstructionResidual = Math.abs(bondNodeContrastDirect - crossReSum);

    return {
      u, psiL, psiR,
      rawConstructive, rawNodal,
      rawConstructiveLabel: "RAW_CONSTRUCTIVE", rawNodalLabel: "RAW_NODAL",
      bondDensity, nodeDensity, totalDensityIncoherent, totalCoherentDensity,
      bondNodeContrast: bondNodeContrastDirect,
      seams,
      audit: {
        seamCount: seams.length,
        leftInternalCount: seams.filter(s => s.block === "leftInternal").length,
        rightInternalCount: seams.filter(s => s.block === "rightInternal").length,
        crossCount: seams.filter(s => s.block === "cross").length,
        periodCounts,
        totalCoherentResidual,
        bondNodeReconstructionResidual
      }
    };
  }

  // Numerically differentiated probability current (Im(psi* grad psi)),
  // labeled as numerical, not analytic -- honest about method.
  function current(psiFn, x, y, z, h) {
    const c0 = psiFn(x, y, z);
    const dx = cscale(csub(psiFn(x + h, y, z), psiFn(x - h, y, z)), 1 / (2 * h));
    const dy = cscale(csub(psiFn(x, y + h, z), psiFn(x, y - h, z)), 1 / (2 * h));
    const dz = cscale(csub(psiFn(x, y, z + h), psiFn(x, y, z - h)), 1 / (2 * h));
    function comp(d) { return c0.re * d.im - c0.im * d.re; }
    return { x: comp(dx), y: comp(dy), z: comp(dz) };
  }

  // Canonical complex-doublet polar chart: Theta = (Omega Xi*, Xi) = rho * U.
  // Same construction already verified earlier tonight; general for ANY
  // nonzero doublet -- that generality is exactly why it is tiered as
  // "structural", never as evidence of a physical Higgs identity.
  function custodialPolarChart(psiL, psiR) {
    const rhoSquared = cabs2(psiL) + cabs2(psiR);
    const rho = Math.sqrt(rhoSquared);
    if (rho < 1e-12) return { available: false, rho: 0, label: "CANONICAL_COMPLEX_DOUBLET_POLAR_COORDINATE" };
    // Theta columns: (Omega Xi*, Xi), Omega = [[0,1],[-1,0]], Xi = (psiL, psiR)
    // => Htilde = Omega * conj(Xi) = (conj(psiR), -conj(psiL))
    const hTilde0 = conj(psiR), hTilde1 = cscale(conj(psiL), -1);
    // U = Theta / rho
    const u00 = cscale(hTilde0, 1 / rho), u10 = cscale(hTilde1, 1 / rho);
    const u01 = cscale(psiL, 1 / rho), u11 = cscale(psiR, 1 / rho);
    const relativePhase = Math.atan2(psiL.im, psiL.re) - Math.atan2(psiR.im, psiR.re);

    // Explicit numerical residuals, recomputed every call -- never assumed.
    const col0Norm = cabs2(u00) + cabs2(u10);
    const col1Norm = cabs2(u01) + cabs2(u11);
    const crossTerm = cadd(cmul(conj(u00), u01), cmul(conj(u10), u11));
    const det = csub(cmul(u00, u11), cmul(u10, u01));
    const residuals = {
      column0NormResidual: Math.abs(col0Norm - 1),
      column1NormResidual: Math.abs(col1Norm - 1),
      columnOrthogonalityResidual: Math.hypot(crossTerm.re, crossTerm.im),
      determinantResidual: Math.hypot(det.re - 1, det.im)
    };

    return {
      available: true,
      label: "CANONICAL_COMPLEX_DOUBLET_POLAR_COORDINATE",
      rho,
      relativePhase,
      matrix: { u00, u10, u01, u11 },
      residuals
    };
  }

  return { leftCenter, rightCenter, sample, current, custodialPolarChart, seamPeriod, RECURRENCE_CENSUS, CHANNEL_STATES, energyPhaseFraction };
}
  root.ClearOnyxWaterFieldV01 = { makeWaterField, cmul, cadd, csub, conj, cabs2, cscale, energyPhaseFraction };
})(typeof globalThis !== "undefined" ? globalThis : this);
