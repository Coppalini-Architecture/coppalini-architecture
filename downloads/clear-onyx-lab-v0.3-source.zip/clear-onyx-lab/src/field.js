/* Numeric adapters. Spatial functions are imported, byte unchanged, from native source. */
(function(root){
'use strict';
const N=root.ClearOnyxNext,K=root.HydrogenOrbitals,TAU=2*Math.PI;
const geometry=Object.freeze({bondLengthAH:0.9572/0.529177,bondAngleRad:104.52*Math.PI/180});
const half=geometry.bondAngleRad/2,centers=[[-geometry.bondLengthAH*Math.sin(half),-geometry.bondLengthAH*Math.cos(half)],[geometry.bondLengthAH*Math.sin(half),-geometry.bondLengthAH*Math.cos(half)]];
const ratios=[0,1,32/27,5/4,0,1,32/27,5/4];
function basis(x,z){return Array.from({length:8},(_,j)=>{const c=centers[j<4?0:1],l=j%4;return .5*K.orbitalValue(l+1,l,0,x-c[0],0,z-c[1]);});}
function phases(beat,alpha=0){beat=BigInt(beat);if(beat<0n||!Number.isFinite(alpha)||alpha<0||alpha>1)throw Error('nonnegative beat and interpolation 0..1 required');return N.steps.map((s,j)=>{const angle=-TAU*(Number((s*beat)%108n)/108+ratios[j]*alpha);return {re:Math.cos(angle),im:Math.sin(angle)};});}
function amplitudes(b,ph){return b.map((x,j)=>({re:x*ph[j].re,im:x*ph[j].im}));}
const abs2=z=>z.re*z.re+z.im*z.im;
function decompose(u){const L={re:0,im:0},R={re:0,im:0};u.forEach((z,j)=>{const p=j<4?L:R;p.re+=z.re;p.im+=z.im;});const sum={re:L.re+R.re,im:L.im+R.im},difference={re:L.re-R.re,im:L.im-R.im};return {u,L,R,total:abs2(sum),bond:.5*abs2(sum),node:.5*abs2(difference),contrast:2*(L.re*R.re+L.im*R.im)};}
function sample(x,z,beat,alpha=0){return decompose(amplitudes(basis(x,z),phases(beat,alpha)));}
function compileGrid(size=192){const horizon=geometry.bondLengthAH*2.6,b=new Float64Array(size*size*8);for(let py=0;py<size;py++)for(let px=0;px<size;px++){const values=basis(((px+.5)/size*2-1)*horizon,(1-(py+.5)/size*2)*horizon);b.set(values,(py*size+px)*8);}return {size,horizon,b};}
function renderGrid(grid,beat,alpha,mode,out){const ph=phases(beat,alpha);out=out||new Float64Array(grid.size**2);for(let i=0;i<out.length;i++){let lr=0,li=0,rr=0,ri=0;for(let j=0;j<8;j++){const v=grid.b[i*8+j];if(j<4){lr+=v*ph[j].re;li+=v*ph[j].im;}else{rr+=v*ph[j].re;ri+=v*ph[j].im;}}const sum=(lr+rr)**2+(li+ri)**2;out[i]=mode==='bond'?.5*sum:mode==='node'?.5*((lr-rr)**2+(li-ri)**2):mode==='contrast'?2*(lr*rr+li*ri):sum;}return out;}
function current(x,z,beat,alpha=0,h=1e-4){const sum=(x,z)=>{const s=sample(x,z,beat,alpha);return {re:s.L.re+s.R.re,im:s.L.im+s.R.im};},s=sum(x,z),xp=sum(x+h,z),xm=sum(x-h,z),zp=sum(x,z+h),zm=sum(x,z-h);return {x:(s.re*(xp.im-xm.im)-s.im*(xp.re-xm.re))/(2*h),z:(s.re*(zp.im-zm.im)-s.im*(zp.re-zm.re))/(2*h)};}
function polar(h){if(h.length!==2||h.some(z=>!Number.isFinite(z.re)||!Number.isFinite(z.im)))return {available:false,reason:'NONFINITE_INPUT'};const rho=Math.hypot(h[0].re,h[0].im,h[1].re,h[1].im);if(rho===0)return {available:false,reason:'ZERO_DOUBLET',rho:0};if(!Number.isFinite(rho))return {available:false,reason:'NORM_OUT_OF_RANGE'};const [a,b]=h.map(z=>({re:z.re/rho,im:z.im/rho})),conj=z=>({re:z.re,im:-z.im}),U=[[conj(b),a],[{re:-a.re,im:a.im},b]],overlap={re:a.re*b.re+a.im*b.im,im:a.re*b.im-a.im*b.re},n={x:2*overlap.re,y:2*overlap.im,z:abs2(a)-abs2(b)};const norm=abs2(a)+abs2(b);return {available:true,rho,q:rho*rho,U,n,residual:Math.abs(norm-1),blochResidual:Math.abs(n.x*n.x+n.y*n.y+n.z*n.z-1),underflow:rho*rho===0};}
function central(h,k){const phases=[{re:1,im:0},{re:0,im:1},{re:-1,im:0},{re:0,im:-1}],p=phases[Number(N.mod(BigInt(k),4n))];return h.map(z=>({re:z.re*p.re-z.im*p.im,im:z.re*p.im+z.im*p.re}));}
function integrateCoherences(points,beat,alpha=0){if(!points.length)throw Error('nonempty quadrature required');const gamma=Array.from({length:8},()=>Array.from({length:8},()=>({re:0,im:0})));for(const p of points){const u=sample(p.x,p.z,beat,alpha).u;for(let a=0;a<8;a++)for(let b=0;b<8;b++){gamma[a][b].re+=(u[a].re*u[b].re+u[a].im*u[b].im)/points.length;gamma[a][b].im+=(u[a].im*u[b].re-u[a].re*u[b].im)/points.length;}}return gamma;}
const api={geometry,centers,ratios,basis,phases,amplitudes,decompose,sample,compileGrid,renderGrid,current,polar,central,integrateCoherences};root.ClearOnyxField=Object.freeze(api);if(typeof module!=='undefined')module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this);
