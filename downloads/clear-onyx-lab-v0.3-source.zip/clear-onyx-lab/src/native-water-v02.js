
(function (root) {
  "use strict";
"use strict";
// ClearOnyxWaterFieldV02 -- core physics + exact state (no DOM, no wall clock).
// Authority hierarchy, enforced structurally: beat (integer) -> exact water
// state at that beat -> renderer interpolation. requestAnimationFrame never
// decides whether a beat occurred; it only supplies alpha in [0,1) between
// the two most recent exact beats.

function assert(cond, msg) { if (!cond) throw new TypeError(msg); }
function cmul(a, b) { return { re: a.re * b.re - a.im * b.im, im: a.re * b.im + a.im * b.re }; }
function cadd(a, b) { return { re: a.re + b.re, im: a.im + b.im }; }
function csub(a, b) { return { re: a.re - b.re, im: a.im - b.im }; }
function conj(a) { return { re: a.re, im: -a.im }; }
function cabs2(a) { return a.re * a.re + a.im * a.im; }
function cscale(a, s) { return { re: a.re * s, im: a.im * s }; }

function gcd(a, b) { a = Math.abs(a); b = Math.abs(b); while (b) { [a, b] = [b, a % b]; } return a; }
function reduceFraction(n, d) { const g = gcd(n, d) || 1; return { n: n / g, d: d / g }; }
// Verified relative-energy fraction (E1-En)/(E1-E2) = 4(n^2-1)/(3n^2).
function energyPhaseFraction(n) {
  const f = reduceFraction(4 * (n * n - 1), 3 * n * n);
  return { numerator: f.n, denominator: f.d };
}
function seamPeriod(nA, nB) {
  const ra = reduceFraction(energyPhaseFraction(nA).numerator, energyPhaseFraction(nA).denominator);
  const rb = reduceFraction(energyPhaseFraction(nB).numerator, energyPhaseFraction(nB).denominator);
  const num = ra.n * rb.d - rb.n * ra.d;
  const den = ra.d * rb.d;
  return reduceFraction(num, den).d;
}

// --- exact 108-address phase register ---------------------------------
// step_n = ratio_n * 108, verified integer for n=1..4: 0, 0, 20, 27.
// Sign is negative to match this project's e^{-iEt/hbar} convention
// (angle = -(ratio)*basePhase), verified to reproduce the old continuous
// formula exactly at integer beats (residual ~1e-14, machine precision).
const REGISTER_SIZE = 108;
const STEP_BY_N = { 1: 0, 2: 0, 3: 20, 4: 27 };
const CHANNEL_N = [1, 2, 3, 4, 1, 2, 3, 4]; // L1..L4, R1..R4
const CHANNEL_STEPS = CHANNEL_N.map(n => STEP_BY_N[n]);

const EXPECTED_RESIDUES = [0, 0, 20, 27];
const EXPECTED_PERIOD_CENSUS = { 1: 8, 4: 8, 27: 8, 108: 4 };
function verifyRecurrenceCensus() {
  for (let i = 0; i < 4; i++) {
    assert(STEP_BY_N[i + 1] === EXPECTED_RESIDUES[i], "108-address step mismatch at n=" + (i + 1));
  }
  const census = {};
  let seamCount = 0;
  for (let a = 0; a < 8; a++) for (let b = a + 1; b < 8; b++) {
    const period = seamPeriod(CHANNEL_N[a], CHANNEL_N[b]);
    census[period] = (census[period] || 0) + 1;
    seamCount++;
  }
  assert(seamCount === 28, "Expected exactly 28 pairwise seams.");
  for (const key of Object.keys(EXPECTED_PERIOD_CENSUS)) {
    assert(census[key] === EXPECTED_PERIOD_CENSUS[key], "Seam period census mismatch at period " + key);
  }
  return { census, seamCount };
}
const RECURRENCE_CENSUS = verifyRecurrenceCensus();

function addressAt(channelIndex, beat) {
  const step = CHANNEL_STEPS[channelIndex];
  return (((-step * beat) % REGISTER_SIZE) + REGISTER_SIZE) % REGISTER_SIZE;
}

// The one authoritative exact state at an integer beat. Pure function of
// beat; no wall-clock input anywhere in this file.
function createWaterPhaseState(beat) {
  assert(Number.isInteger(beat) && beat >= 0, "beat must be a nonnegative integer.");
  const residues108 = CHANNEL_STEPS.map((_, i) => addressAt(i, beat));
  return Object.freeze({
    schema: "water-field-v02.phase-state",
    beat,
    residues108,
    phaseClass4: beat % 4,
    phaseClass27: beat % 27,
    phaseClass108: beat % 108
  });
}

// Renderer-only interpolation: alpha in [0,1) blends the angle between the
// exact state at `beat` and the exact state at `beat+1`, taking the shortest
// signed path around the 108-ring. This changes appearance only -- the
// exact states it interpolates between are computed independently by
// createWaterPhaseState, never derived from alpha itself.
function interpolatedChannelAngle(channelIndex, beat, alpha) {
  const current = addressAt(channelIndex, beat);
  const next = addressAt(channelIndex, beat + 1);
  let delta = next - current;
  if (delta > REGISTER_SIZE / 2) delta -= REGISTER_SIZE;
  if (delta < -REGISTER_SIZE / 2) delta += REGISTER_SIZE;
  const address = current + alpha * delta;
  return (2 * Math.PI * address) / REGISTER_SIZE;
}

function makeWaterField(K, geometry) {
  const half = geometry.bondAngleRad / 2;
  const leftCenter = { x: -geometry.bondLengthAH * Math.sin(half), y: 0, z: -geometry.bondLengthAH * Math.cos(half) };
  const rightCenter = { x: geometry.bondLengthAH * Math.sin(half), y: 0, z: -geometry.bondLengthAH * Math.cos(half) };
  const CHANNEL_STATES = [{ n: 1, l: 0, m: 0 }, { n: 2, l: 1, m: 0 }, { n: 3, l: 2, m: 0 }, { n: 4, l: 3, m: 0 }];

  // Spatial-only orbital value, independent of time -- the part worth
  // precomputing and caching across frames.
  function spatialValue(channelIndex, x, y, z) {
    const side = channelIndex < 4 ? leftCenter : rightCenter;
    const state = CHANNEL_STATES[channelIndex % 4];
    return K.orbitalValue(state.n, state.l, state.m, x - side.x, y - side.y, z - side.z);
  }

  // Full complex amplitude at a point, exact beat, and interpolation alpha.
  function channelAmplitude(channelIndex, x, y, z, beat, alpha) {
    const spatial = spatialValue(channelIndex, x, y, z);
    const angle = interpolatedChannelAngle(channelIndex, beat, alpha);
    return cscale({ re: Math.cos(angle), im: Math.sin(angle) }, 0.5 * spatial);
  }

  function sampleAt(x, y, z, beat, alpha) {
    const u = new Array(8);
    for (let i = 0; i < 8; i++) u[i] = channelAmplitude(i, x, y, z, beat, alpha);
    return decomposeChannels(u);
  }

  // Given 8 complex amplitudes (however obtained -- single point or a field
  // integral), produce every declared quantity and every reconstruction
  // audit. Shared by both the single-point read and the integrated read so
  // there is exactly one place the algebra lives.
  function decomposeChannels(u) {
    let psiL = { re: 0, im: 0 }, psiR = { re: 0, im: 0 };
    for (let i = 0; i < 4; i++) psiL = cadd(psiL, u[i]);
    for (let i = 4; i < 8; i++) psiR = cadd(psiR, u[i]);
    const rawConstructive = cscale(cadd(psiL, psiR), Math.SQRT1_2);
    const rawNodal = cscale(csub(psiL, psiR), Math.SQRT1_2);
    const bondDensity = cabs2(rawConstructive);
    const nodeDensity = cabs2(rawNodal);
    const totalDensityIncoherent = cabs2(psiL) + cabs2(psiR);

    const seams = [];
    let diagonalSum = 0;
    for (let i = 0; i < 8; i++) diagonalSum += cabs2(u[i]);
    let coherentReconstruction = diagonalSum;
    let crossReSum = 0;
    for (let a = 0; a < 8; a++) {
      for (let b = a + 1; b < 8; b++) {
        const s = cmul(u[a], conj(u[b]));
        const block = a < 4 && b < 4 ? "leftInternal" : (a >= 4 && b >= 4 ? "rightInternal" : "cross");
        const period = seamPeriod(CHANNEL_N[a], CHANNEL_N[b]);
        seams.push({ a, b, block, period, re: s.re, im: s.im, magnitude: Math.hypot(s.re, s.im), phase: Math.atan2(s.im, s.re) });
        coherentReconstruction += 2 * s.re;
        if (block === "cross") crossReSum += 2 * s.re;
      }
    }
    assert(seams.length === 28, "Expected exactly 28 pairwise seams.");

    let sumU = { re: 0, im: 0 };
    for (const a of u) sumU = cadd(sumU, a);
    const totalCoherentDensity = cabs2(sumU);
    const totalCoherentResidual = Math.abs(totalCoherentDensity - coherentReconstruction);
    const bondNodeContrastDirect = bondDensity - nodeDensity;
    const bondNodeReconstructionResidual = Math.abs(bondNodeContrastDirect - crossReSum);

    const periodCounts = {};
    for (const s of seams) periodCounts[s.period] = (periodCounts[s.period] || 0) + 1;

    return {
      u, psiL, psiR,
      rawConstructive, rawNodal,
      rawConstructiveLabel: "RAW_CONSTRUCTIVE", rawNodalLabel: "RAW_NODAL",
      bondDensity, nodeDensity, totalDensityIncoherent, totalCoherentDensity,
      bondNodeContrast: bondNodeContrastDirect,
      seams,
      audit: {
        seamCount: seams.length,
        leftInternalCount: seams.filter(s => s.block === "leftInternal").length,
        rightInternalCount: seams.filter(s => s.block === "rightInternal").length,
        crossCount: seams.filter(s => s.block === "cross").length,
        periodCounts,
        totalCoherentResidual,
        bondNodeReconstructionResidual
      }
    };
  }

  // Field-integrated coherence Gamma_ab = sum_p w_p u_a(p) conj(u_b(p)),
  // approximated on a modest sample grid over the rendered plane (not full
  // pixel resolution -- the integral converges well before that, and this
  // keeps the cost bounded to once-per-exact-beat rather than once-per-pixel).
  function integrateField(planePoints, beat, alpha) {
    const n = planePoints.length;
    assert(n > 0, "integrateField requires at least one sample point.");
    const weight = 1 / n; // simple average -- a declared, stated quadrature choice
    const acc = new Array(8);
    for (let i = 0; i < 8; i++) acc[i] = { re: 0, im: 0 };
    for (const p of planePoints) {
      for (let i = 0; i < 8; i++) {
        const amp = channelAmplitude(i, p.x, p.y, p.z, beat, alpha);
        acc[i] = cadd(acc[i], cscale(amp, weight));
      }
    }
    return decomposeChannels(acc);
  }

  // Numerically differentiated probability current (Im(psi* grad psi)).
  function current(psiFn, x, y, z, h) {
    const c0 = psiFn(x, y, z);
    const dx = cscale(csub(psiFn(x + h, y, z), psiFn(x - h, y, z)), 1 / (2 * h));
    const dy = cscale(csub(psiFn(x, y + h, z), psiFn(x, y - h, z)), 1 / (2 * h));
    const dz = cscale(csub(psiFn(x, y, z + h), psiFn(x, y, z - h)), 1 / (2 * h));
    function comp(d) { return c0.re * d.im - c0.im * d.re; }
    return { x: comp(dx), y: comp(dy), z: comp(dz) };
  }

  // Canonical complex-doublet polar coordinate: Theta = (Omega Xi*, Xi) = rho*U.
  function custodialPolarChart(psiL, psiR) {
    const rhoSquared = cabs2(psiL) + cabs2(psiR);
    const rho = Math.sqrt(rhoSquared);
    if (rho < 1e-12) return { available: false, rho: 0, label: "CANONICAL_COMPLEX_DOUBLET_POLAR_COORDINATE" };
    const hTilde0 = conj(psiR), hTilde1 = cscale(conj(psiL), -1);
    const u00 = cscale(hTilde0, 1 / rho), u10 = cscale(hTilde1, 1 / rho);
    const u01 = cscale(psiL, 1 / rho), u11 = cscale(psiR, 1 / rho);
    const relativePhase = Math.atan2(psiL.im, psiL.re) - Math.atan2(psiR.im, psiR.re);
    const col0Norm = cabs2(u00) + cabs2(u10);
    const col1Norm = cabs2(u01) + cabs2(u11);
    const crossTerm = cadd(cmul(conj(u00), u01), cmul(conj(u10), u11));
    const det = csub(cmul(u00, u11), cmul(u10, u01));
    return {
      available: true,
      label: "CANONICAL_COMPLEX_DOUBLET_POLAR_COORDINATE",
      rho, relativePhase,
      matrix: { u00, u10, u01, u11 },
      residuals: {
        column0NormResidual: Math.abs(col0Norm - 1),
        column1NormResidual: Math.abs(col1Norm - 1),
        columnOrthogonalityResidual: Math.hypot(crossTerm.re, crossTerm.im),
        determinantResidual: Math.hypot(det.re - 1, det.im)
      }
    };
  }

  return {
    leftCenter, rightCenter, spatialValue, channelAmplitude,
    sampleAt, integrateField, current, custodialPolarChart,
    CHANNEL_STATES, CHANNEL_N
  };
}

// --- append-only named-transition ledger --------------------------------
// The only legal way beat advances. Receipts are pushed here and nowhere
// else; the renderer never calls this except in response to its own
// schedule tick, and it never fabricates a receipt on its own.
const TRANSITION_TYPES = Object.freeze([
  "WATER_BEAT_ADVANCE", "QUARTER_RETURN_COMMIT", "TWENTY_SEVEN_RETURN_COMMIT",
  "FULL_108_RETURN_COMMIT", "HOLD", "RESET_VIEW"
]);

function createWaterGenerator() {
  let beat = 0;
  let receipts = [];
  let phaseState = createWaterPhaseState(0);

  function advanceBeat() {
    const before = phaseState;
    beat += 1;
    phaseState = createWaterPhaseState(beat);
    receipts.push(Object.freeze({ type: "WATER_BEAT_ADVANCE", sequence: receipts.length, beat, before, after: phaseState }));
    if (beat % 4 === 0) receipts.push(Object.freeze({ type: "QUARTER_RETURN_COMMIT", sequence: receipts.length, beat }));
    if (beat % 27 === 0) receipts.push(Object.freeze({ type: "TWENTY_SEVEN_RETURN_COMMIT", sequence: receipts.length, beat }));
    if (beat % 108 === 0) receipts.push(Object.freeze({ type: "FULL_108_RETURN_COMMIT", sequence: receipts.length, beat }));
    return phaseState;
  }
  function hold() {
    receipts.push(Object.freeze({ type: "HOLD", sequence: receipts.length, beat }));
  }
  function resetView() {
    receipts.push(Object.freeze({ type: "RESET_VIEW", sequence: receipts.length, beat }));
  }
  function fullReturnCount() {
    return receipts.filter(r => r.type === "FULL_108_RETURN_COMMIT").length;
  }
  function quarterReturnCount() {
    return receipts.filter(r => r.type === "QUARTER_RETURN_COMMIT").length;
  }
  function twentySevenReturnCount() {
    return receipts.filter(r => r.type === "TWENTY_SEVEN_RETURN_COMMIT").length;
  }

  return {
    get beat() { return beat; },
    get phaseState() { return phaseState; },
    get receipts() { return receipts.slice(); },
    advanceBeat, hold, resetView,
    fullReturnCount, quarterReturnCount, twentySevenReturnCount
  };
}

const EXPORTS = {
  makeWaterField, createWaterPhaseState, interpolatedChannelAngle, addressAt,
  createWaterGenerator, TRANSITION_TYPES,
  cmul, cadd, csub, conj, cabs2, cscale, energyPhaseFraction, seamPeriod,
  RECURRENCE_CENSUS, REGISTER_SIZE, CHANNEL_N, STEP_BY_N
};
  root.ClearOnyxWaterFieldV02 = EXPORTS;
})(typeof globalThis !== "undefined" ? globalThis : this);
