/* Clear Onyx candidate: exact root and occurrence protocols. No DOM or clock. */
(function(root){
'use strict';
const mod=(n,m)=>((n%m)+m)%m;
const gcd=(a,b)=>{a=a<0n?-a:a;b=b<0n?-b:b;while(b){[a,b]=[b,a%b];}return a;};
class Quad {
 constructor(p=0n,q=0n,d=1n){p=BigInt(p);q=BigInt(q);d=BigInt(d);if(!d)throw Error('zero denominator');if(d<0n){p=-p;q=-q;d=-d;}const g=gcd(gcd(p,q),d);this.p=p/g;this.q=q/g;this.d=d/g;Object.freeze(this);}
 add(b){b=Qd(b);return new Quad(this.p*b.d+b.p*this.d,this.q*b.d+b.q*this.d,this.d*b.d);}
 neg(){return new Quad(-this.p,-this.q,this.d);}
 sub(b){return this.add(Qd(b).neg());}
 mul(b){b=Qd(b);return new Quad(this.p*b.p+5n*this.q*b.q,this.p*b.q+this.q*b.p,this.d*b.d);}
 inv(){return new Quad(this.d*this.p,-this.d*this.q,this.p*this.p-5n*this.q*this.q);}
 eq(b){b=Qd(b);return this.p===b.p&&this.q===b.q&&this.d===b.d;}
 number(){return (Number(this.p)+Number(this.q)*Math.sqrt(5))/Number(this.d);}
 toString(){return `(${this.p}${this.q<0n?'':'+'}${this.q}√5)/${this.d}`;}
 toJSON(){return {p:String(this.p),q:String(this.q),d:String(this.d)};}
}
const Qd=v=>v instanceof Quad?v:new Quad(v);
const mat=v=>v.map(row=>row.map(Qd));
const mul=(a,b)=>mat([[0,0],[0,0]]).map((row,i)=>row.map((_,j)=>a[i][0].mul(b[0][j]).add(a[i][1].mul(b[1][j]))));
const add=(a,b)=>a.map((row,i)=>row.map((x,j)=>x.add(b[i][j])));
const scale=(a,s)=>a.map(row=>row.map(x=>x.mul(s)));
const transpose=a=>[[a[0][0],a[1][0]],[a[0][1],a[1][1]]];
const equal=(a,b)=>a.every((row,i)=>row.every((x,j)=>x.eq(b[i][j])));
const det=a=>a[0][0].mul(a[1][1]).sub(a[0][1].mul(a[1][0]));
const I=mat([[1,0],[0,1]]),Q=mat([[1,1],[1,0]]),Omega=mat([[0,1],[-1,0]]);
const G=add(mul(Q,Omega),scale(mul(Omega,Q),-1));
const H=scale(G,new Quad(0,1,5)),S=scale(add(scale(Q,2),scale(I,-1)),new Quad(0,1,5));
const Lax=scale(add(scale(I,2),Q),new Quad(0,1,5));
function power(a,n){n=BigInt(n);if(n<0n)throw Error('negative matrix power');let r=I;while(n){if(n&1n)r=mul(r,a);a=mul(a,a);n>>=1n;}return r;}
function rootChecks(){return {Qrecurrence:equal(mul(Q,Q),add(Q,I)),Gsquare:equal(mul(G,G),scale(I,5)),Hsquare:equal(mul(H,H),I),Ssquare:equal(mul(S,S),I),generatorFit:equal(add(mul(transpose(S),G),mul(G,S)),scale(I,0)),axialFit:equal(mul(mul(transpose(Lax),G),Lax),G),mirrorInverse:equal(mul(mul(mul(H,Lax),H),Lax),I),axialSquare:equal(mul(Lax,Lax),mul(Q,Q))};}
const frozenCopy=v=>Array.isArray(v)?Object.freeze(v.map(frozenCopy)):v&&typeof v==='object'?Object.freeze(Object.fromEntries(Object.entries(v).map(([k,x])=>[k,frozenCopy(x)]))):v;
function ledger(){const entries=[];return {append(type,before,after,details={}){const e=frozenCopy({sequence:entries.length+1,type,before,after,details});entries.push(e);return e;},get length(){return entries.length;},get entries(){return entries.slice();}};}
function atomic(){let k=0n;const log=ledger();const snapshot=(occurrence=log.length)=>({address:String(k),descriptor:Number(mod(4n*k,7n)),cyclePosition:Number(mod(k,7n)),register:String((k-mod(k,7n))/7n),occurrence});return {snapshot,log,apply(op){if(!['F','F⁻¹','R','Origin'].includes(op))throw Error('unknown atomic operation');const before=snapshot();k=op==='F'?k+1n:op==='F⁻¹'?k-1n:op==='R'?5n-k:0n;log.append(op,before,snapshot(log.length+1));return snapshot();}};}
const steps=[0n,0n,20n,27n,0n,0n,20n,27n];
function atomicChecks(){const id=[0,1,2,3,4,5,6],f=id.map(n=>(n+4)%7),r=id.map(n=>6-n),compose=(a,b)=>b.map(n=>a[n]),key=p=>p.join(','),eq=(a,b)=>key(a)===key(b);let f7=id,r2=compose(r,r);for(let i=0;i<7;i++)f7=compose(f,f7);const inverse=id.map(n=>(n+3)%7),seen=new Map([[key(id),id]]),queue=[id];while(queue.length){const p=queue.shift();for(const g of [f,r]){const q=compose(g,p);if(!seen.has(key(q))){seen.set(key(q),q);queue.push(q);}}}return {F7:eq(f7,id),R2:eq(r2,id),RFR:eq(compose(r,compose(f,r)),inverse),groupOrder:seen.size};}
function water(){let beat=0n;const log=ledger();const snapshot=()=>({beat:String(beat),phase108:Number(beat%108n),fullReturns:String(beat/108n),residues:steps.map(s=>Number(mod(-s*beat,108n)))});return {snapshot,log,advance(count=1){if(!Number.isSafeInteger(count)||count<1||count>108)throw Error('advance must be 1..108 exact beats');for(let i=0;i<count;i++){const before=snapshot();beat++;log.append('WATER_BEAT',before,snapshot(),{fullReturn:beat%108n===0n});}return snapshot();}};}
const pairList=[];for(let a=0;a<8;a++)for(let b=a+1;b<8;b++)pairList.push([a,b]);
const matchings=Array.from({length:7},(_,a)=>[[7,a],...Array.from({length:3},(_,j)=>[mod(a+j+1,7),mod(a-j-1,7)])].map(p=>p.sort((x,y)=>x-y)));
function seams(u){if(u.length!==8)throw Error('eight channels required');const m=u.map(z=>z.re),r=u.map(z=>z.im),normM=m.reduce((s,x)=>s+x*x,0),normR=r.reduce((s,x)=>s+x*x,0),dot=m.reduce((s,x,j)=>s+x*r[j],0);const pairs=pairList.map(([a,b])=>({a,b,delta:m[a]*r[b]-m[b]*r[a],radiusSquared:m[a]**2+r[a]**2+m[b]**2+r[b]**2,band:matchings.findIndex(edges=>edges.some(p=>p[0]===a&&p[1]===b))}));const bands=Array(7).fill(0);for(const p of pairs)bands[p.band]+=p.delta*p.delta;const wedge=bands.reduce((a,b)=>a+b,0);const positive=normM+normR;return {pairs,bands,dot,normM,normR,wedge,positive,alignmentSquare:dot*dot,lagrangeResidual:Math.abs(dot*dot+wedge-normM*normR),radialIncidenceResidual:Math.abs(pairs.reduce((s,p)=>s+p.radiusSquared,0)-7*positive)};}
function rowAction(u,a){const n=a.map(row=>row.map(v=>v instanceof Quad?v.number():v));return u.map(z=>({re:n[0][0]*z.re+n[0][1]*z.im,im:n[1][0]*z.re+n[1][1]*z.im}));}
for(const matrix of [I,Q,Omega,G,H,S,Lax]){matrix.forEach(Object.freeze);Object.freeze(matrix);}
Object.freeze(steps);pairList.forEach(Object.freeze);Object.freeze(pairList);matchings.forEach(m=>{m.forEach(Object.freeze);Object.freeze(m);});Object.freeze(matchings);
const api={Quad,Qd,mod,mat,mul,add,scale,transpose,equal,det,power,I,Q,Omega,G,H,S,Lax,rootChecks,ledger,atomic,atomicChecks,water,steps,pairList,matchings,seams,rowAction};
root.ClearOnyxNext=Object.freeze(api);
if(typeof module!=='undefined')module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this);
