
(function (root) {
  "use strict";
"use strict";
// ClearOnyxHiggsMirrorV01 -- pure derived read of a complex doublet (h1,h2).
// No source-field mutation anywhere in this file. Every "may not claim"
// item from the brief (gauge dynamics, masses, physical Higgs identity) is
// simply absent -- there is nothing here that computes them.

function assert(cond, msg) { if (!cond) throw new TypeError(msg); }
function cmul(a, b) { return { re: a.re * b.re - a.im * b.im, im: a.re * b.im + a.im * b.re }; }
function cadd(a, b) { return { re: a.re + b.re, im: a.im + b.im }; }
function csub(a, b) { return { re: a.re - b.re, im: a.im - b.im }; }
function conj(a) { return { re: a.re, im: -a.im }; }
function cabs2(a) { return a.re * a.re + a.im * a.im; }
function cscale(a, s) { return { re: a.re * s, im: a.im * s }; }
function cabs(a) { return Math.hypot(a.re, a.im); }

function matMul(A, B) {
  return {
    m00: cadd(cmul(A.m00, B.m00), cmul(A.m01, B.m10)),
    m01: cadd(cmul(A.m00, B.m01), cmul(A.m01, B.m11)),
    m10: cadd(cmul(A.m10, B.m00), cmul(A.m11, B.m10)),
    m11: cadd(cmul(A.m10, B.m01), cmul(A.m11, B.m11))
  };
}
function matAdd(A, B) { return { m00: cadd(A.m00, B.m00), m01: cadd(A.m01, B.m01), m10: cadd(A.m10, B.m10), m11: cadd(A.m11, B.m11) }; }
function dagger(M) { return { m00: conj(M.m00), m01: conj(M.m10), m10: conj(M.m01), m11: conj(M.m11) }; }
function matDet(M) { return csub(cmul(M.m00, M.m11), cmul(M.m01, M.m10)); }
function matFrobeniusNorm(M) { return Math.hypot(cabs(M.m00), cabs(M.m01), cabs(M.m10), cabs(M.m11)); }

const CLAIM = Object.freeze({
  CERTIFIED_GENERAL_IDENTITY: "CERTIFIED_GENERAL_IDENTITY",
  COMPUTED_FROM_PROBE_FIELD: "COMPUTED_FROM_PROBE_FIELD",
  DECLARED_PROBE_ADAPTER: "DECLARED_PROBE_ADAPTER",
  DECLARED_VACUUM_MODEL: "DECLARED_VACUUM_MODEL",
  OPEN_PHYSICAL_INTERPRETATION: "OPEN_PHYSICAL_INTERPRETATION",
  FAILED: "FAILED"
});

// The exact minimum Higgs structure carried by any nonzero complex doublet.
// Same Omega/Htilde/Theta convention already built and verified in the
// Water Field's custodialPolarChart -- reused here, not reinvented.
function higgsMirrorPacket(h1, h2, options) {
  const opts = options || {};
  const epsilon = opts.epsilon === undefined ? 1e-12 : opts.epsilon;
  const rho0 = opts.rho0 === undefined ? 1 : opts.rho0;
  const lambda = opts.lambda === undefined ? 1 : opts.lambda;

  const rhoSquared = cabs2(h1) + cabs2(h2);
  const rho = Math.sqrt(rhoSquared);

  if (rho < epsilon) {
    return Object.freeze({
      available: false, rhoSquared, rho,
      reason: "DOUBLET_NORM_BELOW_EPSILON",
      silenceClass: "NODAL_ORIGIN_SILENCE",
      claimStatus: CLAIM.COMPUTED_FROM_PROBE_FIELD
    });
  }

  const z1 = cscale(h1, 1 / rho), z2 = cscale(h2, 1 / rho);
  const hTilde0 = conj(h2), hTilde1 = cscale(conj(h1), -1);
  const theta = { m00: hTilde0, m01: h1, m10: hTilde1, m11: h2 };
  const polar = { m00: cscale(theta.m00, 1 / rho), m01: cscale(theta.m01, 1 / rho), m10: cscale(theta.m10, 1 / rho), m11: cscale(theta.m11, 1 / rho) };

  const overlap = cmul(conj(z1), z2);
  const n = { x: 2 * overlap.re, y: 2 * overlap.im, z: cabs2(z1) - cabs2(z2) };
  const relativePhase = Math.atan2(overlap.im, overlap.re);

  const vacuumResidual = rho - rho0;
  const potential = lambda * (rhoSquared - rho0 * rho0) * (rhoSquared - rho0 * rho0);
  const potentialGradient = 4 * lambda * rho * (rhoSquared - rho0 * rho0);
  const shellProjection = [cscale(z1, rho0), cscale(z2, rho0)];

  // Every residual computed live -- never assumed because it is algebraically guaranteed.
  const thetaDaggerTheta = matMul(dagger(theta), theta);
  const targetGram = { m00: { re: rhoSquared, im: 0 }, m01: { re: 0, im: 0 }, m10: { re: 0, im: 0 }, m11: { re: rhoSquared, im: 0 } };
  const thetaGramResidual = matFrobeniusNorm(matAdd(thetaDaggerTheta, { m00: cscale(targetGram.m00, -1), m01: cscale(targetGram.m01, -1), m10: cscale(targetGram.m10, -1), m11: cscale(targetGram.m11, -1) }));
  const thetaDet = matDet(theta);
  const thetaDeterminantResidual = cabs(csub(thetaDet, { re: rhoSquared, im: 0 }));
  const polarUdaggerU = matMul(dagger(polar), polar);
  const polarUnitarityResidual = matFrobeniusNorm(matAdd(polarUdaggerU, { m00: { re: -1, im: 0 }, m01: { re: 0, im: 0 }, m10: { re: 0, im: 0 }, m11: { re: -1, im: 0 } }));
  const polarDeterminantResidual = cabs(csub(matDet(polar), { re: 1, im: 0 }));
  const sourceRecoveryResidual = Math.hypot(cabs(csub(theta.m01, h1)), cabs(csub(theta.m11, h2)));
  const normalizedNormResidual = Math.abs(cabs2(z1) + cabs2(z2) - 1);
  const blochSphereResidual = Math.abs(n.x * n.x + n.y * n.y + n.z * n.z - 1);

  return Object.freeze({
    available: true,
    sourceDoublet: [h1, h2],
    rhoSquared, rho,
    z: [z1, z2],
    hTilde: [hTilde0, hTilde1],
    theta, polar, n, relativePhase,
    vacuum: { rho0, lambda, radialResidual: vacuumResidual, potential, potentialGradient, shellProjection },
    residuals: {
      thetaGramResidual, thetaDeterminantResidual, polarUnitarityResidual, polarDeterminantResidual,
      sourceRecoveryResidual, normalizedNormResidual, blochSphereResidual
    },
    claimStatus: CLAIM.COMPUTED_FROM_PROBE_FIELD
  });
}

// Section 6/7: central return H -> -H, plus the group-algebra closure
// packet for the represented central element c=-I2. All CERTIFIED_GENERAL_IDENTITY.
function centralReturnPacket(h1, h2, options) {
  const before = higgsMirrorPacket(h1, h2, options);
  const after = higgsMirrorPacket(cscale(h1, -1), cscale(h2, -1), options);

  if (!before.available || !after.available) {
    return Object.freeze({
      available: false,
      reason: "NODAL_ORIGIN_SILENCE",
      before, after,
      claimStatus: CLAIM.COMPUTED_FROM_PROBE_FIELD
    });
  }

  const radiusResidual = Math.abs(after.rho - before.rho);
  const projectiveResidual = Math.hypot(after.n.x - before.n.x, after.n.y - before.n.y, after.n.z - before.n.z);
  const thetaSum = matAdd(before.theta, after.theta); // should be exactly zero
  const liftedSignResidual = matFrobeniusNorm(thetaSum);
  const polarSum = matAdd(before.polar, after.polar); // should be exactly zero
  const polarSignResidual = matFrobeniusNorm(polarSum);

  // Group-algebra closure for c = -I2 (Architecture-of-Silence style):
  // C(c) = c + I, D(c) = c - I.
  const closureRead = 0;           // (-I) + I = 0, exactly
  const representedDefect = -2;    // (-I) - I = -2I, reported as the scalar -2 (times I2)

  return Object.freeze({
    available: true,
    sourceDoublet: before.sourceDoublet,
    returnedDoublet: after.sourceDoublet,
    centralElement: "c = -I2",
    closureRead,
    representedDefect,
    sourceRadius: before.rho,
    returnedRadius: after.rho,
    radiusResidual,
    sourceProjectiveDirection: before.n,
    returnedProjectiveDirection: after.n,
    projectiveResidual,
    sourcePolarFactor: before.polar,
    returnedPolarFactor: after.polar,
    liftedSignResidual,
    polarSignResidual,
    before, after,
    claimStatus: CLAIM.CERTIFIED_GENERAL_IDENTITY
  });
}

const EXPORTS = { CLAIM, higgsMirrorPacket, centralReturnPacket, cmul, cadd, csub, conj, cabs2, cscale, cabs };
  root.ClearOnyxHiggsMirrorV01 = EXPORTS;
})(typeof globalThis !== "undefined" ? globalThis : this);
