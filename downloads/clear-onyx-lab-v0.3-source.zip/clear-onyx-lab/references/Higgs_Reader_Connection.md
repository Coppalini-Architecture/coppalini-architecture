# Higgs-compatible reader: recovered connection and calculation record

**Date:** 5 September 2026  
**Author of source research:** Anthony Vito Coppa  
**This document:** source recovery and independent calculation by ChatGPT; additive review, not a revision of the source manuscripts.

## Result in ordinary language

The eight-channel reader already has an exact route into the complex-doublet geometry used by the Higgs sector. Two real rows become one complex row. Every original pairwise difference is exactly the imaginary part of the corresponding complex correlation. Every nonzero pair has a radius and an SU(2) orientation. The golden eigenframe itself factors into a doublet matrix and a separately retained reciprocal stretch.

Consequently the relationships being drawn on the twenty-eight-seam display are computed from the same source differences. The relationship is an explicit coordinate construction, not an identification inferred from the numbers seven, eight or twenty-eight. The physical spectral module separately supplies the Standard Model representation, action and couplings needed to interpret a physical response.

## 1. Source order and ownership

The following artifacts were located in the File Library. References to them identify library sources, not native copies included in this archive.

1. **CUSTODIAL_MODE_CENSUS_AUDIT.md**, 2 August 2026, §§I–IV and VII. Owns the generic complex-doublet construction; the inherited central phase action; the exact eight-channel complexification; the twenty-eight pair probes; sevenfold radial incidence; and the physical scope boundary.
2. **Clear_Onyx_Custodial_Mode_Census_v0_11.html**, 2 August 2026. Embedded `golden_higgs_adapter_v10`, `custodial_higgs_basis_v11`, and pair-census modules own the numerical implementation and explicit contracts.
3. **clear_onyx_continuous_zeta_revolution_v0_1.html**, 3 August 2026. `applyToFrame` supplies the left action on a two-row frame. Its `construct(h1,h2,epsilon)` function is the source excerpt exercised here.
4. **Clear_onyx Big Box.txt**, uploaded 30 August 2026, especially §§10–13. Plain-language program orientation and the separation between retained machine data and visible display.
5. **The Structure of Survival / Minimum Enduring Complexity, corrected 0.2**, Paper I, 3 September 2026, §§3–9, 15–16, 20–22. Owns the root, the finite relational branch, the seven-band fold, spectral-scope interpretation, local Lie-algebra adapter and continuum contract.
6. **Return-Weight Spectral Adapter v0.2**, §§1–6 and 10–12. Owns the conditional mass/action/proper-time phase correspondence; Higgs radial coupling read; and physical-observation chain.
7. **031 Group Algebra Closure with Retained Occurrence**, §§21–26. Owns the exact finite transport-defect product, local doublet fiber, and proposed gauge–Higgs interface.
8. **QFT / Standard Model / Electroweak / QCD: Field-Source Ownership**, §§XX–XXII and XLIII. Owns the native vacuum/spectral account and exact constraint result register.

Historical notes use “Hold 7 Return 1” as a mnemonic. The equations below state the distinct mathematical meanings of seven in the retrieved implementations. This note does not silently identify all uses of seven.

## 2. Notation

- `i_C` is the scalar complex imaginary unit.
- `i_op=-Omega` is the real quarter-turn operator.
- `G_root=[Q,Omega]` is the root-generated symmetric matrix.
- `m,r` are the two real eight-channel rows (called Form and Function in the census).
- `B(h)` is written here for the matrix called `Theta(h)` in the custodial source, keeping it separate from the project's Timing symbol.
- `H_m=G_root/sqrt(5)` is the normalized root mirror.
- `theta` retains its manuscript meaning, Survival; `Theta` retains Timing. No new mnemonic assignment overwrites those conventions.

## 3. Two-form zero with a retained carrier

Let

    Omega = [[0,1],[-1,0]],
    h = (z1,z2)^T in C^2,
    J(h) = Omega conjugate(h).

Then

    J^2(h) = -h,
    h† J(h) = 0,
    ||J(h)||^2 = ||h||^2.

The zero is an orthogonality read between a nonzero doublet and its conjugate partner. Define

    B(h) = (J(h), h),
    q = h†h.

Direct multiplication gives

    B(h)† B(h) = q I,
    det B(h) = q.

For q>0,

    rho = sqrt(q),
    U(h) = B(h)/rho in SU(2),
    h = rho U(h) e2.

The radius and orientation jointly recover the doublet. At h=0, the radius exists and a unique polar orientation does not.

The same construction is used for the scalar doublet's custodial matrix in Higgs-sector mathematics. A particular eight-channel input is an additional, explicitly chosen source of doublets; the generic identity alone supplies no spacetime dynamics or numerical physical scale.

## 4. Exact connection from eight channels to all twenty-eight pairs

Write

    z_j = m_j + i_C r_j,  j=0,...,7.

For each a<b define

    h_ab = (z_a,z_b)^T,
    Delta_ab = m_a r_b - m_b r_a.

Then

    conjugate(z_a) z_b
      = (m_a m_b + r_a r_b) + i_C Delta_ab.

Therefore

    Im(conjugate(z_a) z_b) = Delta_ab.

This is the exact cross-description joint: the original alternating difference is retained as a component of the complex correlation.

Every pair has

    rho_ab^2 = |z_a|^2 + |z_b|^2.

Each channel occurs in seven pairs, hence

    sum_(a<b) rho_ab^2 = 7 sum_j |z_j|^2.

For separately unit-normalized rows, the total is 14. The pair probes overlap: they are reads of one complex eight-channel record, not twenty-eight independent physical fields.

## 5. Three separate seven-counts

### A. Relative phase

    U(1)^8 / U(1)_diag ~= U(1)^7.

Seven relative phases are available after factoring a common phase. This statement concerns unit phases, not all amplitudes in C^8.

### B. Complete pair scanning

Label vertices by {infinity} union Z_7 and define

    M_a = {{infinity,a}} union {{a+j,a-j}: j=1,2,3}.

The seven perfect matchings partition the twenty-eight unordered pairs. Every matching contains four disjoint pairs.

### C. One alignment plus seven squared-difference bands

For the actual seam values define

    B_a = sum_(e in M_a) Delta_e^2.

Lagrange's identity and the pair partition give

    (m dot r)^2 + sum_a B_a = ||m||^2 ||r||^2.

For unit rows,

    (m dot r)^2 + B_0+...+B_6 = 1.

This is an exact “one alignment, seven difference bands, one conserved total” read.

Example: m=e0 and r=(3/5)e0+(4/5)e1. The alignment square is 9/25; only Delta_01 is nonzero, with square 16/25; the total is 1. In the stated matching convention pair {0,1} lies in matching 4.

The seven band sums retain total squared exterior difference. They do not determine every individual signed seam. Full signed seams, source records and any promised traversal record remain separate retained information.

## 6. The golden eigenframe already has the factorization

Define

    Phi = (1+sqrt(5))/2,
    Psi = (1-sqrt(5))/2,
    E = [[Phi,Psi],[1,1]],
    A = diag(sqrt(Phi),Phi^(-1/2)),
    h_g = (-Phi^(-1/2),sqrt(Phi))^T.

For the same B construction,

    E = B(h_g) A,
    det A = 1,
    h_g†h_g = sqrt(5),
    U_g = 5^(-1/4) B(h_g) in SU(2).

Thus normalization does not need to discard the reciprocal stretch: A remains a separately available factor. This exact construction is already embedded in the August 2 release.

With the source's Hermitian frame

    T1=-H_m/2, T2=-i_C i_op/2, T3=(2Q-I)/(2sqrt(5)),

one has the su(2) commutator relations and

    T3 h_g = -h_g/2.

After supplying Y_H=+1/2,

    Q_em = T3+(1/2)I,
    Q_em h_g=0,
    Q_em^2=Q_em,
    rank Q_em=1.

That zero is a neutral response of a nonzero carrier under a specified operator. The physical hypercharge assignment is an input in the source.

The physical scale function multiplies h_g by

    kappa = v / (sqrt(2) 5^(1/4)),

so its norm becomes v^2/2. The function explicitly labels this supplied calibration rather than prediction of v.

## 7. Transport connection — reviewer-composed corollary

This section composes the source's left row action with its seam definition; it is a displayed reviewer derivation, not a claimed quotation from an unlocated theorem.

For the raw two-row frame X=(m^T;r^T),

    Delta(X) = X^T Omega X.

For any real 2x2 matrix A,

    A^T Omega A = det(A) Omega,

so

    Delta(AX) = det(A) Delta(X).

Proof: multiply the generic matrix A=[[a,b],[c,d]] on both sides of Omega, or expand each pair determinant.

Consequences:

- Q and H_m, each determinant -1, reverse every oriented seam.
- i_op, determinant +1, preserves every oriented seam.
- L_t=exp(t log(Phi) S), determinant +1, preserves every oriented seam.
- The same L_t satisfies L_t^T G_root L_t=G_root.

This is a raw-frame statement. Independently normalizing the two rows rescales their wedge and requires retaining or accounting for the normalization factors. The positive radial norm and the split G_root relation are distinct invariants. L_t is not in general unitary for the positive Euclidean/Hermitian metric; its preservation law is explicitly the one shown.

## 8. Central phase, projection and receipt

For h_n=i_C^n h_g,

    U_n=U_g diag(i_C^(-n),i_C^n).

The doublet radius is fixed. At n+2, U changes to -U; at n+4 it returns to U. The SU(2) adjoint action on SO(3) is unchanged by U -> -U. Separately, the Bloch/projective ray of h is unchanged by any common scalar phase, including a single i_C step. These are different readers.

The internal/body transition U_n†U_(n+1)=-i_C sigma3 and the weak-frame transition U_(n+1)U_n†=-i_C S describe the same accepted step in two frames.

A return of a matrix or projected value does not reset the occurrence number. Exact history recovery uses the separately specified receipt.

## 9. The native physical spectral connection

The later Return-Weight Spectral Adapter supplies a distinct physical calculation. In the stated minimal Standard Model at tree level, the vacuum and supplied couplings produce a quadratic response operator. In basis (W1,W2,W3,B),

    M^2=(v^2/4) [[g^2,0,0,0],
                 [0,g^2,0,0],
                 [0,0,g^2,-g gprime],
                 [0,0,-g gprime,gprime^2]].

It can be computed directly from the action of the four coupled generators on h0=(0,v/sqrt(2)) as twice the real part of the Gram matrix of those responses. Its neutral vector (0,0,gprime,g)^T is nonzero and has zero response.

Replacing v by v+h and extracting the linear term gives

    g_hff=m_f/v,
    g_hVV=2m_V^2/v,

with the source's stated vertex normalization. These are conditional Standard Model relations. ATLAS and CMS production/decay measurements test that coupling pattern within experimental and theoretical uncertainty; they do not independently test the eight-channel identification.

The same source connects an invariant mass m in a specified stable positive-mass sector to proper-time action and phase:

    S=-m c^2 integral d tau,
    exp(i_C S/hbar)=exp(-i_C m c^2 integral d tau/hbar).

This is the manuscript's operational “return weight” reading. An observable phase requires a comparator; an isolated common phase is not measured as an absolute value.

## 10. Continuum interpretation retained at its actual calculation

These recovered equations establish an algebraic bridge from the pairwise reader to complex-doublet/custodial geometry, and the separate physical spectral module supplies its native conditions. They do not calculate the physical spin-two two-point function in CCLQG Paper II equation (44).

Existence of a readable distinction supplies a general requirement on a description. A particular gravitational observable still has a specified state, dynamics, quotient and tensor read. Re-labelling one result as the other would lose exactly the distinction this method retains.

The compatible-reader construction can therefore be carried forward as a verified connection without treating the model-specific gravitational calculation as completed. No unknown physical map is silently inserted in this note.

## 11. Actual checks in this archive

### Independent Python/SymPy checks

`verify_fit.py` is reviewer-written. It checks symbolic identities and finite structural claims derived from the located equations. **93/93 checks passed** using SymPy 1.14.0. The detailed residuals and assumptions are in `symbolic_receipt.json`.

### Independent C++20 compile-time witness

`finite_fit_checks.cpp` is reviewer-written. It compiles with `static_assert` over:

- all 625 doublets with four real components in {-2,-1,0,1,2};
- 6,561 row-action cases with entries in {-1,0,1};
- the complete K8 matching partition;
- one exact eight-channel radial and Lagrange-identity witness.

The compiler version and stdout/stderr are retained. These checks concern their encoded equations and finite domains; they are not a compile-time verification of all physical laws.

### Retrieved JavaScript function body

`polar_source_excerpt.js` contains the located `construct` function body, with reviewer-supplied complex helpers and a finite test harness. It is not the complete native application. Node v22.16.0 tested 625 inputs; 624 nonzero inputs produced the expected polar data. The largest normalized Gram/determinant residual was 2.220446049250313e-16; reconstruction and central-sign residuals were zero in that finite run.

The original function has an epsilon policy: a supplied positive radius below 1e-12 is reported unavailable with radius zero. The additional 1e-13 probe records that numerical behavior. No exact-zero conclusion is drawn from that floating-point cutoff.

### Reproduction

    python verify_fit.py
    g++ -std=c++20 -Wall -Wextra -pedantic -O2 finite_fit_checks.cpp -o finite_fit_checks
    ./finite_fit_checks
    node polar_source_excerpt.js

The scripts require Python+SymPy, a C++20 compiler, and Node respectively. No full GUI, native release build, empirical measurement, or new LQG amplitude calculation was performed in this review.

## 12. External primary sources checked

- ATLAS Collaboration, *A detailed map of Higgs boson interactions by the ATLAS experiment ten years after the discovery*, Nature 607, 52–59 (2022), DOI 10.1038/s41586-022-04893-w.
- CMS Collaboration, *A portrait of the Higgs boson by the CMS experiment ten years after the discovery*, Nature 607, 60–68 (2022), DOI 10.1038/s41586-022-04892-x.

## Handoff statement

The recovered mathematical connection is explicit: one two-form difference is carried into all pairwise complex correlations, each nonzero pair has a custodial orientation and radius, the golden frame admits the same construction with stretch retained, and the raw root motions have exact effects on the original differences. The seven-band read preserves a specified total while the full record carries the finer distinctions.

This is the portion now mapped and independently checked. The named equations are the basis of the assessment, not the fluency of this summary.
