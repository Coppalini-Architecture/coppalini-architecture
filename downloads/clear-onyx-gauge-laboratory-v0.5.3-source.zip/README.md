# Clear Onyx — Gauge & Matter Laboratory v0.5.3

`clear-onyx-gauge-laboratory-v0.5.3.html` is a self-contained browser laboratory. A model enters the dynamic selector when it has a declared update law and at least one numerical receipt that can fail. The five retained atomic, molecular, and real-1D studies display `OPEN · check not admitted`.

## Clear-field reader layout

This presentation release moves the model identity, interaction cue, and visual caption onto the frame perimeter. The main field canvas carries geometry, colour, brightness, filaments, and motion without text overlays. The update laws, carrier code, and physics receipts are unchanged from v0.5.2.

## Electroweak Higgs sector

The Higgs carrier uses the Standard Model Higgs representation directly: a complex hypercharge-one weak doublet

\[
\Phi_x\in\mathbb C^2,\qquad
\mathcal L_H=(D_\mu\Phi)^\dagger(D^\mu\Phi)-\lambda\left(\Phi^\dagger\Phi-\frac{v^2}{2}\right)^2.
\]

Its centered finite-lattice update is

\[
\Phi^{n+1}_x=2\Phi^n_x-\Phi^{n-1}_x+\Delta t^2\left[D_iD_i\Phi^n_x-2\lambda\left((\Phi_x^n)^\dagger\Phi_x^n-\frac{v^2}{2}\right)\Phi^n_x\right],
\]

with \(SU(2)_L\times U(1)_Y\) link transport on a declared two-spatial-dimensional lattice. Brightness is the gauge-invariant radial quantity \(\left|\sqrt{2\Phi^\dagger\Phi}-v\right|\); hue is weak-isospin orientation in the displayed gauge; filaments use the gauge-covariant Higgs current.

| Receipt | Independent comparison | Required result |
|---|---|---|
| Local gauge covariance | evolve a branch and its locally transformed \(SU(2)_L\times U(1)_Y\) companion | transformed-doublet residual below threshold |
| Invariant modulus | compare \(\Phi^\dagger\Phi\) after the same local action | density residual below threshold |
| Radial mode | measure a small-amplitude radial plane mode | measured lattice frequency matches \(m_h=\sqrt{2\lambda}\,v\) and its lattice dispersion |
| Gauge-boson masses | construct the \(4\times4\) mass matrix directly from \(D_\mu\Phi\) at the vacuum, then diagonalize it | \(m_W=gv/2\), \(m_Z=v\sqrt{g^2+g'^2}/2\), \(m_\gamma=0\) |

The earlier real 1D \(\phi^4\) domain field remains present under its own name and remains open. It carries a real-scalar double-well update; the admitted Higgs entry carries the complex electroweak doublet and its gauge action.

## Gauge block

| Model | Finite carrier | Update | Fail-capable receipt |
|---|---|---|---|
| Aharonov–Bohm flux ring | complex amplitude on a closed U(1) link graph | exact unitary bond transport using link phases | norm, local-gauge covariance, \(\Phi\) and \(\Phi+2\pi\) large-gauge density covariance after the declared seed twist, nonzero half-flux response |
| SU(3) colour-link transport | colour-triplet packet on a 2D lattice with non-commuting SU(3) links | exact unitary, gauge-covariant bond transport | norm, covariance under general non-diagonal local SU(3), plaquette and \(2\times1\) Wilson-loop trace invariance, evolved \(\epsilon_{abc}\) singlet determinant |

The U(1) holonomy remains a displayed coordinate, \(\prod_{\rm loop}U_\ell=e^{i\Phi}\). The SU(3) carrier implements finite lattice-gauge kinematics:

\[
\psi_x\mapsto G_x\psi_x,\qquad
U_{x,\mu}\mapsto G_xU_{x,\mu}G^\dagger_{x+\mu},\qquad G_x\in SU(3).
\]

The RGB canvas is a reader mapping of the three colour-basis populations.

## Additional admitted carriers

| Model | Declared result checked |
|---|---|
| Electroweak Higgs doublet | local \(SU(2)_L\times U(1)_Y\) covariance, invariant \(\Phi^\dagger\Phi\), radial lattice frequency, and the tree-level \(W/Z/\gamma\) mass matrix constructed from \(D_\mu\Phi\) |
| Massive Dirac packet | unitary pulse, norm, both dispersion branches, charge conjugation, \(2E\) mixed-branch beating, and an explicit `UNRESOLVED` result for a uniform torus state with no circular centroid |
| Complex \(\phi^4\) vortex pair | post-pulse global U(1) density invariance, discrete charge, initial seed winding, time-local plaquette vortex count, Goldstone dispersion, radial-mode frequency |
| Two-flavour oscillation | \(P_{\alpha\to\beta}=\sin^2(2\theta)\sin^2(\Delta m^2L/4E)\) and \(P_\alpha+P_\beta=1\) |
| Neutral spinor | the visible current is the integrated Weyl current \(\langle\sigma_x,\sigma_y\rangle\), tested against the spinor read on the declared seed |
| Noether–Klein memory field | a post-pulse charge baseline, 3000-step charge-proxy drift, and an explicit `UNRESOLVED` result for a uniform torus field with no circular centroid |
| Electron, photon, scalar | inherited finite carrier checks, with their declared scope retained |

## Reader conventions

- Brightness reads the selected local magnitude.
- Hue reads a declared phase or orientation coordinate.
- The SU(3) view uses RGB as a basis-population reader convention.
- The compass names its three coordinates beneath the vector.
- Dirac and Noether–Klein circular centroids return `UNRESOLVED` when their normalized first circular moment vanishes.
- The electroweak Higgs carrier is a finite \(2+1\)D classical lattice realization with fixed declared background links. Its mass receipt is the tree-level electroweak vacuum relation generated by the declared covariant derivative.

## Visual studies held open

Hydrogen, lithium, helium, water, and real 1D \(\phi^4\) remain available as visual studies. The radial hydrogen formula and its \(n\leq6\) evidence are retained in `PROVENANCE.md`; an independently audited executable orbital kernel is still required for admission.

## Verify

```sh
node build.mjs
node write-manifest.mjs
node tests/check-v042.cjs
node tests/check-v05.cjs
node tests/check-browser-bootstrap.cjs
node tests/check-manifest.cjs
```

`tests/check-particle-atlas.cjs` and `tests/check-v04.cjs` are retired guards and are excluded from the v0.5.3 source package. `source-manifest.json` lists every shipped source file and its SHA-256 hash.
