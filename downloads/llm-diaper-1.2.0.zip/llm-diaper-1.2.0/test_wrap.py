from pathlib import Path
import tempfile
import unittest

import fla
from fla_wrap import feedback_prompt, run_gated


def scripted(replies):
    """Stub model: returns the replies in order and records the prompts it received."""
    seen = []

    def generate(prompt):
        seen.append(prompt)
        return replies[min(len(seen) - 1, len(replies) - 1)]

    generate.seen = seen
    return generate


class TestWrap(unittest.TestCase):
    refs = {"Answer": "Paris"}

    def test_first_attempt_admitted(self):
        model = scripted(["Answer: Paris\n2 + 2 = 4"])
        out = run_gated(model, "capital of France?", self.refs)
        self.assertEqual(out["emitted_text"], "Answer: Paris\n2 + 2 = 4")
        self.assertIsNone(out["silence"])
        self.assertEqual(out["attempt_count"], 1)

    def test_retry_uses_gate_feedback_then_admits(self):
        model = scripted(["Paris is lovely.\n2 + 2 = 5", "Answer: Paris\n2 + 2 = 4"])
        out = run_gated(model, "q", self.refs)
        self.assertEqual(out["attempt_count"], 2)
        self.assertEqual(out["emitted_text"], "Answer: Paris\n2 + 2 = 4")
        retry_prompt = model.seen[1]
        self.assertIn('"Paris is lovely.": open', retry_prompt)
        self.assertIn('"2 + 2 = 5": cannot', retry_prompt)
        self.assertIn("computes to 4 vs 5", retry_prompt)
        self.assertNotIn("Paris\n", retry_prompt.split("Lines not admitted:")[1])  # reference value not revealed

    def test_never_admitted_is_withheld_not_empty_success(self):
        out = run_gated(scripted(["free prose"]), "q", self.refs, max_attempts=3)
        self.assertEqual(out["emitted_text"], "")
        self.assertEqual(out["silence"], "withheld")
        self.assertEqual(out["attempt_count"], 3)

    def test_empty_model_reply_is_a_failed_attempt(self):
        out = run_gated(scripted(["", "   ", "Answer: Paris"]), "q", self.refs)
        self.assertEqual(out["attempt_count"], 3)
        self.assertEqual(out["attempts"][0]["checks"][0]["kind"], "empty_output")
        self.assertEqual(out["emitted_text"], "Answer: Paris")

    def test_tolerance_passes_through_and_is_recorded(self):
        out = run_gated(scripted(["Answer: paris"]), "q", self.refs, tolerance=fla.Tolerance(fold_case=True))
        self.assertEqual(out["emitted_text"], "Answer: paris")
        self.assertEqual(out["attempts"][0]["tolerances"], {"fold_case": True})

    def test_attempts_are_ledgered(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "wrap.jsonl"
            run_gated(scripted(["junk", "Answer: Paris"]), "q", self.refs, ledger=path)
            entries = fla.read_ledger(path)
            self.assertEqual([e["receipt"]["accepted"] for e in entries], [False, True])
            self.assertEqual(entries[0]["receipt"]["kind"], "gate_attempt")

    def test_max_attempts_validated(self):
        with self.assertRaises(ValueError):
            run_gated(scripted(["x"]), "q", max_attempts=0)

    def test_feedback_prompt_lists_only_non_admitted_lines(self):
        result = fla.gate_text("2 + 2 = 4\nnonsense", None)
        text = feedback_prompt("p", result)
        self.assertIn("nonsense", text)
        self.assertNotIn('"2 + 2 = 4"', text)


if __name__ == "__main__":
    unittest.main()
