import json
from fractions import Fraction
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from fla import (
    audit_text, append_receipt, check_equation, check_referenced_claims, decode_text,
    encode_text, even_transport, gate_text, mirrored_inverse, mv, quadratic, read_ledger,
    verify_invariants, Tolerance,
)


class TestFLA(unittest.TestCase):
    def test_invariants(self):
        self.assertTrue(all(verify_invariants().values()))

    def test_lossless_unicode_and_whitespace(self):
        examples = ["", "2 + 2 = 5", "\x00\x00", "leading \n trailing  ", "é 🧭 🇯🇵 𝄞\u200b", "0" * 2048]
        for sample in examples:
            z = encode_text(sample)
            self.assertEqual(decode_text(z), sample)
            for steps in [0, 1, 2, 17, -1, -5]:
                bz = mv(even_transport(steps), z)
                self.assertEqual(quadratic(z), quadratic(bz))
                recovered = mv(mirrored_inverse(steps), bz)
                self.assertEqual(recovered, z)
                self.assertEqual(decode_text(recovered), sample)
                result = audit_text(sample, steps)
                self.assertTrue(result["lossless_utf8_roundtrip"])

    def test_equation_checker(self):
        self.assertFalse(check_equation("2 + 2 = 5")["valid"])
        self.assertTrue(check_equation("2 + 2 = 4")["valid"])
        self.assertTrue(check_equation("0.1 + 0.2 = 0.3")["valid"])
        self.assertTrue(check_equation("(4 / 3) * 3 = 4")["valid"])
        with self.assertRaises((ValueError, SyntaxError)):
            check_equation("__import__('os') = 1")

    def test_reference_checker(self):
        result = check_referenced_claims({"country": "France", "count": 3, "guess": 2}, {"country": "France", "count": 4})
        self.assertEqual(result["claims"], {"country": "verified", "count": "contradicted", "guess": "unverified"})
        self.assertFalse(result["all_verified"])

    def test_reference_grade_silence_gate(self):
        self.assertEqual(gate_text("2 + 2 = 5")["emitted_text"], "")
        self.assertEqual(gate_text("2 + 2 = 4")["emitted_text"], "2 + 2 = 4")
        self.assertEqual(gate_text("Unsupported factual statement")["emitted_text"], "")
        self.assertEqual(gate_text("Answer: Paris", {"Answer": "Paris"})["emitted_text"], "Answer: Paris")
        self.assertEqual(gate_text("Answer: Lyon", {"Answer": "Paris"})["emitted_text"], "")
        self.assertEqual(gate_text("2 + 2 = 4\nUnsupported factual statement")["emitted_text"], "")

    def test_hash_ledger_tamper(self):
        with tempfile.TemporaryDirectory() as dir_name:
            path = Path(dir_name) / "fla.jsonl"
            first = append_receipt(path, audit_text("test"))
            second = append_receipt(path, check_equation("2+2=4"))
            self.assertEqual(len(read_ledger(path)), 2)
            self.assertEqual(first["seq"], 1)
            self.assertEqual(second["seq"], 2)
            content = path.read_text(encoding="utf-8")
            path.write_text(content.replace('"utf8_bytes":4', '"utf8_bytes":5'), encoding="utf-8")
            with self.assertRaises(ValueError):
                read_ledger(path)

    def test_ledger_blank_lines_tolerated_but_reorder_rejected(self):
        with tempfile.TemporaryDirectory() as dir_name:
            path = Path(dir_name) / "fla.jsonl"
            append_receipt(path, check_equation("2+2=4"))
            append_receipt(path, check_equation("1+1=2"))
            lines = path.read_text(encoding="utf-8").splitlines()
            path.write_text("\n" + lines[0] + "\n\n" + lines[1] + "\n\n", encoding="utf-8")
            self.assertEqual(len(read_ledger(path)), 2)
            path.write_text(lines[1] + "\n" + lines[0] + "\n", encoding="utf-8")
            with self.assertRaises(ValueError):
                read_ledger(path)

    def test_fixed_definitions(self):
        from fla import G, OMEGA, Q, difference, mm
        self.assertEqual(difference(mm(Q, OMEGA), mm(OMEGA, Q)), G)

    def test_gate_rejects_unsupported_forms(self):
        for text in ["2 + 2 = 4 = 4", "a = 4", "1/3 = 0.333", "Answer: Paris = capital", "", "   \n"]:
            self.assertEqual(gate_text(text, {"Answer": "Paris"})["emitted_text"], "", text)

    def test_claims_are_type_strict(self):
        self.assertEqual(check_referenced_claims({"n": 4}, {"n": "4"})["claims"], {"n": "contradicted"})


    def test_blank_candidate_is_neutral_silence(self):
        for text in ["", "  \n \n"]:
            r = gate_text(text)
            self.assertTrue(r["accepted"])
            self.assertEqual((r["emitted_text"], r["silence"], r["checks"]), ("", "neutral", []))

    def test_unproven_candidate_is_withheld_silence(self):
        r = gate_text("2 + 2 = 4\nunsupported prose")
        self.assertFalse(r["accepted"])
        self.assertEqual((r["emitted_text"], r["silence"]), ("", "withheld"))
        self.assertEqual([c["gate"] for c in r["checks"]], ["can", "open"])

    def test_gate_values_can_cannot_open(self):
        r = gate_text("Answer: Paris\nAnswer: Lyon\nOther: x", {"Answer": "Paris"})
        self.assertEqual([c["gate"] for c in r["checks"]][:2], ["can", "cannot"])
        self.assertEqual(r["checks"][2]["gate"], "open")
        self.assertIsNone(gate_text("2 + 2 = 4")["silence"])

    def test_tolerances_are_opt_in_and_recorded(self):
        refs = {"Answer": "Paris", "Count": "1000"}
        self.assertFalse(gate_text("Answer: paris", refs)["accepted"])
        r = gate_text("Answer:   paris", refs, Tolerance(fold_case=True, normalize_whitespace=True))
        self.assertTrue(r["accepted"])
        self.assertEqual(r["checks"][0]["match"], "normalized")
        self.assertFalse(gate_text("answer: Paris", refs, Tolerance(fold_case=True))["accepted"])  # keys stay exact
        self.assertEqual(r["tolerances"], {"fold_case": True, "normalize_whitespace": True})
        self.assertFalse(gate_text("Count: 1,000", refs)["accepted"])
        r = gate_text("Count: 1,000", refs, Tolerance(strip_thousands=True))
        self.assertEqual(r["checks"][0]["match"], "normalized")
        self.assertFalse(gate_text("Count: 1,0000", refs, Tolerance(strip_thousands=True))["accepted"])

    def test_epsilon_opt_in(self):
        self.assertFalse(gate_text("0.1 + 0.2 = 0.30001")["accepted"])
        r = gate_text("0.1 + 0.2 = 0.30001", None, Tolerance(epsilon=Fraction(1, 10000)))
        self.assertTrue(r["accepted"])
        self.assertEqual(r["checks"][0]["match"], "within_epsilon")
        self.assertEqual(r["tolerances"], {"epsilon": "1/10000"})
        self.assertFalse(gate_text("1 = 2", None, Tolerance(epsilon=Fraction(1, 10)))["accepted"])
        self.assertNotIn("epsilon", check_equation("1 = 1"))

    def test_accepted_value_sets(self):
        refs = {"Answer": ["Paris", "Paris, France"]}
        self.assertTrue(gate_text("Answer: Paris, France", refs)["accepted"])
        self.assertEqual(gate_text("Answer: Lyon", refs)["checks"][0]["gate"], "cannot")
        self.assertEqual(gate_text("Answer: Paris", {"Answer": []})["checks"][0]["gate"], "open")
        self.assertEqual(gate_text("Answer: 4", {"Answer": [4]})["checks"][0]["gate"], "open")

    def test_cli_exit_codes(self):
        here = Path(__file__).resolve().parent

        def run(*args):
            return subprocess.run([sys.executable, str(here / "fla.py"), *args], capture_output=True, text=True)

        self.assertEqual(run("gate", "2 + 2 = 4").returncode, 0)
        self.assertEqual(run("gate", "2 + 2 = 5").returncode, 1)
        self.assertEqual(run("gate", "").returncode, 0)
        self.assertEqual(run("check", "1 = 1.0001", "--epsilon", "1/1000").returncode, 0)
        self.assertEqual(run("check", "1 = 1.0001").returncode, 1)
        self.assertEqual(run("check", "1 = 1", "--epsilon", "x").returncode, 2)
        self.assertEqual(run("--version").stdout.strip(), "fla 1.2.0")


if __name__ == "__main__":
    unittest.main()
