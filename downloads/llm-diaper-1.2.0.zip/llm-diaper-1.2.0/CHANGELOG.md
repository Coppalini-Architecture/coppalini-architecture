# Changelog

## 1.2.0
- Typed silence: gate results carry `silence` = `null` (delivered), `"neutral"` (blank candidate, nothing owed) or `"withheld"` (output present, not fully proven). Per-line `gate` values `can` / `cannot` / `open`.
- Behaviour change: a blank candidate is now accepted as neutral silence (exit 0). Previously it was rejected (exit 1).
- Opt-in tolerances (`--fold-case`, `--normalize-whitespace`, `--strip-thousands`, `--epsilon`; `Tolerance` in Python). Default stays exact; active settings are recorded in every result and receipt.
- Reference values may be a list of accepted strings.
- `fla_wrap.run_gated`: generate → gate → feedback → regenerate, with per-attempt ledger receipts. An empty model reply counts as a failed attempt.
- Gate arithmetic checks now report `left_exact` / `right_exact`; verified lines report `match`.
- Packaging: `fla_wrap` module, version 1.2.0, README rewritten, runnable `example_wrap.py`.
- Tests: 10 → 25.

## 1.1.1
- Renamed to LLM Diaper (package `llm-diaper`; module and `fla` command unchanged).

## 1.1.0
- Ω stated explicitly; `read_ledger` ignores blank lines; `--version`; README scope notes; tests 6 → 10.

## 1.0
- Initial reference implementation.
