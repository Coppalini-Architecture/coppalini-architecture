"""Runnable demo of the retry wrapper with a stub model (no network, no API key).

    python example_wrap.py

Replace `stub_model` with a function that calls your model and returns its text.
"""
import json

from fla_wrap import run_gated

REFERENCES = {"Answer": "Paris"}
REPLIES = iter([
    "Paris is the capital of France, a lovely city.\n2 + 2 = 5",   # prose + wrong equation: withheld
    "Answer: Paris\n2 + 2 = 4",                                     # in grammar and proven: delivered
])


def stub_model(prompt: str) -> str:
    return next(REPLIES)


if __name__ == "__main__":
    out = run_gated(stub_model, "Capital of France, then 2 + 2.", REFERENCES, max_attempts=3)
    print(json.dumps(out, indent=2, ensure_ascii=False))
