#!/usr/bin/env python3
"""Validator kit runner (B-2).  Usage:
    python3 kit.py                run every card
    python3 kit.py --list         print the card table without running
    python3 kit.py --only S-4 E-1 run selected cards
    python3 kit.py --receipt      also write KIT_RECEIPT.json and KIT_RECEIPT.md

Per card: every file listed in cards.json is hashed first; a mismatch is reported as HASH-FAIL and the
card is not run.  A card PASSes only if its command exits 0 and prints its marker line.
Row format: id | claim | domain | command | PASS/FAIL | boundary | SHA-256 (of the card's entry script).
"""
import argparse, hashlib, json, os, platform, subprocess, sys, time
from pathlib import Path

HERE = Path(__file__).resolve().parent


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def run_card(c):
    d = HERE / "cards" / c["dir"]
    bad = [f for f, h in c["files"].items() if not (d / f).is_file() or sha(d / f) != h]
    if bad:
        return "HASH-FAIL", "changed or missing: " + ", ".join(bad), 0.0
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
    t = time.time()
    try:
        r = subprocess.run([sys.executable, c["script"]], cwd=d, capture_output=True, text=True, env=env, timeout=900)
    except subprocess.TimeoutExpired:
        return "FAIL", "timeout (900 s)", time.time() - t
    out = r.stdout + (("\n[stderr]\n" + r.stderr) if r.stderr.strip() else "")
    ok = r.returncode == 0 and c["marker"] in r.stdout
    return ("PASS" if ok else "FAIL"), out, time.time() - t


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--receipt", action="store_true")
    a = ap.parse_args()
    cards = json.loads((HERE / "cards.json").read_text(encoding="utf-8"))["cards"]
    if a.only:
        cards = [c for c in cards if c["id"] in a.only]
    rows = []
    for c in cards:
        if a.list:
            status, out, dt = "-", "", 0.0
        else:
            status, out, dt = run_card(c)
        rows.append((c, status, out, dt))
        print(f"{c['id']} | {c['claim']} | {c['domain']} | {c['command']} | {status} | {c['boundary']} | {c['sha256']}")
    if a.list:
        return 0
    fails = [c["id"] for c, s, _, _ in rows if s != "PASS"]
    print(f"\n{len(rows) - len(fails)}/{len(rows)} cards PASS" + (f"; not passing: {', '.join(fails)}" if fails else ""))
    if a.receipt:
        meta = dict(python=platform.python_version(), platform=platform.platform(),
                    utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))
        (HERE / "KIT_RECEIPT.json").write_text(json.dumps(dict(meta=meta, results=[
            dict(id=c["id"], status=s, seconds=round(dt, 2), sha256=c["sha256"], output=o) for c, s, o, dt in rows]),
            indent=1, ensure_ascii=False), encoding="utf-8")
        md = [f"# Kit receipt\n\nPython {meta['python']} · {meta['platform']} · {meta['utc']}\n",
              "| id | claim | domain | command | result | boundary | SHA-256 |", "|---|---|---|---|---|---|---|"]
        for c, s, o, dt in rows:
            md.append(f"| {c['id']} | {c['claim']} | {c['domain']} | `{c['command']}` | {s} | {c['boundary']} | `{c['sha256']}` |")
        (HERE / "KIT_RECEIPT.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
