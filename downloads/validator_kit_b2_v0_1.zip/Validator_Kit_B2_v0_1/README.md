# Validator Kit B-2 v0.1

One runner over twelve cards. Each card is a verifier script with its sources, bound by SHA-256 in `cards.json`.

    python3 kit.py                 # run all cards
    python3 kit.py --list          # print the card table without running
    python3 kit.py --only S-4 E-1  # selected cards
    python3 kit.py --receipt       # also write KIT_RECEIPT.json / KIT_RECEIPT.md

Row format: `id | claim | domain | command | PASS/FAIL | boundary | SHA-256`. The SHA-256 is that of the card's
entry script; `cards.json` lists the hash of every file the card reads. A changed or missing file gives
`HASH-FAIL` and the card does not run. A card passes only if it exits 0 and prints its marker line.

Requirements: Python 3.10+; numpy for C-1; sympy optional (S-5 adds a symbolic minor when present).
Full run takes about 40 s.

| id | script | origin |
|---|---|---|
| S-1 … S-8 | `cards/suture/` | `Suture_Audit_v0_2` (Cards 5 and 5a); per-file hashes match its `SHA256SUMS` |
| E-1 | `cards/exact_spine/verify_exact_spine.py` | Atomic–Linear packet `02_linear_infinity/` |
| L-1 | `cards/lorentz_cell/verify_lorentz_congruence_v0_1.py` | written for this kit (GL.9–GL.11b) |
| F-1 | `cards/four_paper/verify_four_papers_v0_3.py` | `physical_reality_field_v0_3.zip` (files byte-identical to the packet copy) |
| C-1 | `cards/chsh_matrix/quantum_time_chsh_verification.py` | Atomic–Linear packet `03_supporting_forms/` |

Not in the kit, by design:
- A standalone Time Scope verifier. None was located; F-1 carries only source-token guards for Card 3.
- `CONSTRUCTION_SPINE.md`, which E-1 cites for its differential-geometric statements; it is not in the v0.1 packet.
- Clear Onyx atomic receipts (H, He, Li): track A-1, not yet issued.
- The CCLQG Eq. 44 criterion: it is `OPEN` in the source.

Each card's boundary is part of its row. A PASS establishes the stated claim in the stated domain and nothing wider;
open edges for the Suture cards are R-1 … R-12 in `Suture_Audit_v0_2/RESIDUAL_LEDGER_v0_2.md`.

To add a card: put the script and every file it reads in `cards/<dir>/`, then add its entry to `cards.json` with
`claim`, `domain`, `command`, `boundary`, `marker` and the SHA-256 of each file.
