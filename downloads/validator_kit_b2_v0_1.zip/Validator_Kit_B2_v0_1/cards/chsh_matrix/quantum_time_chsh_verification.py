"""Exact-model numerical verification: SU(2) phase and CHSH spectrum."""
import numpy as np

I = np.eye(2, dtype=complex)
sx = np.array([[0, 1], [1, 0]], dtype=complex)
sz = np.array([[1, 0], [0, -1]], dtype=complex)
hbar = omega = 1.0
H = hbar * omega * sz / 2
xi = -1j * sz
g = -1j * sx

def U(t):
    return np.diag([np.exp(-1j*omega*t/2), np.exp(1j*omega*t/2)])

ts = np.linspace(0, 4*np.pi/omega, 401)
assert np.allclose(xi @ xi, -I)
assert np.allclose(g @ g, -I)
assert np.allclose(np.linalg.matrix_power(g, 4), I)
assert np.allclose(U(2*np.pi/omega), -I)
assert np.allclose(U(4*np.pi/omega), I)
assert all(np.allclose(U(t).conj().T @ U(t), I) for t in ts)
assert all(np.allclose(g @ U(t) @ g.conj().T, U(-t)) for t in ts)

A, Ap = sz, sx
B = (sz + sx)/np.sqrt(2)
Bp = (sz - sx)/np.sqrt(2)
C = np.kron(A, B+Bp) + np.kron(Ap, B-Bp)
spectrum = np.linalg.eigvalsh(C)
assert np.allclose(spectrum, [-2*np.sqrt(2), 0, 0, 2*np.sqrt(2)])
print("SU(2) phase and central-square checks: PASS")
print("CHSH spectrum:", spectrum)
print("CHSH operator norm:", np.linalg.norm(C, 2))
