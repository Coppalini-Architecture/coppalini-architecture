#!/usr/bin/env python3
"""Dependency-free exact checks for the golden axial-return spine.

The scalar field is Q(sqrt(5)); every reported matrix and projective identity
is checked with rational arithmetic. Differential-geometric calculations are
proved in CONSTRUCTION_SPINE.md rather than approximated here.
"""

from dataclasses import dataclass
from fractions import Fraction
from math import gcd


@dataclass(frozen=True)
class K:
    """a + b sqrt(5), with a,b rational."""

    a: Fraction = Fraction(0)
    b: Fraction = Fraction(0)

    @staticmethod
    def make(a=0, b=0):
        return K(Fraction(a), Fraction(b))

    def __add__(self, other):
        other = scalar(other)
        return K(self.a + other.a, self.b + other.b)

    __radd__ = __add__

    def __neg__(self):
        return K(-self.a, -self.b)

    def __sub__(self, other):
        return self + (-scalar(other))

    def __rsub__(self, other):
        return scalar(other) - self

    def __mul__(self, other):
        other = scalar(other)
        return K(
            self.a * other.a + 5 * self.b * other.b,
            self.a * other.b + self.b * other.a,
        )

    __rmul__ = __mul__

    def inverse(self):
        norm = self.a * self.a - 5 * self.b * self.b
        if norm == 0:
            raise ZeroDivisionError
        return K(self.a / norm, -self.b / norm)

    def __truediv__(self, other):
        return self * scalar(other).inverse()


def scalar(value):
    return value if isinstance(value, K) else K.make(value)


@dataclass(frozen=True)
class CK:
    """Complex number with coefficients in Q(sqrt(5))."""

    re: K
    im: K

    def __add__(self, other):
        return CK(self.re + other.re, self.im + other.im)

    def __neg__(self):
        return CK(-self.re, -self.im)

    def __sub__(self, other):
        return self + (-other)

    def __mul__(self, other):
        return CK(
            self.re * other.re - self.im * other.im,
            self.re * other.im + self.im * other.re,
        )


def matrix(rows):
    return [[scalar(entry) for entry in row] for row in rows]


def madd(left, right):
    return [
        [left[i][j] + right[i][j] for j in range(len(left[0]))]
        for i in range(len(left))
    ]


def mscale(factor, value):
    factor = scalar(factor)
    return [[factor * entry for entry in row] for row in value]


def mmul(left, right):
    return [
        [
            sum(
                (left[i][k] * right[k][j] for k in range(len(right))),
                K.make(),
            )
            for j in range(len(right[0]))
        ]
        for i in range(len(left))
    ]


def mpow(value, exponent):
    result = matrix([[1, 0], [0, 1]])
    base = value
    power = exponent
    while power:
        if power & 1:
            result = mmul(result, base)
        base = mmul(base, base)
        power //= 2
    return result


def transpose(value):
    return [list(row) for row in zip(*value)]


def determinant(value):
    return value[0][0] * value[1][1] - value[0][1] * value[1][0]


def pmul(left, right):
    """Multiply coefficient lists in ascending degree order."""
    out = [K.make() for _ in range(len(left) + len(right) - 1)]
    for i, a in enumerate(left):
        for j, b in enumerate(right):
            out[i + j] = out[i + j] + a * b
    return out


def pscale(factor, value):
    return [scalar(factor) * entry for entry in value]


def check(label, condition):
    if not condition:
        raise AssertionError(label)
    print(f"PASS  {label}")


def fibonacci(index):
    """Exact Fibonacci number F_index with F_0=0 and F_1=1."""
    left, right = 0, 1
    for _ in range(index):
        left, right = right, left + right
    return left


def lucas(index):
    """Exact Lucas number L_index=F_(index-1)+F_(index+1)."""
    if index == 0:
        return 2
    return fibonacci(index - 1) + fibonacci(index + 1)


def is_prime(value):
    if value < 2:
        return False
    if value % 2 == 0:
        return value == 2
    divisor = 3
    while divisor * divisor <= value:
        if value % divisor == 0:
            return False
        divisor += 2
    return True


def multiplicative_order(base, modulus):
    if gcd(base, modulus) != 1:
        raise ValueError("multiplicative order requires coprime inputs")
    value = 1
    for exponent in range(1, modulus + 1):
        value = (value * base) % modulus
        if value == 1:
            return exponent
    raise AssertionError("order not found")


def main():
    one = K.make(1)
    sqrt5 = K.make(0, 1)
    inv_sqrt5 = K.make(0, Fraction(1, 5))
    phi = K.make(Fraction(1, 2), Fraction(1, 2))
    psi = K.make(Fraction(1, 2), Fraction(-1, 2))

    identity = matrix([[1, 0], [0, 1]])
    zero2 = matrix([[0, 0], [0, 0]])
    c1 = matrix([[0, -1], [1, 0]])
    omega = mscale(-1, c1)
    q = matrix([[1, 1], [1, 0]])
    g = madd(mmul(c1, q), mscale(-1, mmul(q, c1)))
    h = mscale(inv_sqrt5, g)
    s_mirror = mscale(
        inv_sqrt5,
        madd(mscale(2, q), mscale(-1, identity)),
    )
    j_phase = mmul(q, h)
    b_metric = mscale(-1, mmul(omega, j_phase))
    m0 = mmul(q, omega)
    ell = mscale(inv_sqrt5, madd(q, mscale(2, identity)))
    ell_inverse = mscale(inv_sqrt5, matrix([[2, -1], [-1, 3]]))

    check("C_1^2=-I", mmul(c1, c1) == mscale(-1, identity))
    check("C_1^4=I", mmul(mmul(c1, c1), mmul(c1, c1)) == identity)
    check("Omega C_1=I", mmul(omega, c1) == identity)
    check("Q^2=Q+I", mmul(q, q) == madd(q, identity))
    check("Q^5=[[8,5],[5,3]]", mpow(q, 5) == matrix([[8, 5], [5, 3]]))
    check("Q^9=[[55,34],[34,21]]", mpow(q, 9) == matrix([[55, 34], [34, 21]]))
    check("137=11^2+4^2", 11 * 11 + 4 * 4 == 137)
    check("137=1+4*34", 1 + 4 * 34 == 137)
    first_family_solutions = [
        m
        for m in range(1, 65)
        if fibonacci(m) + fibonacci(2 * m - 1) == m * m
    ]
    second_family_solutions = [
        m
        for m in range(1, 65)
        if lucas(m + 1) ** 2 + m * m
        == 1 + m * fibonacci(2 * m + 1)
    ]
    check("first 137 convergence family has only m=4 through m=64", first_family_solutions == [4])
    check("second 137 convergence family has only m=4 through m=64", second_family_solutions == [4])
    check("137 is prime", is_prime(137))
    check("4^17=-1 mod 137", pow(4, 17, 137) == 136)
    check("ord_137(4)=34", multiplicative_order(4, 137) == 34)
    smaller_order_34_primes = [
        p for p in range(2, 137) if is_prime(p) and gcd(4, p) == 1
        and multiplicative_order(4, p) == 34
    ]
    check("137 is the least prime with ord_p(4)=34", smaller_order_34_primes == [])
    check("1277 is prime", is_prime(1277))
    check("34 does not divide 1277-1", (1277 - 1) % 34 != 0)
    check("ord_1277(4)=638", multiplicative_order(4, 1277) == 638)
    check("1277 quotient order is 2, not 4", (1277 - 1) // 638 == 2)
    check("gcd(4,137)=1", gcd(4, 137) == 1)
    check("lcm(4,137)=548", (4 * 137) // gcd(4, 137) == 548)
    crt_addresses = {(n % 4, n % 137) for n in range(548)}
    check("Z_548 -> Z_4 x Z_137 is bijective", len(crt_addresses) == 548)
    first_joint_return = next(
        n for n in range(1, 549) if n % 4 == 0 and n % 137 == 0
    )
    check("first Phase_4/Mirror_137 joint return is 548", first_joint_return == 548)
    check("G=[C_1,Q]", g == matrix([[-2, 1], [1, 2]]))
    check("G^2=5I", mmul(g, g) == mscale(5, identity))
    check(
        "Q^T Omega Q=-Omega",
        mmul(mmul(transpose(q), omega), q) == mscale(-1, omega),
    )
    check(
        "Q^T G Q=-G",
        mmul(mmul(transpose(q), g), q) == mscale(-1, g),
    )
    check("M_0=Q Omega", m0 == matrix([[-1, 1], [0, 1]]))
    check("M_0^2=I", mmul(m0, m0) == identity)
    check("det L=1", determinant(ell) == one)
    check("L^2=Q^2", mmul(ell, ell) == mmul(q, q))
    check("L L^-1=I", mmul(ell, ell_inverse) == identity)
    check("H^2=I", mmul(h, h) == identity)
    check("H is g_i-self-adjoint", transpose(h) == h)
    check("tr H=0", h[0][0] + h[1][1] == K.make())
    check("det H=-1", determinant(h) == K.make(-1))
    check("S^2=I", mmul(s_mirror, s_mirror) == identity)
    check("S is symmetric", transpose(s_mirror) == s_mirror)
    check("S^T S=I", mmul(transpose(s_mirror), s_mirror) == identity)
    check(
        "S^T G+G S=0",
        madd(mmul(transpose(s_mirror), g), mmul(g, s_mirror)) == zero2,
    )
    check("S H=Omega", mmul(s_mirror, h) == omega)
    check("H S=Omega^-1", mmul(h, s_mirror) == mscale(-1, omega))
    check("J=QH and J^2=-I", mmul(j_phase, j_phase) == mscale(-1, identity))
    check("B=-Omega J is symmetric", transpose(b_metric) == b_metric)
    check(
        "B has exact positive normal form",
        b_metric
        == mscale(inv_sqrt5, matrix([[2, -1], [-1, 3]])),
    )
    check("det B=1", determinant(b_metric) == one)
    check("tr B=sqrt(5)", b_metric[0][0] + b_metric[1][1] == sqrt5)
    check("J^T B J=B", mmul(mmul(transpose(j_phase), b_metric), j_phase) == b_metric)
    check("J^T Omega J=Omega", mmul(mmul(transpose(j_phase), omega), j_phase) == omega)
    check("B J=Omega", mmul(b_metric, j_phase) == omega)
    check("M_0 H=L", mmul(m0, h) == ell)
    check("H M_0=L^-1", mmul(h, m0) == ell_inverse)
    check("H C_1 H=C_1^-1", mmul(mmul(h, c1), h) == mscale(-1, c1))
    check("H L H=L^-1", mmul(mmul(h, ell), h) == ell_inverse)

    check("Phi+Psi=1", phi + psi == one)
    check("Phi Psi=-1", phi * psi == K.make(-1))
    check("Phi-Psi=sqrt(5)", phi - psi == sqrt5)
    check("Phi^2=Phi+1", phi * phi == phi + one)

    phi_inverse = phi.inverse()
    cosh_log_phi = (phi + phi_inverse) / 2
    sinh_log_phi = (phi - phi_inverse) / 2
    check("cosh(log Phi)=sqrt(5)/2", cosh_log_phi == sqrt5 / 2)
    check("sinh(log Phi)=1/2", sinh_log_phi == K.make(Fraction(1, 2)))
    check(
        "exp((log Phi)S)=L",
        madd(
            mscale(cosh_log_phi, identity),
            mscale(sinh_log_phi, s_mirror),
        )
        == ell,
    )
    check(
        "L^T G L=G",
        mmul(mmul(transpose(ell), g), ell) == g,
    )
    check(
        "L^T L=L^2=Q^2",
        mmul(transpose(ell), ell) == mmul(ell, ell) == mmul(q, q),
    )
    check("raw linear L does not preserve g_i", mmul(transpose(ell), ell) != identity)

    v_phi = matrix([[phi], [one]])
    v_psi = matrix([[psi], [one]])
    check(
        "v_Phi is G-null",
        mmul(mmul(transpose(v_phi), g), v_phi) == matrix([[0]]),
    )
    check(
        "v_Psi is G-null",
        mmul(mmul(transpose(v_psi), g), v_psi) == matrix([[0]]),
    )
    check("L v_Phi=Phi v_Phi", mmul(ell, v_phi) == mscale(phi, v_phi))
    check(
        "L v_Psi=Phi^-1 v_Psi",
        mmul(ell, v_psi) == mscale(phi_inverse, v_psi),
    )

    # In two dimensions Ric=-g and R=-2 give an identically zero Einstein
    # tensor. This is the dimensional obstruction requiring completion data.
    eta2 = matrix([[-1, 0], [0, 1]])
    ricci_ads2 = mscale(-1, eta2)
    einstein2 = madd(ricci_ads2, eta2)
    check("2D AdS Einstein tensor vanishes", einstein2 == zero2)

    # Unit-radius Bertotti-Robinson orthonormal-frame check. Scaling restores
    # the general ell dependence. Signature is (-,+,+,+), F_01=1.
    eta4 = matrix(
        [
            [-1, 0, 0, 0],
            [0, 1, 0, 0],
            [0, 0, 1, 0],
            [0, 0, 0, 1],
        ]
    )
    f_br = matrix(
        [
            [0, 1, 0, 0],
            [-1, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
        ]
    )
    ff_cov = mmul(mmul(f_br, eta4), transpose(f_br))
    f_squared = K.make(-2)
    einstein_maxwell_rhs = mscale(
        2,
        madd(ff_cov, mscale(-f_squared / 4, eta4)),
    )
    ricci_br = matrix(
        [
            [1, 0, 0, 0],
            [0, -1, 0, 0],
            [0, 0, 1, 0],
            [0, 0, 0, 1],
        ]
    )
    check(
        "unit Bertotti-Robinson Einstein-Maxwell normalization",
        einstein_maxwell_rhs == ricci_br,
    )

    xi_matrix = matrix([[-1, phi], [1, -psi]])
    check("det xi_ax=-sqrt(5)", determinant(xi_matrix) == -sqrt5)

    # The golden geodesic has center 1/2 and radius^2 5/4.
    center = K.make(Fraction(1, 2))
    radius_squared = K.make(Fraction(5, 4))
    check("Phi is an ideal endpoint", (phi - center) * (phi - center) == radius_squared)
    check("Psi is an ideal endpoint", (psi - center) * (psi - center) == radius_squared)
    check("i lies on the golden axis", center * center + one == radius_squared)
    check(
        "axis tangent at i is (2,1)/sqrt(5)",
        K.make(Fraction(-1, 2)) * K.make(2) + one == K.make(),
    )

    # xi(i)=-i Phi, checked without division:
    # Phi-i = (-i Phi)(i-Psi).
    i_point = CK(K.make(), one)
    phi_complex = CK(phi, K.make())
    psi_complex = CK(psi, K.make())
    minus_i_phi = CK(K.make(), -phi)
    check(
        "xi(i)=-i Phi",
        phi_complex - i_point == minus_i_phi * (i_point - psi_complex),
    )

    # L has the same projective action as [[3,1],[1,2]].  Cross-multiply
    # xi(Lz)=Phi^-2 xi(z) as a polynomial identity in z.
    a_num = [2 * phi - one, phi - 3]
    a_den = [one - 2 * psi, 3 - psi]
    xi_num = [phi, -one]
    xi_den = [-psi, one]
    phi_inverse_squared = (phi * phi).inverse()

    # M_0 acts as z -> 1-z. In the axial chart it is inversion.
    m0_num = [phi - one, one]
    m0_den = [one - psi, -one]
    check(
        "xi(M_0 z)=1/xi(z)",
        pmul(m0_num, xi_num) == pmul(m0_den, xi_den),
    )

    # H has the raw rational action (-2z+1)/(z+2); it becomes scaled
    # inversion. Its genuine H^+ reflection action additionally conjugates z.
    h_num = [2 * phi - one, phi + 2]
    h_den = [one - 2 * psi, -2 - psi]
    check(
        "xi(H z)=Phi^2/xi(z)",
        pmul(h_num, xi_num)
        == pscale(phi * phi, pmul(h_den, xi_den)),
    )

    check(
        "xi(Lz)=Phi^-2 xi(z)",
        pmul(a_num, xi_den)
        == pscale(phi_inverse_squared, pmul(xi_num, a_den)),
    )

    print("\nAll exact algebraic and projective checks passed.")


if __name__ == "__main__":
    main()
