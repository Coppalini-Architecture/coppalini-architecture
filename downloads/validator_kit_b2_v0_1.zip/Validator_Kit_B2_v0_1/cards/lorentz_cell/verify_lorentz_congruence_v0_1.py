"""Exact receipt for the Gravity Light Lorentz congruence cell (GL.9-GL.11b).

Field: Q(sqrt2, sqrt5), basis (1, sqrt2, sqrt5, sqrt10), Fraction coefficients.
  A_Lor = [[sqrt(5/2), 0], [1/sqrt2, sqrt2]],  eta_{1,1} = diag(-1,1),  G = [[-2,1],[1,2]].
Checks
  L1  A^T eta_{1,1} A = G                               (GL.10)
  L2  (A (+) I_2)^T eta_{3,1} (A (+) I_2) = G (+) I_2          (GL.11)
  L3  det G = -5 < 0, so G has signature (1,1)           (Lorentzian)
  L4  G(l,l) = 0 for l = (1, (-1 +- sqrt5)/2)            (GL.11b null directions, as in Prop. 'Fixed null directions')
  L5  source guard: GL.9, GL.10, GL.11 tokens in 01_gravity_light.tex
  N1-N3 negative controls: eta = diag(1,-1); A with its (2,1) entry zeroed; A with sqrt2 -> 1.
Not checked here: the boost B_t and the isometric inclusion iota_x (GL.11a, GL.11c) -- those are
statements about a curved spacetime and a one-parameter group, not about this matrix cell.
"""
from __future__ import annotations
from fractions import Fraction as Fr
from pathlib import Path

ROOT = Path(__file__).resolve().parent


class F:
    """a + b r2 + c r5 + d r10, with r2 r5 = r10."""
    __slots__ = ("v",)
    _T = {  # product of basis elements: (i,j) -> (index, coefficient)
        (0, 0): (0, 1), (0, 1): (1, 1), (0, 2): (2, 1), (0, 3): (3, 1),
        (1, 0): (1, 1), (1, 1): (0, 2), (1, 2): (3, 1), (1, 3): (2, 2),
        (2, 0): (2, 1), (2, 1): (3, 1), (2, 2): (0, 5), (2, 3): (1, 5),
        (3, 0): (3, 1), (3, 1): (2, 2), (3, 2): (1, 5), (3, 3): (0, 10),
    }

    def __init__(self, a=0, b=0, c=0, d=0):
        self.v = (Fr(a), Fr(b), Fr(c), Fr(d))

    @staticmethod
    def co(x):
        return x if isinstance(x, F) else F(x)

    def __add__(s, o):
        o = F.co(o)
        return F(*[x + y for x, y in zip(s.v, o.v)])
    __radd__ = __add__

    def __neg__(s):
        return F(*[-x for x in s.v])

    def __sub__(s, o):
        return s + (-F.co(o))

    def __mul__(s, o):
        o = F.co(o)
        out = [Fr(0)] * 4
        for i in range(4):
            for j in range(4):
                k, c = F._T[(i, j)]
                out[k] += s.v[i] * o.v[j] * c
        return F(*out)
    __rmul__ = __mul__

    def __eq__(s, o):
        return s.v == F.co(o).v

    def __hash__(s):
        return hash(s.v)


R2, R5, R10 = F(0, 1), F(0, 0, 1), F(0, 0, 0, 1)
HALF = Fr(1, 2)
A_LOR = [[R10 * HALF, F(0)], [R2 * HALF, R2]]          # sqrt(5/2) = sqrt10/2 ; 1/sqrt2 = sqrt2/2
ETA11 = [[F(-1), F(0)], [F(0), F(1)]]
G = [[F(-2), F(1)], [F(1), F(2)]]


def mm(a, b):
    return [[sum((a[i][k] * b[k][j] for k in range(len(b))), F(0)) for j in range(len(b[0]))] for i in range(len(a))]


def tr(a):
    return [[a[j][i] for j in range(len(a))] for i in range(len(a[0]))]


def eqm(a, b):
    return all(a[i][j] == b[i][j] for i in range(len(a)) for j in range(len(a[0])))


def direct_sum(a, b):
    n, m = len(a), len(b)
    out = [[F(0)] * (n + m) for _ in range(n + m)]
    for i in range(n):
        for j in range(n):
            out[i][j] = a[i][j]
    for i in range(m):
        for j in range(m):
            out[n + i][n + j] = b[i][j]
    return out


def cong(a, eta):
    return mm(mm(tr(a), eta), a)


def main() -> None:
    I2 = [[F(1), F(0)], [F(0), F(1)]]
    assert eqm(cong(A_LOR, ETA11), G)                                         # L1
    eta31 = direct_sum(ETA11, I2)
    assert eqm(cong(direct_sum(A_LOR, I2), eta31), direct_sum(G, I2))         # L2
    det_g = G[0][0] * G[1][1] - G[0][1] * G[1][0]
    assert det_g == F(-5)                                                     # L3
    for sign in (1, -1):                                                      # L4: l = (1, (-1 + sign*sqrt5)/2)
        l = [F(1), F(Fr(-1, 2)) + R5 * (Fr(sign, 2))]
        q = sum((l[i] * G[i][j] * l[j] for i in range(2) for j in range(2)), F(0))
        assert q == F(0)
    src = (ROOT / "01_gravity_light.tex").read_text(encoding="utf-8")          # L5
    for tok in ("\\tag{GL.9}", "\\tag{GL.10}", "\\tag{GL.11}", "\\sqrt{5/2}&0", "1/\\sqrt2&\\sqrt2",
                "A_{\\rm Lor}^{\\mathsf T}\\eta_{1,1}A_{\\rm Lor}=G",
                "\\widetilde A^{\\mathsf T}\\eta_{3,1}\\widetilde A=G\\oplus I_2"):
        assert tok in src, tok
    # negative controls
    assert not eqm(cong(A_LOR, [[F(1), F(0)], [F(0), F(-1)]]), G)             # N1
    assert not eqm(cong([[A_LOR[0][0], F(0)], [F(0), A_LOR[1][1]]], ETA11), G)  # N2
    assert not eqm(cong([[A_LOR[0][0], F(0)], [A_LOR[1][0], F(1)]], ETA11), G)  # N3
    print("PASS: Lorentz congruence cell GL.9-GL.11b (exact, Q(sqrt2,sqrt5))")
    print("A_Lor^T eta_{1,1} A_Lor = G; (A (+) I2)^T eta_{3,1} (A (+) I2) = G (+) I2; det G = -5; G(l+-,l+-) = 0; 3 negative controls rejected")


if __name__ == "__main__":
    main()
