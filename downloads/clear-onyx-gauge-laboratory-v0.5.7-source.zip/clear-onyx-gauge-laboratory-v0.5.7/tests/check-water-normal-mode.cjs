'use strict';

const assert = require('node:assert/strict');
const Core = require('../src/core.js');

function waterReceipt() {
  const water = Core.makeEngine('water', 160, 112);
  const initial = water.read();
  assert.ok(Number.isFinite(initial.energyProxy), 'initial mode energy is finite');
  assert.ok(initial.equationResidual < 1e-12, `initial equation residual ${initial.equationResidual}`);
  assert.ok(initial.comResidual < 1e-12, `initial centre-of-mass residual ${initial.comResidual}`);

  water.step(10000);
  const unforced = water.read();
  assert.ok(Math.abs(unforced.energyDrift) < 1e-9, `unforced energy drift ${unforced.energyDrift}`);
  assert.ok(unforced.stepResidual < 1e-12, `exact-step residual ${unforced.stepResidual}`);
  assert.ok(unforced.equationResidual < 1e-12, `unforced equation residual ${unforced.equationResidual}`);
  assert.ok(unforced.comResidual < 1e-12, `unforced centre-of-mass residual ${unforced.comResidual}`);
  assert.match(water.audit(unforced), /^PASS/, 'unforced normal-mode receipt passes');

  const energyBeforeKick = unforced.energyProxy;
  water.inject(water.width * .76, water.height * .28);
  const afterKick = water.read();
  assert.ok(Math.abs(afterKick.energyProxy - energyBeforeKick) > 1e-6, 'declared velocity impulse changes the energy reference');
  water.step(10000);
  const postKick = water.read();
  assert.ok(Math.abs(postKick.energyDrift) < 1e-9, `post-kick energy drift ${postKick.energyDrift}`);
  assert.ok(postKick.stepResidual < 1e-12, `post-kick exact-step residual ${postKick.stepResidual}`);
  assert.ok(postKick.comResidual < 1e-12, `post-kick centre-of-mass residual ${postKick.comResidual}`);

  const corruptAccelerationResidual = water.modeEquationResidual([1, -1]);
  assert.ok(corruptAccelerationResidual > 1e-2, `corrupted acceleration must fail (${corruptAccelerationResidual})`);
  return {
    initialEnergy: initial.energyProxy,
    unforcedEnergyDrift: unforced.energyDrift,
    exactStepResidual: unforced.stepResidual,
    postKickEnergyDrift: postKick.energyDrift,
    centreOfMassResidual: postKick.comResidual,
    corruptAccelerationResidual
  };
}

console.log(JSON.stringify({ waterNormalMode: waterReceipt() }, null, 2));
