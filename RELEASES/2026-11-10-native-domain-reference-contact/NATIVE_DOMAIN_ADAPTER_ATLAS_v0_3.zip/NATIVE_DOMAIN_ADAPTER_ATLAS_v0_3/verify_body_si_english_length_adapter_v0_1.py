#!/usr/bin/env python3
"""Exact verifier for the Body–SI–English Length Adapter v0.1.

This verifier checks conventional unit transport using Fraction only. It does
not assert a value for any particular body measurement.
"""

from fractions import Fraction
import re


F = Fraction
M_PER_UNIT = {
    "in": F(127, 5000),
    "ft_intl": F(381, 1250),
    "yd": F(1143, 1250),
    "fur": F(25146, 125),
    "mi": F(201168, 125),
    "mm": F(1, 1000),
    "m": F(1),
    "km": F(1000),
}
ALIASES = {
    "inch": "in", "inches": "in", "in": "in",
    "foot": "ft_intl", "feet": "ft_intl", "ft": "ft_intl", "ft_intl": "ft_intl",
    "yard": "yd", "yards": "yd", "yd": "yd",
    "furlong": "fur", "furlongs": "fur", "fur": "fur",
    "mile": "mi", "miles": "mi", "mi": "mi",
    "millimetre": "mm", "millimeter": "mm", "mm": "mm",
    "metre": "m", "meter": "m", "m": "m",
    "kilometre": "km", "kilometer": "km", "km": "km",
}
REJECTED = {"second", "seconds", "s", "survey_foot", "survey_feet", "foot_anatomical"}
NUMBER_UNIT = re.compile(r"^\s*([+-]?\d+(?:/\d+)?)\s+([A-Za-z_]+)\s*$")


def parse_length(expression: str) -> Fraction:
    match = NUMBER_UNIT.match(expression)
    if not match:
        raise ValueError("expected '<rational numeral> <typed length unit>'")
    number, word = match.groups()
    if word in REJECTED:
        raise ValueError(f"refused unit office: {word}")
    unit = ALIASES.get(word)
    if unit is None:
        raise ValueError(f"unknown or untyped length unit: {word}")
    return Fraction(number) * M_PER_UNIT[unit]


def to_unit(value_m: Fraction, unit: str) -> Fraction:
    if unit not in M_PER_UNIT:
        raise ValueError("target must be a declared canonical length unit")
    return value_m / M_PER_UNIT[unit]


checks = 0


def equal(label: str, observed, expected) -> None:
    global checks
    if observed != expected:
        raise AssertionError(f"FAIL {label}: {observed!r} != {expected!r}")
    checks += 1
    print(f"PASS {label}")


def rejected(label: str, expression: str) -> None:
    global checks
    try:
        parse_length(expression)
    except ValueError:
        checks += 1
        print(f"PASS {label}")
        return
    raise AssertionError(f"FAIL {label}: expression was admitted: {expression!r}")


equal("U1-1 international foot exact", M_PER_UNIT["ft_intl"], F(381, 1250))
equal("U1-2 inch exact", M_PER_UNIT["in"], F(127, 5000))
equal("U1-3 yard exact", M_PER_UNIT["yd"], 3 * M_PER_UNIT["ft_intl"])
equal("U1-4 furlong equals 660 feet", M_PER_UNIT["fur"], 660 * M_PER_UNIT["ft_intl"])
equal("U1-5 furlong metres exact", M_PER_UNIT["fur"], F(25146, 125))
equal("U1-6 mile equals 5280 feet", M_PER_UNIT["mi"], 5280 * M_PER_UNIT["ft_intl"])
equal("U1-7 mile metres exact", M_PER_UNIT["mi"], F(201168, 125))
equal("U1-8 metric prefix transport", 1000 * M_PER_UNIT["mm"], M_PER_UNIT["m"])
equal("U1-9 twelve inches equals one foot", parse_length("12 inches"), parse_length("1 foot"))
equal("U1-10 one third yard equals one foot", parse_length("1/3 yard"), parse_length("1 ft"))
equal("U1-11 six feet SI record", parse_length("6 feet"), F(2286, 1250))
equal("U1-12 inverse canonical feet", to_unit(parse_length("6 feet"), "ft_intl"), F(6))

# A finite-resolution body record: 6 ft +/- 1/16 in. Conversion of its
# interval endpoints is exact even though the physical reading has resolution.
half_width = F(1, 16) * M_PER_UNIT["in"]
body_interval = (parse_length("6 feet") - half_width, parse_length("6 feet") + half_width)
equal("U1-13 calibrated body interval lower endpoint", body_interval[0], F(2286, 1250) - F(127, 80000))
equal("U1-14 calibrated body interval upper endpoint", body_interval[1], F(2286, 1250) + F(127, 80000))

rejected("N1 bare numeral refused", "6")
rejected("N2 time unit refused", "6 seconds")
rejected("N3 survey-foot tag refused", "6 survey_foot")
rejected("N4 anatomical foot token refused", "6 foot_anatomical")

if checks != 18:
    raise AssertionError(f"internal count mismatch: {checks}")
print(f"RESULT: {checks}/{checks} PASS — exact Fraction arithmetic only")
