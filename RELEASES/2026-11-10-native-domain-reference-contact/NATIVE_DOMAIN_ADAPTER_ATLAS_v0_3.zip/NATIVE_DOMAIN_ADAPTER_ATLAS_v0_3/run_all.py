#!/usr/bin/env python3
"""Hash-gated runner for Native Domain Adapter Atlas v0.3."""

from __future__ import annotations

import hashlib
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile


ROOT = Path(__file__).resolve().parent


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def check_manifest() -> None:
    lines = (ROOT / "SHA256SUMS").read_text(encoding="utf-8").splitlines()
    checked = 0
    for line in lines:
        if not line.strip():
            continue
        expected, relative = line.split("  ", 1)
        path = ROOT / relative
        actual = sha256(path)
        if actual != expected:
            raise AssertionError(f"HASH-FAIL {relative}: {actual} != {expected}")
        checked += 1
    print(f"PASS SHA256SUMS ({checked} files)")


def run(command: list[str], cwd: Path) -> None:
    print("RUN", " ".join(command))
    subprocess.run(command, cwd=cwd, check=True)


def main() -> None:
    check_manifest()
    run([sys.executable, "-I", "verify_body_si_english_length_adapter_v0_1.py"], ROOT)
    run([sys.executable, "-I", "verify_source_bindings_v0_3.py"], ROOT)
    with tempfile.TemporaryDirectory(prefix="atlas-v03-lineage-") as temp:
        destination = Path(temp)
        with zipfile.ZipFile(ROOT / "lineage/NATIVE_DOMAIN_ADAPTER_ATLAS_v0_2.zip") as archive:
            archive.extractall(destination)
        inherited = destination / "NATIVE_DOMAIN_ADAPTER_ATLAS_v0_2"
        run([sys.executable, "-I", "run_all.py"], inherited)
    print("OVERALL: PASS — v0.3 plus preserved v0.2 lineage")


if __name__ == "__main__":
    main()
