# Reference contact and novelty gate

## Exact distinction

`THE_EMPIRICAL_INPUT_REGISTER_v0_1.md`, §14, assigns a prospective gate to
**new predictive physical content**: the predicted value/range and acceptance
rule are frozen before a held-out datum is read. That certificate is the
correct gate for a newly claimed Architecture-derived number, effect, or
empirical discriminator.

`PHYSICAL_ADAPTER_CERTIFICATE_v0_1.md` assigns a different completion form to
an existing physical carrier: a declared map, preserved structure, units,
observable, outside receipt, uncertainty, rivals, and scope wall. Its AB
application is a completed example.

The two certificates compose when a new claim is made; they do not collapse
into one retrospective requirement.

## Current placement

| Claim office | Current state | Required next record if promoted |
|---|---|---|
| Aharonov–Bohm compact-phase contact | completed source-reference contact | none, unless a new discriminator is asserted |
| Electroweak source junction | completed at received SM selection | forced-number certificate only for a newly claimed value/particle prediction |
| Atomic Hamiltonian fibers | completed at declared model resolutions | A-1 receipt only for a Clear Onyx dynamic observable claim |
| GR transport duties | completed at declared duty resolution | a new prediction record for any new gravitational/cosmological effect |
| `Q^2` optical cell | conditional construction, apparatus receipt open | calibrated transfer-matrix protocol and outside record |
| Time Scope laboratory reading | formal result, apparatus contact open | hardware-specific calibration/readout receipt |
| Suture magnetic cap | exact regular-branch result | source equation, units/calibration for `chi`, predicted band, rivals, falsifier, prospective comparison |
| LQG Eq. open | source-owned model-specific open condition | complete amplitude / physical quotient / spin-two-residue witness |

## Guard

No source-bound reference contact is re-described as a new prediction. No
new prediction is described as certified merely because its formal source
card passes. This guard preserves both kinds of closure at their earned
strength.
