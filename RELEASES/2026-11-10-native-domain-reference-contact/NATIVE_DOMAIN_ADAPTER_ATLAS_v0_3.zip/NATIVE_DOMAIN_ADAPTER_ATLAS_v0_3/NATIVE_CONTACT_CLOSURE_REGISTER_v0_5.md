# Native-contact closure register · v0.5

## Governing separation

Each row records the strongest closure actually held by its source. A native source receipt and a new Architecture prediction use different gates.

| Native bundle | Carrier and map | Receipt / authority | Exact status |
|---|---|---|---|
| **U1 — Body–SI–English length** | calibrated body-length record \(\rho_{\rm cal}\) to SI length; exact rational transport to controlled English expressions | BIPM metre definition; NIST HB 44 / NIST Guide conversion factors; System of the Body | **CLOSED — exact conventional unit/language transport.** A particular body reading retains its instrument and uncertainty record. |
| **Gauge / magnetic Aharonov–Bohm** | exact \(\chi:\mathbb R\Omega\to\mathfrak u(1)\) compact-phase representation | retained v0.2 source bundle and historical AB receipt | **CLOSED — source-reference contact** at the stated AB configuration. |
| **Electroweak junction** | received SM representation/vacuum carried through the W-0/W-1 algebraic maps | retained v0.2 source bundle and W/Z/Higgs historical receipts | **CLOSED — source-reference contact at received selection.** |
| **Atomic: H, He, Li and descriptors** | Coulomb hydrogen, finite-basis helium, and evaluated H–Li descriptor carriers | atomic field source; `MINIMUM_HYDROGEN_DYNAMICS_AUDIT.md`; `Hydrogen_Lithium_Valence_Quotient_Return_v01.md`; NIST/CODATA references named in those records | **CLOSED — declared model realization and source-linked H/H–Li reference at the stated resolutions.** **OPEN — Clear Onyx A-1 dynamic H/He/Li receipt.** |
| **Lorentzian / GR duties** | split-metric duties map into native signature, null, transport, quotient/lift, connection, and holonomy offices | GR field-source ownership record and its type firewall | **CLOSED — declared duty/type map and diagnostic/identity firewall.** **OPEN — source-selected observational instantiation.** |
| **Paraxial \(Q^2\) optics** | exact conditional lens-drift factorization | v0.2 source bundle | **OPEN — apparatus/model gate.** |
| **Time Scope readout** | exact projective polarization/two-level doubled-angle relation | v0.2 source bundle | **OPEN — apparatus contact.** |
| **Suture Einstein–Maxwell reduction** | exact regular-branch \(\Pi\mapsto(g,F_{\rm sol})\) with nontrivial fibre | v0.2 source bundle | **CLOSED — model-local equation realization; OPEN — empirical novelty gate.** |
| **Covariant LQG** | exact compatibility/gluing and spin-two-survival criterion | v0.2 source bundle | **OPEN — model-specific amplitude gate.** |

## v0.3 effect

1. `CLOSED FOR CONSOLIDATION` is preserved as its own source-ownership result.
2. Hydrogen's already retained numerical-reference materials are bound into this packet rather than recreated.
3. The GR status names both its closed type/duty content and its source-owned observational continuation.
4. U1 closes the SI/metric/English unit grammar as an exact conventional transport layer.

No row above licenses a new Architecture-derived physical number or effect. Such a claim remains governed by the prospective forced-number certificate in the retained v0.2 lineage.
