#!/usr/bin/env python3
"""Source-binding verifier for Native Domain Adapter Atlas v0.3.

This verifies that the claimed source records and status language are bundled.
It does not replace the original proof, experiment, or external authority.
"""

from pathlib import Path


ROOT = Path(__file__).resolve().parent
CHECKS = [
    ("B1 Body carrier source", "sources/SYSTEM_OF_THE_BODY_Multiscale_Homeostasis_and_Whole_Organism_Viability_v0_1.md", ["whole-organism", "language / action receipt"]),
    ("B2 Hydrogen audit source", "sources/MINIMUM_HYDROGEN_DYNAMICS_AUDIT.md", ["2022 CODATA", "13.598433", "22/22"]),
    ("B3 H-L numeric source", "sources/Hydrogen_Lithium_Valence_Quotient_Return_v01.md", ["13.598433", "5.391719", "independent Hamiltonian and spectral witnesses"]),
    ("B4 Atomic status source", "sources/11 ATOMIC_MOLECULAR_CHEMISTRY_Hamiltonian_Fibers_and_Minimum_Complex_Models_v0_1(1).md", ["CLOSED FOR CONSOLIDATION", "CLOSED IN THE DECLARED COULOMB JURISDICTION"]),
    ("B5 GR status source", "sources/06 RELATIVITY_GRAVITY_COSMOLOGY_Field_Source_Ownership_v0_2(1).md", ["CLOSED FOR CONSOLIDATION", "CLOSED BY TYPE", "OPEN FOR EMPIRICAL INSTANTIATION"]),
    ("B6 Novelty-gate source", "sources/THE_EMPIRICAL_INPUT_REGISTER_v0_1.md", ["Forced-number certificate", "held-out observable", "prospective gate"]),
    ("B7 SI/NIST source record", "UNIT_STANDARD_SOURCE_RECORD_v0_1.md", ["299\\,792\\,458", "0.3048", "201.168", "1609.344"]),
    ("B8 U1 contract", "BODY_SI_ENGLISH_LENGTH_ADAPTER_v0_1.md", ["ft_intl", "controlled English", "foot_anatomical"]),
    ("B9 status ruling", "STATUS_LABEL_RULING_v0_1.md", ["CLOSED FOR CONSOLIDATION", "CLOSED BY TYPE", "prospective novelty"]),
    ("B10 v0.2 lineage", "lineage/NATIVE_DOMAIN_ADAPTER_ATLAS_v0_2.zip", []),
]


count = 0
for label, relative, markers in CHECKS:
    path = ROOT / relative
    if not path.is_file():
        raise AssertionError(f"FAIL {label}: missing {relative}")
    if markers:
        text = path.read_text(encoding="utf-8")
        absent = [marker for marker in markers if marker not in text]
        if absent:
            raise AssertionError(f"FAIL {label}: missing markers {absent}")
    count += 1
    print(f"PASS {label}")

print(f"RESULT: {count}/{count} PASS — source bindings present")
