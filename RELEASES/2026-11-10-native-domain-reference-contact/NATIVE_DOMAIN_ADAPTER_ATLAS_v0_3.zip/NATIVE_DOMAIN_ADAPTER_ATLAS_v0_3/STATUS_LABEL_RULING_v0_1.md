# Status-label ruling v0.1

## Purpose

This ruling separates source-management closure, formal/type closure, native-reference contact, and prospective novelty. It prevents one valid closure from being read as another.

| Source phrase or result | Exact register office |
|---|---|
| `CLOSED FOR CONSOLIDATION` | source-ownership and migration closure; it establishes a coherent source packet |
| `CLOSED BY TYPE` | formal/type firewall closure; it establishes a refusal or allowed map at the declared type |
| exact model/verifier result | model-local or formal closure at its stated carrier |
| named native authority plus retained comparison record | source-reference contact at the declared native resolution |
| frozen Architecture claim plus held-out acceptance rule | prospective novelty gate |

## Applied rulings

### Atomic

The atomic source's consolidation ruling, Coulomb-model closure, finite-basis helium status, and descriptor closure remain earned at their stated carriers. The Library additionally contains `MINIMUM_HYDROGEN_DYNAMICS_AUDIT.md`, which records 2022 CODATA inputs, NIST comparison values, and its own witness-lock claim. This supplies a source-linked hydrogen reference record that v0.2 omitted from its binding manifest.

The Clear Onyx A-1 dynamic H/He/Li receipt remains a separate prospective/dynamic record. It tests a different claim and neither replaces nor is replaced by the model and reference documents.

### Lorentzian/GR

The GR source closes the declared duty dictionary and the diagnostic/identity firewall. Its own next empirical task is an observational instantiation on selected records. The v0.3 row therefore separates the closed map from that source-owned record-binding continuation.

### Historical and prospective receipts

Established native results use their retained historical/source receipts. A prospective held-out gate is required only when the Architecture advances a new numerical value, effect, or empirical distinction.
