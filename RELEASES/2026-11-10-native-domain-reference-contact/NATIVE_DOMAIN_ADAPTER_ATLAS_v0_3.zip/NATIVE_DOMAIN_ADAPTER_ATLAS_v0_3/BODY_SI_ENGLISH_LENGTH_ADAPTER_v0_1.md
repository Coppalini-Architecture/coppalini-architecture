# Body–SI–English Length Adapter v0.1

**Date:** 10 November 2026  
**Status:** CLOSED — exact conventional unit/language transport at the declared length-language resolution.

## 1. Jurisdiction

This adapter connects four distinct offices:

\[
\mathcal B_{\ell}
\xrightarrow{\ \rho_{\rm cal}\ }
\mathcal L_{\rm SI}
\xleftrightarrow{\ T_{\rm exact}\ }
\mathcal L_{\rm EN}.
\]

| Office | Declared carrier |
|---|---|
| body | a calibrated body-length record: referent, anatomical coordinate, instrument, procedure, resolution, and retained result |
| SI | tagged length quantities in metres, recorded at a declared finite resolution or as intervals |
| English | controlled English length expressions: numeral + unit word + quantity tag + standard tag |
| transport | exact rational conversion between tagged unit expressions and metre values |

`SYSTEM_OF_THE_BODY` supplies the organism as a multi-reader carrier and places language/action reports as downstream public-reader outputs. It does not supply a universal anatomical length constant. The calibrated reader \(\rho_{\rm cal}\) supplies the body-to-measurement crossing.

## 2. Exact standard transport

The adapter uses the international foot, written `ft_intl`.

\[
\begin{aligned}
1\,\mathrm{in} &= \frac{127}{5000}\,\mathrm m,\\
1\,\mathrm{ft}_{\rm intl} &= \frac{381}{1250}\,\mathrm m = 0.3048\,\mathrm m,\\
1\,\mathrm{yd} &= \frac{1143}{1250}\,\mathrm m = 0.9144\,\mathrm m,\\
1\,\mathrm{fur} &= 660\,\mathrm{ft}_{\rm intl}
 = \frac{25146}{125}\,\mathrm m = 201.168\,\mathrm m,\\
1\,\mathrm{mi} &= 5280\,\mathrm{ft}_{\rm intl}
 = \frac{201168}{125}\,\mathrm m = 1609.344\,\mathrm m.
\end{aligned}
\]

The SI metric prefixes retain their exact decimal transport:

\[
1\,\mathrm{mm}=10^{-3}\,\mathrm m,
\qquad
1\,\mathrm{km}=10^3\,\mathrm m.
\]

The metre is the SI base unit of length. Its magnitude is set through the fixed numerical value of \(c\); the foot/furlong relations above are conventional exact relations to that SI unit.

## 3. The 1:1 carrier

Raw spellings are intentionally many-to-one:

\[
12\,\mathrm{in}
\sim
1\,\mathrm{ft}
\sim
\frac13\,\mathrm{yd}.
\]

The exact carrier is therefore an equivalence class of typed expressions:

\[
\mathcal Q_{\ell}^{\rm EN}
:=
\{(q,u,\mathrm{length},\mathrm{standard})\}/\!\sim,
\]

where two entries are equivalent exactly when their rational metre values agree. The map

\[
T_{\rm exact}:\mathcal Q_{\ell}^{\rm EN}\longrightarrow
\mathbb Q\,\mathrm m
\]

is one-to-one and onto at the declared rational-record resolution. Its inverse selects a declared canonical display unit; it never erases the originating unit tag from the receipt.

Examples:

\[
[\text{six feet}]\longleftrightarrow 1.8288\,\mathrm m,
\qquad
[\text{one furlong}]\longleftrightarrow 201.168\,\mathrm m.
\]

## 4. Controlled English measurement grammar

The grammar is deliberately finite and public:

\[
\texttt{<numeral> <length-unit> [<standard-tag>]}. 
\]

Accepted English unit forms include `inch/inches`, `foot/feet`, `yard/yards`, `furlong/furlongs`, and `mile/miles`. Metric forms include `millimetre/millimeter`, `metre/meter`, and `kilometre/kilometer`.

The grammar supplies a closed English **measurement** interface. It carries number, plural form, conventional unit word, dimensional office, and reference standard in one public expression. This is the declared English-language resolution of the adapter.

Two uses of the token `foot` remain deliberately distinct:

| Expression | Typed referent |
|---|---|
| `six feet` | `ft_intl`, a conventional length unit |
| `a human foot` | anatomical structure inside the body carrier |

The distinction is a visible part of the adapter rather than an ambiguity left for inference.

## 5. Body record interface

A body measurement enters as

\[
b=(\mathrm{referent},\ \mathrm{coordinate},\ \mathrm{instrument},\ \mathrm{procedure},\ \Delta,\ \mathrm{record}).
\]

The calibrated reader returns an SI interval or a finite-resolution SI record:

\[
\rho_{\rm cal}(b)=[\ell_- ,\ell_+]\subset\mathbb R_{\ge0}\,\mathrm m.
\]

`T_exact` transports each endpoint exactly into the chosen English unit. Thus measurement uncertainty remains an empirical property of the body/instrument record, while unit conversion remains exact.

## 6. Preserved structure and failure witnesses

The exact verifier checks:

1. all displayed conversions as rational equalities;
2. forward/inverse conversion on canonical representatives;
3. equality of `12 in`, `1 ft`, and `1/3 yd`;
4. `1 fur = 660 ft` and `1 mi = 5280 ft`;
5. dimension preservation and order preservation;
6. exact transport of a finite-resolution body interval.

The following inputs are refused by type:

| Candidate | Witness |
|---|---|
| `6` | bare numeral lacks a quantity unit |
| `6 seconds` | time unit cannot enter the length map |
| `6 survey feet` | requires the historical U.S.-survey-foot standard, not `ft_intl` |
| `foot_anatomical` as a unit | anatomical carrier lacks a conventional-unit declaration |

## 7. Authority and scope

- **SI anchor:** BIPM, SI base-unit definition of the metre, retrieved 10 November 2026.
- **English/U.S. customary anchor:** NIST Handbook 44 (2026), Appendix C, and NIST Guide to the SI, Appendix B.
- **Body carrier:** *System of the Body*, v0.1.

This closure concerns standard transport and controlled public measurement language. A particular body measurement, clinical claim, anthropometric population statement, or physical prediction requires its own retained record and calibration.

## 8. Result

\[
\boxed{
\textbf{Body record}
\xrightarrow{\rho_{\rm cal}}
\textbf{SI length}
\xleftrightarrow{T_{\rm exact}}
\textbf{English length expression}
}
\]

is a closed, typed, reversible unit-language adapter at its declared resolution.
