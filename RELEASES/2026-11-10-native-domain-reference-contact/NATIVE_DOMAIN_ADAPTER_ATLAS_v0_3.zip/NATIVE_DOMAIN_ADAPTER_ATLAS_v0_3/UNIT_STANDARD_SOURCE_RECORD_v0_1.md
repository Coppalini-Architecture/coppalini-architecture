# Unit-standard source record v0.1

**Retrieval date:** 10 November 2026  
**Purpose:** exact authority record for the Body–SI–English Length Adapter.

## BIPM: SI metre

- Authority: International Bureau of Weights and Measures (BIPM).
- Source: <https://www.bipm.org/en/si-base-units/metre>
- Statement used: the metre is the SI unit of length; the fixed numerical value of the speed of light in vacuum is \(299\,792\,458\) when expressed in \(\mathrm{m\,s^{-1}}\).
- Adapter use: anchors the metre as the native SI length carrier.

## NIST: international foot and derived length units

- Authority: National Institute of Standards and Technology (NIST).
- Source: *NIST Handbook 44 — 2026*, Appendix C, General Tables of Units of Measurement: <https://nvlpubs.nist.gov/nistpubs/hb/2026/NIST.HB.44-2026.pdf>
- Supporting source: NIST, *U.S. Survey Foot: Revised Unit Conversion Factors*: <https://www.nist.gov/pml/us-surveyfoot/revised-unit-conversion-factors>
- Exact statements used:

\[
1\,\mathrm{ft}_{\rm intl}=0.3048\,\mathrm m,
\quad
1\,\mathrm{fur}=660\,\mathrm{ft}=201.168\,\mathrm m,
\quad
1\,\mathrm{mi}=5280\,\mathrm{ft}=1609.344\,\mathrm m.
\]

- Legacy control: NIST identifies the U.S. survey foot as a separate historical/legacy unit and distinguishes its conversion from the international foot. This supplies U1's negative control.

## Exactness note

This record preserves source URLs, edition, date, and the particular values used by the verifier. It is a source index; the authoritative documents remain owned by BIPM and NIST.
