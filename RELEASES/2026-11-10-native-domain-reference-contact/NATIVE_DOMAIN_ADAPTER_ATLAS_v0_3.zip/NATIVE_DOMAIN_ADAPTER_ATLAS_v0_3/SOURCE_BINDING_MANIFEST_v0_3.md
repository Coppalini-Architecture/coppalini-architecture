# Source-binding manifest · v0.3

All files below are carried in `sources/` and hash-bound by `SHA256SUMS`.

| Local path | Source identity | Role in v0.3 |
|---|---|---|
| `sources/SYSTEM_OF_THE_BODY_Multiscale_Homeostasis_and_Whole_Organism_Viability_v0_1.md` | `libfile_ccd04dea28788191b8879f4154fef058` | body as multi-reader carrier; language/action report boundary |
| `sources/MINIMUM_HYDROGEN_DYNAMICS_AUDIT.md` | `libfile_d914bfa290bc819189a25792e458389e` | hydrogen numerical-reference, CODATA/NIST, and verification record |
| `sources/Hydrogen_Lithium_Valence_Quotient_Return_v01.md` | `libfile_d117d597b5548191bd4912ed1a12b3e3` | H–Li evaluated descriptor and ionization-energy receipt |
| `sources/11 ATOMIC_MOLECULAR_CHEMISTRY_Hamiltonian_Fibers_and_Minimum_Complex_Models_v0_1(1).md` | v0.2 retained source | model/descriptor closure and consolidation wording |
| `sources/06 RELATIVITY_GRAVITY_COSMOLOGY_Field_Source_Ownership_v0_2(1).md` | v0.2 retained source | GR duty map, type firewall, and explicit empirical-instantiation continuation |
| `sources/THE_EMPIRICAL_INPUT_REGISTER_v0_1.md` | v0.2 retained source | historical-source versus prospective-novelty distinction |
| `UNIT_STANDARD_SOURCE_RECORD_v0_1.md` | BIPM and NIST source index | metre, foot, furlong, mile authority record |

The other v0.2 sources are retained verbatim in `sources/`; `lineage/NATIVE_DOMAIN_ADAPTER_ATLAS_v0_2.zip` remains byte-preserved.

`verify_source_bindings_v0_3.py` verifies required addresses and markers. It is a source-binding check; the original mathematical and empirical arguments remain owned by their source records.
