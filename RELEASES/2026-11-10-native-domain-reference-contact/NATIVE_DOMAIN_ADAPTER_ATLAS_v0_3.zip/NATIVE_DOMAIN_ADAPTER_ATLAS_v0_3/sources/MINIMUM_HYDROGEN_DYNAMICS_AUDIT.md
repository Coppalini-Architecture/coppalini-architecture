# Minimum Hydrogen Dynamical Architecture v0.1

## Audit scope

This release instantiates a minimal two-energy-sector closed hydrogen model in the supplied audit jurisdiction with genuine observable density motion. It does not depict an electron orbit. It does not model neutral helium as a dynamical endpoint. It keeps Coulomb evolution, reflected density disclosure, axial spin lift, and occurrence retention in separate typed offices.

The model is intentionally ideal: center-of-mass separated, field free, nonrelativistic, spin factored, and closed. Fine structure, hyperfine structure, the Lamb shift, spontaneous emission, external fields, relativity, and QED are excluded.

## 1. Physical kernel

For protium, the declared relative-coordinate Hamiltonian is

\[
H_{\mathrm{rel}}
=-\frac{\hbar^2}{2\mu_H}\nabla^2
-\frac{e^2}{4\pi\varepsilon_0r},
\qquad
\mu_H=\frac{m_em_p}{m_e+m_p}.
\]

Its reduced-mass Bohr scale and energy scale are

\[
a_H=\frac{4\pi\varepsilon_0\hbar^2}{\mu_He^2},
\qquad
E_H=\frac{\mu_He^4}{2(4\pi\varepsilon_0)^2\hbar^2},
\qquad
E_n=-\frac{E_H}{n^2}.
\]

The code uses 2022 CODATA inputs and reports

\[
\mu_H/m_e\approx0.9994556794,
\quad
a_H\approx5.29465\times10^{-11}\,\mathrm m,
\quad
T_{21}\approx4.0551\times10^{-16}\,\mathrm s.
\]

These values belong to the reduced-mass Coulomb approximation. They are not silently substituted for the measured full hydrogen spectrum. NIST lists the physical hydrogen ground level as \(1s\,{}^2S_{1/2}\), an ionization energy near 13.598433 eV, and the \(1s\to2p\) separation near 10.1988 eV.

## 2. Minimum observable motion

A single energy eigenstate changes only by global phase, so its density does not move. The minimum moving state therefore uses two distinct energy sectors. In the dimensionless coordinates \((X,Y,Z)=\mathbf r/a_H\), define

\[
s(R)=\frac{e^{-R}}{\sqrt\pi},
\qquad
p_h(X,Y,Z)=\frac{(X+ihY)e^{-R/2}}{8\sqrt\pi},
\qquad h\in\{+1,-1\}.
\]

After removing the common unobservable phase, the exact gauge-fixed spectral evolution is

\[
\widetilde\Psi_h(X,Y,Z;\tau)
=\frac{s(R)+e^{-i\tau}p_h(X,Y,Z)}{\sqrt2},
\qquad
\tau=\frac{E_2-E_1}{\hbar}t.
\]

No numerical PDE integrator is used. The state is evaluated directly from this closed form.

The dimensionless density is

\[
\widetilde\rho_h
=\frac12\left[
s^2+f^2(X^2+Y^2)
+2sf\bigl(X\cos\tau+hY\sin\tau\bigr)
\right],
\quad
f(R)=\frac{e^{-R/2}}{8\sqrt\pi}.
\]

The displayed short line elements are the dimensionless probability current

\[
\mathbf J_h=\operatorname{Im}\!\left(\widetilde\Psi_h^*\nabla_X\widetilde\Psi_h\right),
\]

not sampled particle paths. The short center vector terminates at the exact expectation read

\[
\langle\mathbf r\rangle_h
=\frac{128a_H}{243}(\cos\tau,h\sin\tau,0),
\]

which is a state expectation value, not an electron location.

## 3. Heavy Horizon seam

The two branches are exact reflected readers:

\[
\widetilde\rho_+(X,Y,Z;\tau)
=\widetilde\rho_-(X,-Y,Z;\tau).
\]

Their signed difference is

\[
\zeta_H
:=\widetilde\rho_+-\widetilde\rho_-
=\frac{Y e^{-3R/2}}{4\pi}\sin\tau.
\]

Under the declared half-angle adapter \(\tau=2\theta\),

\[
\boxed{
\zeta_H(X,Y,Z;\theta)
=\frac{Y e^{-3R/2}}{4\pi}\sin(2\theta).
}
\]

This is an exact correspondence with the Heavy Horizon reader in the angular office: both expose the factor \(\sin(2\theta)\). Their radial envelopes are not identified. The atomic carrier retains \(Ye^{-3R/2}/(4\pi)\); the prior Heavy Horizon carrier retains its own normalized radial expression.

The name “Heavy Horizon seam” is used explicitly. Bare \(H^2\) is prohibited here because it could mean a Hilbert-space square, two hydrogen occurrences, molecular hydrogen, helium, or a Heavy Horizon namespace.

At \(\theta=0,\pi/2,\pi\), the signed mirror read closes to zero while both density branches remain normalized and the phase address remains available. This is closure without erasure.

## 4. Axial return and occurrence ledger

The outer rails implement a separately controlled axial double-cover read. This release chooses the standard active Pauli-adjoint convention \(\sigma(p(U)v)=U\sigma(v)U^\dagger\), so a positive physical angle \(\theta=2\alpha\) is lifted as

\[
U(\alpha)=\operatorname{diag}(e^{-i\alpha},e^{i\alpha}).
\]

The resulting matrixwise projection is tested across both orientations. The placement is

\[
U(1)_{\mathrm{top}}\to SU(2)\to SO(3),
\qquad
\theta_{\mathrm{physical}}=2\alpha_{\mathrm{top}}.
\]

One `TURN 2π` closes physical orientation but reaches the nontrivial central element \(-I\) in the spinor lift. A second turn returns the spinor to \(+I\). For the represented defect \(\Psi=H-I\),

\[
\Psi(-I)=-2I,
\qquad
\Psi(+I)=0,
\qquad
\Psi_{12}=\Psi_1+\Psi_2+\Psi_1\Psi_2.
\]

Each receipt distinguishes the new loop coefficient \(-2\) from the cumulative coefficient, which is \(-2\) after one turn and \(0\) after two. Thus two nontrivial \(-2I\) loop defects compose to zero. Both canonical symbolic path-lift receipts remain in an immutable functional page-local ledger. Each receipt stores the analytic base loop, analytic lift, chosen axis and sheets, endpoint equation, projection, continuity, homotopy, sheet, and concatenation witnesses, and an exact JSON round trip. This is executable page-local retention, not a claim of durable external archival storage. The Coulomb beat clock does not drive the axial turn, and the axial turn does not drive the Coulomb state.

## 5. H–He reference seam

At the declared electronic resolution,

\[
{}^{1}H:1s^1\,{}^2S_{1/2},
\qquad
{}^{4}He:1s^2\,{}^1S_0.
\]

The separate ground-spectroscopy reference package evaluates the shared central generator in different electronic-spin characters:

\[
z_{2\pi}(J_H=\tfrac12)=-1,
\qquad
z_{2\pi}(J_{He}=0)=+1.
\]

This yields the exact static reference seam displayed below the instrument: open first shell to closed first shell. It is not a physical evolution from H to He. Neutral helium requires a two-electron Hamiltonian with electron–electron correlation. The one-electron hydrogenic continuation to \(He^+\) is a separate, admissible future scale adapter.

No Berry phase is displayed. The witnesses require a parameterized Hamiltonian family, a gapped constant-rank projector bundle, a connection, and endpoint semantics before such a phase exists. Endpoint resemblance is not sufficient.

## 6. Display contract

The circular image is the \(Z=0\) slice, not the full three-dimensional atom.

- Lightness/alpha: a fixed, frame-independent transform of density.
- Chroma: the exact local interference visibility.
- Hue: the local phase of the gauge-fixed total amplitude. This is a gauge- and basis-phase display convention, not an observable.
- Seam mode: warm/cool sign of \(\zeta_H\).
- Short strokes: probability current.
- Center point: the fixed nuclear coordinate.
- Radial map: the declared quadratic display map \(R=r/a_H=12u^2\), used only to resolve the Coulomb cusp inside a 12-\(a_H\) horizon. Probability-current vectors are pushed through the Jacobian of this map before being drawn.

At the exact center the \(2p\) amplitude and interference visibility vanish, so chroma is set to zero. The center remains a neutral density read rather than a fabricated phase address.

The colors are false-color phase grammar. They are not emitted optical wavelengths. One physical 405.5-attosecond beat is dilated to 12 wall-clock seconds for display. The renderer has no feedback into the Hamiltonian.

## 7. Privacy and capability boundary

The release is fully local and deterministic. It contains no camera, eye tracking, network request, external API, local storage, telemetry, random source, or particle-position state. The occurrence ledger exists only in the running page and disappears when the page closes.

## 8. Verification

The regression suite checks:

1. reduced-mass model bounds;
2. exact normalization of the \(1s\) and \(2p,m=\pm1\) basis states;
3. equality of direct complex sampling and closed-form density;
4. nonnegative finite density;
5. exact reflected-reader identity;
6. exact hydrogen/Heavy-Horizon double-angle seam;
7. seam closure at each half-turn;
8. gauge-fixed representative/ray return and independently integrated state expectation;
9. analytic probability current against finite differences and the continuity equation;
10. center-neutral color adapters and the radial-map Jacobian;
11. exact four-step phase table;
12. \(2\pi/4\pi\) spinorial return and matrixwise axial-cover projection;
13. ordered loop/cumulative defect composition and immutable duplicate receipt retention;
14. exact symbolic path reconstruction and encode/decode round trip;
15. isotope- and office-explicit H–He reference typing;
16. fragment, identifier, syntax, privacy, and primary-control contracts;
17. real dark/light canvas runtime renders and all three interactions.

Current result: **22/22 tests pass**.

## 9. Primary references

- NIST, [Atomic Data for Hydrogen](https://www.physics.nist.gov/PhysRefData/Handbook/Tables/hydrogentable1.htm).
- NIST, [Energy Levels of Neutral Hydrogen](https://www.physics.nist.gov/PhysRefData/Handbook/Tables/hydrogentable5.htm).
- NIST, [Persistent Lines of Neutral Hydrogen](https://www.physics.nist.gov/PhysRefData/Handbook/Tables/hydrogentable3.htm).
- NIST, [Atomic Data for Helium](https://physics.nist.gov/PhysRefData/Handbook/Tables/heliumtable1.htm).
- NIST, [Energy Levels of Singly Ionized Helium](https://physics.nist.gov/PhysRefData/Handbook/Tables/heliumtable6.htm).
- NIST, [2022 CODATA Recommended Values](https://physics.nist.gov/constants).

The supplied witness files are preserved byte-for-byte under `witnesses/` and locked by `WITNESS_LOCK.sha256`.
