---
title: "NATIVE PHYSICAL TRANSPORT INVENTORY"
subtitle: "Selection jurisdiction and first comparison with the even carriage"
author: "Anthony V. Coppa"
date: "Version 0.1 - 20 August 2026"
---

# Native Physical Transport Inventory

## Selection jurisdiction and first comparison with the even carriage

The purpose of this inventory is not to find a physical system that looks like

\[
Q^2=\begin{pmatrix}2&1\\1&1\end{pmatrix}.
\]

It is to identify physical theories that independently supply a transport office strong enough to receive a two-dimensional formal carrier, and only then ask whether their native transport admits or refuses the even carriage.

The order is binding:

\[
\boxed{
\text{physical office}
\longrightarrow
\text{native transport}
\longrightarrow
\text{observable access}
\longrightarrow
\text{root comparison}
}.
\]

No candidate receives credit for numerical, visual, or verbal resemblance to $Q^2$ during selection.

---

## 1. Independent selection duties

A candidate enters the shortlist only by supplying the following duties in its own theory.

### A. Native comparison carrier

The theory supplies a two-real-dimensional linear state or comparison slice without first projecting a larger state onto a preferred picture merely to match the root.

### B. Path-generated composition

The transporter belongs to an actual ordered evolution, path, beamline, worldline, or connection and composes in traversal order:

\[
T_{\gamma_2\circ\gamma_1}=T_{\gamma_2}T_{\gamma_1}.
\]

An isolated coordinate change with no specified physical traversal receives only partial credit.

### C. Transport observability

Input and output data can identify the transported two-dimensional structure. A measured scalar consequence receives partial credit; reconstruction of the full local transporter receives full credit.

### D. Rival discrimination

The physical literature or a realizable protocol supplies calibrations and controls capable of distinguishing the proposed transporter from drift, leakage, misalignment, basis choice, loss, or a nearby dynamical mechanism.

### E. Regime auditability

The governing equations, approximations, units, and breakdown conditions are explicit enough to run the *Physical Adapter Certificate*.

Each duty is scored $0$ when absent, $1$ when present only after an additional reduction or partial observation, and $2$ when native and directly auditable. The maximum selection score is ten. Algebraic compatibility with $Q^2$ is not a scoring field.

---

## 2. Inventory before root comparison

| Native physical transport | Carrier | A | B | C | D | E | Score | Selection result |
|---|---|---:|---:|---:|---:|---:|---:|---|
| Paraxial ray transfer through first-order optical elements | $(x,\theta)$ in one transverse plane | 2 | 2 | 2 | 2 | 2 | 10 | SHORTLIST |
| Linear charged-particle beam optics | one transverse canonical phase plane | 2 | 2 | 2 | 2 | 2 | 10 | SHORTLIST |
| Lorentz transport in a fixed $1+1$ plane | time-space frame components | 2 | 1 | 2 | 2 | 2 | 9 | RETAIN |
| Relativistic gyroscope transport | two transverse spin components | 2 | 2 | 1 | 2 | 2 | 9 | RETAIN |
| BMT spin transport in a storage ring | two transverse polarization components | 2 | 2 | 1 | 2 | 2 | 9 | RETAIN |
| Lossless polarization/geometric-phase transport | complex Jones vector or Poincare sphere | 1 | 2 | 2 | 2 | 2 | 9 | RETAIN IN ITS OWN TYPE |
| Magnetic Aharonov-Bohm phase transport | $U(1)$ phase | 1 | 2 | 1 | 2 | 2 | 8 | ALREADY CLOSED; NOT A $Q^2$ TARGET |

The scores do not declare one physical theory more fundamental than another. They answer one narrower question: how directly can the theory carry, expose, and test a two-real-dimensional transporter?

Two families tie at the top before $Q^2$ is consulted: paraxial ray optics and charged-particle beam optics. This is not accidental identity. Both are linear Hamiltonian transport theories whose one-plane transfer maps are symplectic. They remain different physical mechanisms with different carriers, forces, scales, and receipts.

Paraxial optics is chosen for the first certificate because it supplies the smaller controlled apparatus. The accelerator family remains an independent neighboring realization and an important external check on the same transport grammar.

---

## 3. Root comparison after selection

Only after the shortlist is fixed do we compare the native transporter classes with

\[
M_\star=Q^2=\begin{pmatrix}2&1\\1&1\end{pmatrix},
\qquad
\det M_\star=1,
\qquad
\operatorname{tr}M_\star=3.
\]

Let

\[
\Omega=\begin{pmatrix}0&1\\-1&0\end{pmatrix},
\qquad
G=[Q,\Omega]
=\begin{pmatrix}-2&1\\1&2\end{pmatrix}.
\]

Direct multiplication gives

\[
M_\star^{\mathsf T}\Omega M_\star=\Omega,
\qquad
M_\star^{\mathsf T}GM_\star=G.
\]

Thus $M_\star$ is both symplectic on the root area plane and hyperbolic relative to the root indefinite form.

| Candidate | Native transporter class | Comparison with $Q^2$ | Verdict |
|---|---|---|---|
| Paraxial ray optics | $Sp(\mathbb R^2,\Omega)\cong SL(2,\mathbb R)$ in one transverse plane | $Q^2$ is admitted and has an exact lens-drift factorization | ADMIT, CONDITIONALLY PHYSICAL |
| Linear accelerator optics | symplectic transfer in each uncoupled canonical phase plane | $Q^2$ is an admissible hyperbolic cell map | ADMIT, REALIZATION OPEN |
| $1+1$ Lorentz transport | $SO^+(1,1)$ after a metric frame is fixed | $Q^2$ is conjugate to a boost of rapidity $2\log\Phi$ | ADMIT AS CHART COMPATIBILITY; NO SELECTED MOTION |
| Gravity Probe B-type gyro transport | metric-preserving transverse rotation/precession | reciprocal positive real eigenvalues do not match a nontrivial rotation | REFUSE $Q^2$ IN THIS OFFICE |
| BMT storage-ring spin transport | elliptic spin precession in the transverse plane | hyperbolic $Q^2$ is not the native lossless spin rotation | REFUSE $Q^2$ IN THIS OFFICE |
| Lossless polarization/geometric phase | unitary transport, usually represented on a complex state or Poincare sphere | $Q^2$ is not unitary in the declared positive norm | REFUSE WITHOUT A DIFFERENT LOSS/GAIN OFFICE |
| Aharonov-Bohm transport | $U(1)$ phase holonomy | the measured office is a phase modulo $2\pi$, not a real hyperbolic map | NOT USED |

The refusals matter. They show that the inventory is not treating every two-component transport as the same mechanism. Conjugacy class, invariant form, field, and observable remain typed.

---

## 4. The exact optical presentation

Fix a positive length $\ell$. In a uniform medium, write a paraxial ray at an input plane as

\[
r=\begin{pmatrix}q\\p\end{pmatrix}
=\begin{pmatrix}x/\ell\\\theta\end{pmatrix},
\]

where $x$ is transverse displacement and $\theta$ is the small ray slope. Both normalized coordinates are dimensionless. Here $p$ names a paraxial slope coordinate, not photon momentum.

Free propagation through distance $\ell$ has normalized transfer

\[
U=\begin{pmatrix}1&1\\0&1\end{pmatrix}.
\]

An ideal thin diverging lens with focal length $f=-\ell$ has normalized transfer

\[
D=\begin{pmatrix}1&0\\1&1\end{pmatrix}.
\]

The ray meets the lens first and then traverses the drift, so the total map is

\[
\boxed{
UD
=
\begin{pmatrix}1&1\\0&1\end{pmatrix}
\begin{pmatrix}1&0\\1&1\end{pmatrix}
=
\begin{pmatrix}2&1\\1&1\end{pmatrix}
=Q^2.
}
\]

The reverse hardware order gives

\[
DU=\begin{pmatrix}1&1\\1&2\end{pmatrix}
=P Q^2P,
\qquad
P=\begin{pmatrix}0&1\\1&0\end{pmatrix},
\]

the coordinate-exchanged member of the same root orbit.

This construction establishes existence inside a native physical transport theory. It does **not** establish that nature selects $f=-\ell$, that the root derived geometric optics, or that an unmeasured apparatus has already produced the matrix.

Neither $U$ nor $D$ is identified with the root one-step operator $Q$. The physical cell realizes the even carriage only as their ordered composite.

---

## 5. What the factorization means

The two elementary maps are unipotent Hamiltonian shears. With normalized axial coordinate $s=z/\ell$, define

\[
N_+=\begin{pmatrix}0&1\\0&0\end{pmatrix},
\qquad
N_-=\begin{pmatrix}0&0\\1&0\end{pmatrix}.
\]

Because $N_+^2=N_-^2=0$,

\[
U=e^{N_+}=I+N_+,
\qquad
D=e^{N_-}=I+N_-.
\]

Both generators satisfy

\[
N_\pm^{\mathsf T}\Omega+\Omega N_\pm=0,
\]

so each element preserves $\Omega$, as does their composition. The ideal thin lens is an impulsive transfer in this model; a finite-thickness lens replaces the kick with a resolved refractive evolution and must be measured in its own principal-plane convention.

The root form $G$ is restored by the complete cell:

\[
(UD)^{\mathsf T}G(UD)=G.
\]

It is not generally preserved at the intermediate plane between $D$ and $U$. In this optical realization, $G$ is therefore a stroboscopic quadratic invariant of the complete ideal cell, not a universal optical metric and not gravitational spacetime.

The eigenvalues are

\[
\lambda_\pm=\Phi^{\pm2}.
\]

Accordingly, repeated ideal cells are hyperbolic: one eigen-direction expands and the other contracts. In a finite apparatus, aperture, aberration, and the breakdown of the paraxial approximation limit the number of lawful repetitions. Infinite projective order in the algebra does not mean an infinitely repeatable physical bench.

---

## 6. Present authority

| Claim | Status |
|---|---|
| First-order paraxial propagation and ideal thin-lens transfer form a compositional $2\times2$ symplectic theory | IMPORTED / DERIVED IN THE CITED THEORY |
| The normalized lens-then-drift cell with $f=-\ell$, $L=\ell$ equals $Q^2$ | DERIVED |
| The complete cell preserves both $\Omega$ and $G$ | DERIVED |
| The same $Q^2$ is an eligible one-plane accelerator transfer | CONDITIONAL COMPATIBILITY |
| $Q^2$ is realized by Levi-Civita transport in spacetime | OPEN; NOT ADVANCED HERE |
| A constructed optical bench has been calibrated to $Q^2$ | OPEN |
| Nature uniquely or minimally selects this optical cell | REFUSED AS AN UNSUPPLIED CLAIM |
| The optical realization transports every root meaning | REFUSED |

The result is the first exact constructive physical office for the even carriage in this program. It is not yet a measured graft.

---

## 7. Source ledger

The source chain is deliberately narrower than a general optics bibliography.

1. H. Kogelnik and T. Li, “Laser Beams and Resonators,” *Applied Optics* **5** (1966), 1550–1567, [doi:10.1364/AO.5.001550](https://doi.org/10.1364/AO.5.001550). Classical ABCD treatment of laser beams and resonators.
2. E. C. G. Sudarshan, R. Simon, and N. Mukunda, “Paraxial-wave optics and relativistic front description. I. The scalar theory,” *Physical Review A* **28** (1983), 2921, [doi:10.1103/PhysRevA.28.2921](https://doi.org/10.1103/PhysRevA.28.2921). Derives free propagation and lens transmission in the paraxial framework and identifies the metaplectic structure.
3. H. Bacry and M. Cadilhac, “Metaplectic group and Fourier optics,” *Physical Review A* **23** (1981), 2533, [doi:10.1103/PhysRevA.23.2533](https://doi.org/10.1103/PhysRevA.23.2533). Connects paraxial optical evolution, canonical transformations, and the symplectic group.
4. K. B. Wolf, “Diffraction-free beams remain diffraction free under all paraxial optical transformations,” *Physical Review Letters* **60** (1988), 757, [doi:10.1103/PhysRevLett.60.757](https://doi.org/10.1103/PhysRevLett.60.757). States the paraxial symplectic linear group action in $2\times2$ matrix form.
5. M. Lax, W. H. Louisell, and W. B. McKnight, “From Maxwell to paraxial wave optics,” *Physical Review A* **11** (1975), 1365, [doi:10.1103/PhysRevA.11.1365](https://doi.org/10.1103/PhysRevA.11.1365). Fixes the approximation boundary by deriving the paraxial expansion from Maxwell theory.
6. C. A. Dartora et al., “Lagrangian-Hamiltonian formulation of paraxial optics and applications,” *Physical Review A* **83** (2011), 012110, [doi:10.1103/PhysRevA.83.012110](https://doi.org/10.1103/PhysRevA.83.012110). Supplies a Hamiltonian formulation and ray trajectories in the paraxial regime.
7. E. D. Courant and H. S. Snyder, “Theory of the Alternating-Gradient Synchrotron,” *Annals of Physics* **3** (1958), 1–48, [doi:10.1016/0003-4916(58)90012-5](https://doi.org/10.1016/0003-4916(58)90012-5). Foundational linear Hamiltonian beam transport and stability theory.
8. A. Halavanau et al., “Analysis and measurement of the transfer matrix of a 9-cell, 1.3-GHz superconducting cavity,” *Physical Review Accelerators and Beams* **20** (2017), 040102, [doi:10.1103/PhysRevAccelBeams.20.040102](https://doi.org/10.1103/PhysRevAccelBeams.20.040102). Demonstrates experimental transfer-matrix measurement and comparison with analytic and numerical predictions.
9. V. Bargmann, L. Michel, and V. L. Telegdi, “Precession of the Polarization of Particles Moving in a Homogeneous Electromagnetic Field,” *Physical Review Letters* **2** (1959), 435, [doi:10.1103/PhysRevLett.2.435](https://doi.org/10.1103/PhysRevLett.2.435). Native relativistic spin-transport comparison family.
10. C. W. F. Everitt et al., “Gravity Probe B: Final Results of a Space Experiment to Test General Relativity,” *Physical Review Letters* **106** (2011), 221101, [doi:10.1103/PhysRevLett.106.221101](https://doi.org/10.1103/PhysRevLett.106.221101). Measured gyroscope precession along an Earth orbit.
11. E. Sjoqvist et al., “Geometric Phases for Mixed States in Interferometry,” *Physical Review Letters* **85** (2000), 2845, [doi:10.1103/PhysRevLett.85.2845](https://doi.org/10.1103/PhysRevLett.85.2845). Gives a parallel-transport condition and interferometric phase read in a unitary quantum office.
12. A. Tonomura et al., “Observation of Aharonov-Bohm Effect by Electron Holography,” *Physical Review Letters* **48** (1982), 1443, [doi:10.1103/PhysRevLett.48.1443](https://doi.org/10.1103/PhysRevLett.48.1443). Primary measured phase-holonomy comparison already certified elsewhere in the corpus.

---

## Closure note

The inventory closes the candidate-selection step and produces one exact conditional construction:

\[
\boxed{
\text{diverging thin lens }(-\ell)
\longrightarrow
\text{free drift }(\ell)
\longrightarrow
Q^2
}
\]

inside normalized first-order paraxial ray transport.

The next necessary object is not another analogy. It is the measurement certificate for this cell: prepared ray ensemble, calibrated lens and separation, reconstructed transfer matrix with covariance, invariant residuals, rival controls, and an outside receipt.
