# THE EMPIRICAL INPUT REGISTER

## What Standard Model structure selects, transports, receives, and leaves open

**Anthony V. Coppa**

**Version 0.1 — 21 August 2026**

---

## Abstract

The Standard Model becomes numerically predictive only after its structural declarations are joined to empirical inputs, computational coordinates, occurrence conditions, and apparatus records. These offices are frequently compressed into the single word *parameter*. That compression obscures which quantities the theory selects, which it relates, which renormalization transports, and which experiment supplies.

This register separates those offices. Under the convention that retains the strong-CP angle, the minimal renormalizable Standard Model with massless neutrinos contains nineteen independent continuous physical parameters:

\[
3_{\mathrm{gauge}}
+2_{\mathrm{scalar}}
+9_{\mathrm{charged\ fermion\ masses}}
+4_{\mathrm{CKM}}
+1_{\mathrm{strong\ CP}}
=19.
\]

The choice of experimental input scheme can exchange coordinates while preserving this count. Field representations, hypercharges, generation number, global gauge-group form, background structure, renormalization prescription, initial state, nonperturbative functions, and apparatus response occupy additional typed registers. Neutrino mass requires a separate carrier extension and adds its own parameters.

The present Recognition architecture exactly coordinates several structural relations and transports established parameters through certified adapters. It presently receives every numerical Standard Model parameter from empirical physics. A forced, previously free quantity therefore remains the exact boundary between verified reorganization and new predictive physical content.

---

## 0. Jurisdiction and authority

### 0.1 Model jurisdiction

The primary census is the minimal renormalizable Standard Model with:

\[
\mathfrak g_{\mathrm{SM}}
=
\mathfrak{su}(3)_c
\oplus
\mathfrak{su}(2)_L
\oplus
\mathfrak u(1)_Y,
\]

three observed fermion generations, one complex scalar doublet, the usual chiral matter representations, and massless neutrinos at the renormalizable level.

The continuous count retains the physical strong-CP parameter \(\bar\theta_{\mathrm{QCD}}\). A convention imposing \(\bar\theta_{\mathrm{QCD}}=0\) produces an eighteen-parameter restricted model. This paper keeps the parameter in the register because experimental bounds constrain its value while the Standard Model action permits it.

### 0.2 Status vocabulary

| Status | Exact use |
|---|---|
| **SELECTED** | uniquely fixed inside a declared jurisdiction by a proved criterion |
| **DERIVED** | follows from stated premises and displayed operations |
| **TRANSPORTED** | carried between equivalent coordinates, scales, or schemes by a certified map |
| **RECEIVED** | supplied by empirical measurement or fit |
| **DECLARED** | chosen as part of the model, representation, convention, or calculation |
| **CONSTRAINED** | narrowed by consistency or evidence while retaining residual freedom |
| **OPEN** | awaiting a carrier, selector, adapter, measurement, or receipt |
| **REFUSED** | excluded from the stated office by a type mismatch or failed condition |

### 0.3 Four registers

The word *input* divides into four forms:

1. **structural input** — group, representation, field content, dimension, global form;
2. **continuous physical input** — coupling, scalar coefficient, mass, mixing coordinate, CP angle;
3. **computational input** — scheme, scale, truncation, regulator, factorization prescription;
4. **occurrence and readout input** — prepared state, boundary condition, luminosity, calibration, response, nuisance model.

Only the second register contributes to the conventional nineteen-parameter count.

### 0.4 Units and constants

The constants \(c\) and \(\hbar\) convert physical dimensions and set unit conventions. Their numerical values in SI reflect the unit system. They occupy the conversion office rather than the nineteen-entry fitted-parameter register.

---

## 1. The nineteen-entry continuous register

### Theorem 1.1 — Minimal Standard Model parameter census

After quotienting the three charged-fermion Yukawa matrices by field redefinitions that preserve observables, the minimal Standard Model has the independent continuous register

\[
\Theta_{\mathrm{SM}}^{(19)}
=
\bigl(
g_s,g,g',
\mu_H^2,\lambda,
m_e,m_\mu,m_\tau,
m_u,m_d,m_s,m_c,m_b,m_t,
\theta_{12}^{q},\theta_{23}^{q},\theta_{13}^{q},\delta_{\mathrm{CKM}},
\bar\theta_{\mathrm{QCD}}
\bigr).
\]

The count is

\[
\underbrace{3}_{g_s,g,g'}
+
\underbrace{2}_{\mu_H^2,\lambda}
+
\underbrace{9}_{\text{charged-fermion masses}}
+
\underbrace{4}_{V_{\mathrm{CKM}}}
+
\underbrace{1}_{\bar\theta_{\mathrm{QCD}}}
=19.
\]

#### Receipt

The 2026 Particle Data Group electroweak review identifies seventeen electroweak free parameters: \(g,g'\), two scalar-potential parameters, nine charged-fermion masses, and four CKM coordinates. It then completes the full Standard Model register with \(\alpha_s\) and the strong-CP angle. The 2026 Higgs review independently describes nineteen input parameters and assigns fifteen of them to the scalar/Yukawa sector.

### Corollary 1.2 — Coordinate-count invariance

Let \(F\) be an invertible change between complete parameter bases on a stated domain:

\[
F:\Theta\longrightarrow\Theta'.
\]

Then

\[
\dim\Theta'=\dim\Theta.
\]

Replacing \((g,g',\mu_H^2,\lambda)\) by an experimentally convenient set such as \((\alpha,G_F,M_Z,M_H)\) changes the coordinate chart. It preserves the number of independent inputs.

---

## 2. Structural register

Structural entries state which dynamical system is being evaluated. Their empirical success supports the declared model. Their discrete form keeps them outside the continuous count.

| ID | Structural entry | Mechanical office | Evidence or consistency condition | Recognition status |
|---|---|---|---|---|
| S01 | local gauge algebra \(\mathfrak{su}(3)_c\oplus\mathfrak{su}(2)_L\oplus\mathfrak u(1)_Y\) | connection directions and brackets | strong, weak, and electromagnetic interaction records | **RECEIVED / COORDINATED** |
| S02 | global gauge-group quotient \(\Gamma\subset Z(SU(3)\times SU(2)\times U(1))\) | global bundle and line-operator admissibility | global observables and topology | **DECLARED / OPEN selection** |
| S03 | chiral matter representations | states on which the connection acts | charged-current chirality, color, charge assignments | **RECEIVED / CONSTRAINED** |
| S04 | hypercharge assignments | \(U(1)_Y\) action and electric-charge relation | measured charges plus anomaly cancellation | **RECEIVED / CONSTRAINED** |
| S05 | one complex scalar \(SU(2)\) doublet | electroweak vacuum and radial mode | Higgs and electroweak receipts | **DECLARED / MEASURED** |
| S06 | three fermion generations | repeated matter register | flavor, Higgs, and electroweak precision data | **MEASURED; upstream selection OPEN** |
| S07 | absence of right-handed neutrinos in the minimal register | renormalizable neutrino mass office remains empty | observed oscillations require an extension | **DECLARED minimal model / empirically incomplete sector** |
| S08 | four-dimensional Lorentzian background for ordinary calculations | spacetime carrier and causal ordering | relativistic experiments | **IMPORTED physical framework** |
| S09 | locality and renormalizable operator restriction | action admissibility | predictive quantum field theory within its energy jurisdiction | **DECLARED method condition** |

### 2.1 Anomaly cancellation constrains admissibility

For one generation, the declared representations satisfy

\[
SU(3)^3,quad
SU(3)^2U(1),quad
SU(2)^2U(1),quad
\mathrm{grav}^2U(1),quad
U(1)^3
\]

anomaly cancellation, together with even \(SU(2)\) doublet parity for the Witten global anomaly. This certificate tests the representation register. It leaves the upstream selection of the observed representation pattern as a separate question.

### 2.2 Generation count

The value

\[
N_g=3
\]

is an empirically secured discrete input. Repetition preserves the generation-by-generation anomaly receipt. The present architecture transports the threefold register and leaves its independent selection **OPEN**.

---

## 3. Gauge-coupling register

| ID | Standard coordinate | Action office | Running and scheme | Principal empirical readers | Present architecture |
|---|---|---|---|---|---|
| P01 | \(g_s\), equivalently \(\alpha_s(\mu)=g_s^2(\mu)/(4\pi)\) | \(SU(3)_c\) covariant derivative and self-interaction | strong scale dependence; reference scale, flavor thresholds, and scheme required | hadronic decays, event shapes, jets, lattice quantities, global fits | **RECEIVED; RG TRANSPORTED** |
| P02 | \(g(\mu)\) | \(SU(2)_L\) connection | electroweak running; scheme and scale required | muon decay, weak decays, \(W/Z\) observables, global electroweak fit | **RECEIVED; RG TRANSPORTED** |
| P03 | \(g'(\mu)\) | \(U(1)_Y\) connection | electroweak running; scheme and scale required | electromagnetic coupling, neutral currents, weak mixing observables | **RECEIVED; RG TRANSPORTED** |

The electroweak relations

\[
\tan\theta_W=\frac{g'}{g},
\qquad
e=g\sin\theta_W=g'\cos\theta_W
\]

are **DERIVED** inside a declared renormalization scheme. A quoted \(\sin^2\theta_W\) therefore carries its scheme and scale.

The QCD coordinate \(\Lambda_{\mathrm{QCD}}\) can replace \(\alpha_s\) at a reference scale after the scheme, active-flavor register, and threshold matching are fixed. The replacement is a parameter transport, preserving one independent strong-coupling coordinate.

---

## 4. Scalar-sector register

Use the corpus convention

\[
V(H)=-\mu_H^2H^\dagger H+\lambda(H^\dagger H)^2,
\qquad
\mu_H^2>0,
\quad
\lambda>0
\]

in the broken-phase tree-level domain.

| ID | Standard coordinate | Action office | Equivalent experimental coordinate | Principal reader | Present architecture |
|---|---|---|---|---|---|
| P04 | \(\mu_H^2(\mu)\) | quadratic scalar coefficient and vacuum scale | \(v\), or a basis containing \(G_F\) | muon decay plus electroweak radiative matching | **RECEIVED; scheme TRANSPORTED** |
| P05 | \(\lambda(\mu)\) | scalar radial curvature and self-interaction | \(M_H\) after \(v\) is fixed | Higgs pole reconstruction; self-coupling measurements test the interaction relation | **RECEIVED through mass basis; RG TRANSPORTED** |

At tree level,

\[
v^2=\frac{\mu_H^2}{\lambda},
\qquad
m_h^2=2\lambda v^2.
\]

These equations relate a chosen complete input basis. They become numerical predictions for one coordinate only after the complementary coordinates have been fixed independently.

The vacuum scale \(v\), Higgs pole mass \(M_H\), potential coefficients, and Higgs self-couplings therefore share one scalar-sector dependency graph. Counting each as independent would duplicate the same office.

---

## 5. Charged-fermion spectral register

The three Yukawa matrices

\[
Y_e,qquad Y_u,qquad Y_d
\]

contain redundant coordinates before field-basis reduction. Their observable physical content in the minimal model is nine charged-fermion masses plus four CKM coordinates.

At tree level,

\[
M_f=\frac{v}{\sqrt2}Y_f.
\]

Beyond tree level, every mass or Yukawa value carries a pole, complex-pole, running, threshold, lattice, or fitted-template prescription.

| ID | Mass coordinate | Native office | Required typing | Principal empirical reader | Present architecture |
|---|---|---|---|---|---|
| P06 | \(m_e\) | charged-lepton spectral coefficient | pole/on-shell convention | spectroscopy, kinematics, precision QED | **RECEIVED** |
| P07 | \(m_\mu\) | charged-lepton spectral coefficient | pole/on-shell convention | decay and kinematic records | **RECEIVED** |
| P08 | \(m_\tau\) | unstable charged-lepton spectral coefficient | resonance or pole convention | threshold and decay reconstruction | **RECEIVED** |
| P09 | \(m_u(\mu)\) | up-quark Yukawa eigenvalue | scheme and scale; commonly \(\overline{\mathrm{MS}}\) | lattice QCD, sum rules, hadronic observables | **RECEIVED; RG TRANSPORTED** |
| P10 | \(m_d(\mu)\) | down-quark Yukawa eigenvalue | scheme and scale; commonly \(\overline{\mathrm{MS}}\) | lattice QCD, sum rules, hadronic observables | **RECEIVED; RG TRANSPORTED** |
| P11 | \(m_s(\mu)\) | strange-quark Yukawa eigenvalue | scheme and scale; commonly \(\overline{\mathrm{MS}}\) | lattice QCD, sum rules, hadronic observables | **RECEIVED; RG TRANSPORTED** |
| P12 | \(m_c(\mu)\) | charm-quark Yukawa eigenvalue | running or threshold mass scheme | quarkonium, moments, lattice and inclusive observables | **RECEIVED; MATCHED / TRANSPORTED** |
| P13 | \(m_b(\mu)\) | bottom-quark Yukawa eigenvalue | running or threshold mass scheme | quarkonium, moments, inclusive decays, collider records | **RECEIVED; MATCHED / TRANSPORTED** |
| P14 | \(m_t\) | top-quark Yukawa eigenvalue | pole, short-distance, or calibrated event-generator mass definition | threshold, inclusive cross sections, decay reconstruction | **RECEIVED; MATCHED / TRANSPORTED** |

Quark masses are Lagrangian coordinates inferred through hadronic or collider observables. Scheme and scale are part of the address. Hadron masses are QCD spectral outputs conditional on \(g_s\), quark masses, and the nonperturbative calculation; they add zero entries to the fundamental nineteen-parameter register.

In the description-layer adapter of *Return-Weight Spectral Adapter*, a positive invariant mass may be read as a proper-time phase weight. That semantic adapter preserves the standard mass coordinate and its measurement rules.

---

## 6. Quark-mixing register

After diagonalizing \(Y_u\) and \(Y_d\), their left-handed basis mismatch enters charged-current transport as

\[
V_{\mathrm{CKM}}=V_L^uV_L^{d\dagger}.
\]

A three-generation unitary matrix has four observable coordinates in this office:

| ID | Coordinate | Function | Principal empirical reader | Present architecture |
|---|---|---|---|---|
| P15 | \(\theta_{12}^{q}\) | first–second generation mixing | kaon, nuclear, charm, and global flavor data | **RECEIVED / FITTED** |
| P16 | \(\theta_{23}^{q}\) | second–third generation mixing | charm and bottom transitions | **RECEIVED / FITTED** |
| P17 | \(\theta_{13}^{q}\) | first–third generation mixing | charmless bottom transitions and global fits | **RECEIVED / FITTED** |
| P18 | \(\delta_{\mathrm{CKM}}\) | quark-sector CP-odd phase | CP asymmetries and global unitarity-triangle fits | **RECEIVED / FITTED** |

The Wolfenstein coordinates \((\lambda_W,A,\bar\rho,\bar\eta)\) supply an equivalent chart. Unitarity constrains the matrix form. Experimental decay and asymmetry records fix its four physical coordinates.

Renormalization can transport the Yukawa matrices and therefore the mixing coordinates between scales. A numerical CKM entry inherits that scheme and matching context when used beyond leading order.

---

## 7. Strong-CP register

| ID | Coordinate | Action office | Empirical reader | Present architecture |
|---|---|---|---|---|
| P19 | \(\bar\theta_{\mathrm{QCD}}\) | CP-odd topological term, including the mass-matrix phase combination | electric-dipole-moment searches and related CP tests | **RECEIVED as a stringent bound; upstream smallness OPEN** |

The measured near-zero value is an empirical constraint. Setting the coordinate identically to zero defines a restricted model and changes the declared parameter jurisdiction from nineteen to eighteen.

---

## 8. Experimental input schemes

### 8.1 Bosonic Lagrangian basis

The original electroweak bosonic basis is

\[
\Theta_{\mathrm{EW,bos}}^{\mathcal L}
=
(g,g',\mu_H^2,\lambda).
\]

### 8.2 Representative observable bases

Current calculations commonly trade those coefficients for four experimentally accessible inputs. Examples include

\[
(\alpha(0),G_F,M_Z,M_H),
\]

\[
(\alpha(0),M_W,M_Z,M_H),
\]

\[
(\alpha(M_Z^2),M_W,M_Z,M_H),
\]

or

\[
(G_F,M_W,M_Z,M_H).
\]

Each basis requires a declared renormalization scheme and radiative matching. The unused bosonic observables then become derived cross-checks.

### 8.3 Tree-level dependency map

\[
G_F
\longleftrightarrow
v,
\]

\[
(g,g',v)
\longrightarrow
(e,\theta_W,m_W,m_Z),
\]

\[
(\lambda,v)
\longrightarrow
m_h,
\]

\[
(Y_f,v)
\longrightarrow
M_f.
\]

Radiative corrections replace these arrows by scheme-dependent calculated adapters. The dependency direction remains auditable: an output called a prediction must be absent from the chosen independent input set.

### 8.4 Double-counting guard

A fit may use \(M_W\) as input or derive it from \(\alpha,G_F,M_Z\). Counting both roles as independent evidence duplicates one office. The complete record must name:

1. the independent input basis;
2. the held-out observables;
3. the radiative order;
4. the scheme and scale;
5. correlations and uncertainties.

---

## 9. Scale, scheme, and computational register

These entries determine the coordinate realization of a calculation. They remain outside the nineteen physical parameters.

| ID | Input | Office | Status |
|---|---|---|---|
| C01 | renormalization scheme | defines the meaning of renormalized couplings, masses, and fields | **DECLARED** |
| C02 | renormalization scale \(\mu_{\mathrm{ren}}\) | addresses running parameters and truncation uncertainty | **DECLARED; RG TRANSPORT** |
| C03 | factorization scheme and scale \(\mu_F\) | separates short-distance coefficients from hadronic functions | **DECLARED** |
| C04 | perturbative order and resummation prescription | fixes retained terms and missing-order estimate | **DECLARED** |
| C05 | regulator | supplies an intermediate finite representation | **DECLARED; removed or matched in final observable** |
| C06 | effective-field-theory operator basis and matching scale | states the truncated jurisdiction and Wilson-coordinate chart | **DECLARED / MATCHED** |
| C07 | lattice spacing, volume, action, and continuum extrapolation | defines a nonperturbative computational realization | **DECLARED / COMPUTED** |
| C08 | gauge fixing | selects calculational representatives inside one gauge orbit | **DECLARED computational coordinate** |

Physical observables remain invariant under exact scheme changes. Finite-order calculations retain residual scale and scheme dependence, which supplies part of the theoretical uncertainty receipt.

---

## 10. Nonperturbative, occurrence, and apparatus register

Prediction at an actual detector requires further inputs whose functions differ from Lagrangian parameters.

| ID | Input | Mechanical office | Source | Status |
|---|---|---|---|---|
| O01 | parton distribution functions | hadron-to-parton preparation map | global scattering fits plus QCD evolution | **RECEIVED / FITTED / TRANSPORTED** |
| O02 | fragmentation functions | parton-to-hadron readout map | identified-hadron data plus evolution | **RECEIVED / FITTED / TRANSPORTED** |
| O03 | hadronic form factors and matrix elements | composite-state transition adapter | lattice, sum rules, symmetry, and decay data | **COMPUTED / RECEIVED** |
| O04 | nuclear matrix elements | nucleus-to-fundamental-interaction adapter | nuclear theory and calibration data | **COMPUTED / RECEIVED** |
| O05 | prepared beam or source state | initial occurrence condition | accelerator, source, and monitoring records | **MEASURED** |
| O06 | luminosity, flux, target, and exposure | occurrence normalization | calibration and monitoring | **MEASURED** |
| O07 | detector geometry, efficiency, resolution, and response | trace-to-record adapter | calibration samples and simulation | **MEASURED / FITTED** |
| O08 | event selection and acceptance | admission predicate for recorded events | declared analysis procedure | **DECLARED / VALIDATED** |
| O09 | background and nuisance model | rival occurrence and uncertainty register | sidebands, control regions, auxiliary measurements | **FIT / CONSTRAINED** |
| O10 | statistical likelihood and interval rule | record-to-inference adapter | declared statistical method | **DECLARED** |

These inputs can dominate the uncertainty of a measurement while contributing zero new terms to the fundamental Standard Model Lagrangian.

---

## 11. Neutrino extension register

The minimal renormalizable Standard Model assigns zero neutrino masses because its field register lacks the required right-handed singlets and renormalizable Majorana operator. Oscillation records establish nonzero mass-squared differences, so a complete empirical account requires an extension.

### 11.1 Carrier choices

| ID | Extension carrier | Added structure | Status |
|---|---|---|---|
| N00-D | right-handed neutrino singlets with Dirac Yukawa matrix | new representations and Yukawa coefficients | **OPEN model selection** |
| N00-M | Majorana mass carrier, including the dimension-five Weinberg operator or a higher theory | new scale and symmetric mass matrix | **OPEN model selection** |

Distinct carriers can produce the same low-energy oscillation normal form. Their shared fit leaves the upstream mechanism unresolved.

### 11.2 Low-energy three-neutrino coordinates

| ID | Coordinate | Reader | Status |
|---|---|---|---|
| N01 | \(\Delta m_{21}^2\) | solar, reactor, and combined oscillation patterns | **MEASURED / FITTED** |
| N02 | \(\Delta m_{3\ell}^2\) | atmospheric, accelerator, and reactor patterns | **MEASURED / FITTED** |
| N03 | \(\theta_{12}^{\nu}\) | solar/reactor flavor-return amplitudes | **MEASURED / FITTED** |
| N04 | \(\theta_{23}^{\nu}\) | atmospheric/accelerator flavor-return amplitudes | **MEASURED / FITTED** |
| N05 | \(\theta_{13}^{\nu}\) | reactor and accelerator flavor-return amplitudes | **MEASURED / FITTED** |
| N06 | \(\delta_{\mathrm{CP}}^{\nu}\) | CP-sensitive appearance comparisons | **CONSTRAINED / FITTED** |
| N07 | lightest mass \(m_{\mathrm{lightest}}\) | beta endpoint, cosmological model fits, and other absolute-scale readers | **CONSTRAINED; value OPEN** |
| N08 | mass ordering | sign/order relation among eigenvalues | oscillation comparisons | **DISCRETE empirical question** |
| N09 | Majorana phase \(\eta_1\) | lepton-number-violating amplitudes | **OPEN** |
| N10 | Majorana phase \(\eta_2\) | lepton-number-violating amplitudes | **OPEN** |

Oscillation probabilities depend on two independent mass-squared differences, three mixing angles, and one Dirac phase. A common shift of all \(m_i^2\) leaves that reader invariant. Absolute mass and Majorana phases therefore require different apparatus offices.

### 11.3 Extended parameter counts

Using three mass eigenvalues as the spectral coordinates:

\[
N_{\mathrm{Dirac}\ \nu}
=19+(3_{m_\nu}+3_{\mathrm{angles}}+1_{\mathrm{phase}})
=26,
\]

\[
N_{\mathrm{Majorana}\ \nu}
=19+(3_{m_\nu}+3_{\mathrm{angles}}+3_{\mathrm{phases}})
=28.
\]

These counts describe low-energy parameter content under the stated carrier choices. Additional heavy states or effective-operator coefficients enlarge the register according to their own jurisdiction.

---

## 12. Gravity and cosmology boundary

Gravity occupies a distinct carrier and parameter office. A Standard Model calculation on a prescribed metric receives the background geometry. A coupled classical calculation adds the Einstein-sector inputs and boundary data.

| ID | Input | Office | Status |
|---|---|---|---|
| G01 | Newton coupling \(G_N\) | stress-energy-to-curvature response scale | **RECEIVED** |
| G02 | cosmological constant \(\Lambda\) | vacuum curvature term | **RECEIVED / cosmologically fitted** |
| G03 | metric and boundary/initial data | spacetime occurrence carrier | **DECLARED / MEASURED by problem** |
| G04 | quantum gravity completion | joint ultraviolet dynamics | **OPEN** |

Cosmological densities, primordial conditions, dark-sector parameters, and astrophysical nuisance models belong to further empirical registers. They add zero entries to \(\Theta_{\mathrm{SM}}^{(19)}\).

---

## 13. What the present architecture does with each register

| Input class | Selected | Derived | Transported | Received | Present boundary |
|---|---:|---:|---:|---:|---|
| root operator \(Q\) inside \(\mathcal D_{\mathrm{tr}}\) | yes | yes | yes | — | jurisdiction-dependent mathematical selection |
| Standard Model bracket ranks and kernels | — | yes | coordinate transported | structural carrier imported | exact algebraic closure |
| electroweak mass-operator rank and null line | — | yes | Weinberg transported | \(g,g',v\) received | exact conditional spectrum structure |
| representation commutation and anomalies | — | yes | generation repeated | representations received | admissibility certified |
| numerical gauge couplings | — | relations only | RG transported | yes | upstream numerical selection open |
| scalar scale and curvature | — | conditional relations | RG and scheme transported | yes | upstream numerical selection open |
| charged-fermion masses and Yukawas | — | basis relations | RG and matching transported | yes | flavor hierarchy open |
| CKM coordinates | — | unitarity relations | RG transported | yes | numerical selection open |
| strong-CP angle | — | observable consequences | carried as physical angle | bound received | smallness open |
| neutrino parameters | — | oscillation relations | phase transported | partially received | carrier and remaining values open |
| cross sections and decay rates | — | conditionally computed | scale evolved | parameters and state received | apparatus certificate required |
| detector inference | — | conditional on response model | calibration transported | physical traces received | uncertainty and loss boundary required |

The present corpus therefore performs four earned operations:

1. it **selects** mathematical carriers inside declared mathematical jurisdictions;
2. it **derives** structural consequences of the imported Standard Model carrier;
3. it **transports** parameters through scale, basis, and observable adapters;
4. it **receives** numerical physical coordinates from empirical records.

Every numerical entry of \(\Theta_{\mathrm{SM}}^{(19)}\) currently occupies the fourth line.

---

## 14. Forced-number certificate

Gap B closes for a candidate quantity \(q\) only when one record supplies every field below.

| Field | Required receipt |
|---|---|
| target | identify the previously free Standard Model coordinate \(q\) |
| prior status | show where \(q\) entered the established theory as empirical input |
| upstream premises | list assumptions independently of the measured value of \(q\) |
| selector | construct a map whose admissible solution set fixes \(q\) |
| uniqueness | prove the selected value or bounded orbit inside the declared jurisdiction |
| dimensions | supply the physical unit or dimensionless normalization |
| scheme and scale | state the renormalization convention and reference scale |
| sensitivity | propagate uncertainty from every premise and computational approximation |
| parameterization invariance | recover the same physical prediction in an equivalent input chart |
| held-out observable | identify a receipt excluded from the selection step |
| rival set | state competing values or models tested by the same apparatus |
| prospective gate | freeze the prediction and acceptance rule before reading the held-out data |
| outcome | record **ADMIT**, **REFUSE**, or **DEFER** |

### Definition 14.1 — New predictive physical content

A result supplies new predictive physical content in this register when it reduces the number or admissible range of empirical inputs and survives the complete forced-number certificate.

Structural compression, basis change, dimensional coincidence, shared cardinality, and post-fit reconstruction can each be mathematically valuable. Their authority remains **REORGANIZATION** until the certificate closes.

---

## 15. Minimum compression

The Standard Model fixes the admissible form of its dynamics through symmetry, representations, locality, and action.

Empirical records fix or bound nineteen continuous coordinates in the minimal massless-neutrino jurisdiction.

Renormalization moves those coordinates between scales.

Field redefinitions and input schemes change their chart.

The action relates them.

Calculation carries them toward observables.

Apparatus records constrain them.

Recognition compares the returned record with the declared prediction.

The current architecture coordinates this full passage. Its next predictive threshold is exact:

> Select one coordinate that established physics presently receives, carry it through a certified physical adapter, and recover it from a held-out receipt.

---

## 16. Source ledger

### Primary and authoritative external sources

1. F. Takahashi et al. (Particle Data Group), *Review of Particle Physics*, **International Journal of Modern Physics A 41**, 2630011 (2026). <https://pdg.lbl.gov/2026/>
2. J. de Blas, S. Dittmaier, and R. Kogler, “Electroweak Model and Constraints on New Physics,” in *Review of Particle Physics* (2026). <https://pdg.lbl.gov/2026/reviews/rpp2026-rev-standard-model.pdf>
3. Particle Data Group, “Quantum Chromodynamics,” in *Review of Particle Physics* (2026). <https://pdg.lbl.gov/2026/reviews/rpp2026-rev-qcd.pdf>
4. Particle Data Group, “Status of Higgs Boson Physics,” in *Review of Particle Physics* (2026). <https://pdg.lbl.gov/2026/reviews/rpp2026-rev-higgs-boson.pdf>
5. A. Ceccucci, Z. Ligeti, and Y. Sakai, “CKM Quark-Mixing Matrix,” in *Review of Particle Physics* (2026). <https://pdg.lbl.gov/2026/reviews/rpp2026-rev-ckm-matrix.pdf>
6. Particle Data Group, “Neutrino Masses, Mixing, and Oscillations,” in *Review of Particle Physics* (2026). <https://pdg.lbl.gov/2026/reviews/rpp2026-rev-neutrino-mixing.pdf>
7. Particle Data Group, “Quark Masses,” in *Review of Particle Physics* (2026). <https://pdg.lbl.gov/2026/reviews/rpp2026-rev-quark-masses.pdf>
8. Particle Data Group, “Particle Detectors at Accelerators,” in *Review of Particle Physics* (2026). <https://pdg.lbl.gov/2026/reviews/rpp2026-rev-particle-detectors-accel.pdf>
9. Particle Data Group, “Statistics,” in *Review of Particle Physics* (2026). <https://pdg.lbl.gov/2026/reviews/rpp2026-rev-statistics.pdf>

### Internal dependencies

10. Anthony V. Coppa, *Everything: The Minimum Classical Closure*, v0.11.
11. Anthony V. Coppa, *Form \(\Lambda\) Fit \(\Delta\) Function: Canonical Method Kernel*, v0.1.
12. Anthony V. Coppa, *Physical Adapter Certificate*, v0.1.
13. Anthony V. Coppa, *Cross-Sector Observable Certificate*, v0.1.
14. Anthony V. Coppa, *The Standard Model as Constrained Dynamics*, v0.2.
15. Anthony V. Coppa, *Return-Weight Spectral Adapter*, v0.2.
16. Anthony V. Coppa, *The Electroweak Two-Operator Certificate*, v0.1.
17. Anthony V. Coppa, *The 28-Seam Color-Bracket Adapter*, v0.1.

### Source-to-claim map

| Claim | Source |
|---|---|
| nineteen-parameter census and electroweak input bases | Particle Data Group electroweak and Higgs reviews |
| gauge-coupling and QCD scale transport | Particle Data Group QCD review |
| nine charged-fermion masses and four physical CKM coordinates | Particle Data Group electroweak, CKM, and quark-mass reviews |
| neutrino extension and low-energy parameter register | Particle Data Group neutrino review |
| detector, nuisance, and statistical inputs | Particle Data Group detector and statistics reviews; internal observable certificates |
| selection, derivation, transport, and receipt offices | internal canonical-method corpus |
| electroweak two-operator distinction | *The Electroweak Two-Operator Certificate* |
| color and full-gauge bracket structure | *The 28-Seam Color-Bracket Adapter*; *The Standard Model as Constrained Dynamics* |

---

## Status note

- **Minimal continuous register:** nineteen entries under the retained strong-CP convention.
- **Coordinate changes:** preserve the independent count when the adapter is invertible.
- **Structural declarations:** separately registered.
- **Computational and apparatus inputs:** separately registered.
- **Neutrino extension:** separately typed; carrier selection remains open.
- **Gravity joint:** separate parameter office.
- **Recognition architecture:** selects mathematical structure, derives and transports physical relations, and receives current numerical Standard Model inputs.
- **Gap B:** open under the forced-number certificate.
