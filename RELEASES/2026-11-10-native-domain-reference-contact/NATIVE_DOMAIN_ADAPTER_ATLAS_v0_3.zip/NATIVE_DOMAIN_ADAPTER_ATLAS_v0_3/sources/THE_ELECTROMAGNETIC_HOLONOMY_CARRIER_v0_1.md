# THE ELECTROMAGNETIC HOLONOMY CARRIER

## A calibrated \(U(1)\) physical instantiation

**Version 0.1 — 20 August 2026**

---

## Status and purpose

This note carries the commuting \(U(1)\) control of *The Classical Gauge Spine* into one measured physical configuration: the magnetic Aharonov–Bohm experiment.

It closes a specific chain:

\[
\boxed{
\text{electromagnetic connection}
\to
\text{charged-wave transport}
\to
\text{relative phase}
\to
\text{interference receipt}
}
\]

The experiment supplies the physical carrier independently. The root construction supplies an exact real coordinate representation of its compact phase axis. Neither is used to manufacture the other.

Three statuses remain distinct:

- **DERIVED** — follows from the declared physical model or displayed algebra;
- **MEASURED** — reported by the cited experiment;
- **DECLARED** — selected convention, carrier, orientation, or experimental condition;
- **OPEN** — not established here.

---

## 1. The correction at the root

The magnetic Aharonov–Bohm effect is often summarized by saying that a magnetic potential affects an electron where the magnetic field is zero. That compression is useful only if its offices remain typed.

The electron is already moving. The electromagnetic potential does not supply motion to a static electron. The wave already carries phase. The connection governs how that phase is transported along each admitted path. Recombination reads the difference between the transported phases.

Likewise, “field-free” does not mean empty, still, or outside all physical relation. It means:

\[
F_{\mathrm{em}}=0
\]

on the region accessible to the electron wave. The electromagnetic connection may nevertheless have nontrivial holonomy around an excluded flux-bearing region.

The exact correction is:

> Zero local electromagnetic curvature does not imply trivial global electromagnetic transport.

This is not a revision of electromagnetism or quantum mechanics. It is their existing distinction between local curvature, global topology, transport, and observation, stated without allowing one office to replace another.

---

## 2. Physical configuration

Let \(D\subset\mathbb R^2\) be the cross-section of an inaccessible magnetic-flux carrier and let

\[
M=\mathbb R^2\setminus D
\]

be the region accessible to a coherent charged matter wave. In the shielded toroidal realization, \(M\) is the corresponding accessible three-dimensional complement.

Declare:

- a coherent particle of charge \(q\), with \(q=-e\) for an electron;
- two paths \(\gamma_1,\gamma_2\subset M\) from a common source to a common detector;
- the closed comparison loop
  \[
  C=\gamma_1\cdot\gamma_2^{-1};
  \]
- an electromagnetic potential one-form \(A_{\mathrm{em}}\);
- electromagnetic curvature
  \[
  F_{\mathrm{em}}=dA_{\mathrm{em}};
  \]
- magnetic flux \(\Phi_B\) enclosed by \(C\);
- coherent recombination at the detector.

Along the admitted paths,

\[
F_{\mathrm{em}}\big|_M=0.
\]

But \(M\) is not simply connected. The restricted potential may be closed without being globally exact:

\[
dA_{\mathrm{em}}=0
\quad\text{on }M,
\qquad
[A_{\mathrm{em}}]\neq0
\quad\text{in }H^1_{\mathrm{dR}}(M).
\]

Consequently,

\[
\oint_C A_{\mathrm{em}}
\]

need not vanish.

If a spanning surface \(\Sigma\) is allowed to pass through the excluded flux region, then

\[
\oint_C A_{\mathrm{em}}
=
\int_\Sigma F_{\mathrm{em}}
=
\Phi_B.
\]

There is no contradiction with Stokes’ theorem on \(M\): a loop winding around \(D\) has no spanning surface contained entirely in \(M\).

---

## 3. Units and dimensionless connection

In SI units:

- \(q\) has unit coulomb;
- \(\Phi_B\) has unit weber;
- \(1\ \mathrm{Wb}=1\ \mathrm{V\,s}=1\ \mathrm{J\,s\,C^{-1}}\);
- \(\hbar\) has unit joule-second.

Therefore

\[
\frac{q\Phi_B}{\hbar}
\]

is dimensionless, as a phase must be.

The current SI fixes exactly

\[
h=6.626\,070\,15\times10^{-34}\ \mathrm{J\,s},
\]

and

\[
e=1.602\,176\,634\times10^{-19}\ \mathrm C.
\]

For a charge of magnitude \(e\), the full phase period corresponds to

\[
\Phi_0=\frac{h}{e}
\approx
4.135\,667\,6969\times10^{-15}\ \mathrm{Wb}.
\]

The superconducting flux quantum is

\[
\Phi_{\mathrm{sc}}=\frac{h}{2e}
\approx
2.067\,833\,8485\times10^{-15}\ \mathrm{Wb}.
\]

These constants and units enter from the independently measured and defined physical formalism. They are not derived from the root algebra.

---

## 4. The \(\Omega\)-axis adapter

The root construction supplies

\[
\Omega=
\begin{pmatrix}
0&1\\
-1&0
\end{pmatrix},
\qquad
\Omega^2=-I.
\]

Let

\[
\chi:\mathbb R^2\to\mathbb C,
\qquad
\chi(x,y)=x+\mathbf i y.
\]

Then

\[
\chi(\Omega v)=-\mathbf i\,\chi(v),
\]

and hence

\[
\chi\,e^{\theta\Omega}\chi^{-1}
=
e^{-\mathbf i\theta}.
\]

This is an exact equivalence between the real two-dimensional rotation representation and the complex one-dimensional \(U(1)\) representation.

Define the dimensionless real-matrix connection

\[
\mathcal A_\Omega
=
\frac{q}{\hbar}A_{\mathrm{em}}\,\Omega.
\]

Using the transport convention

\[
U_\gamma^\Omega
=
\exp\!\left(-\int_\gamma\mathcal A_\Omega\right),
\]

the complex representation gives

\[
\chi U_\gamma^\Omega\chi^{-1}
=
\exp\!\left(
\frac{\mathbf i q}{\hbar}
\int_\gamma A_{\mathrm{em}}
\right).
\]

For the closed comparison loop,

\[
\boxed{
\chi U_C^\Omega\chi^{-1}
=
\exp\!\left(
\frac{\mathbf i q\Phi_B}{\hbar}
\right)
}.
\]

Thus the root \(\Omega\)-axis and the physical \(U(1)\) phase carrier are connected by a certified representation adapter.

### What the adapter preserves

| Field | Certified content |
|---|---|
| Domain | the real compact axis \(\mathbb R\Omega\) |
| Operation | \(\chi(x,y)=x+\mathbf i y\) |
| Codomain | the standard complex \(U(1)\) representation |
| Invariant | group multiplication and Euclidean norm |
| Symmetry | compact phase rotation |
| Receipt | equality of the real rotation and complex phase exponentials |

### What the adapter does not supply

The adapter does not derive:

- electric charge \(q\);
- Planck’s constant or \(\hbar\);
- the electromagnetic potential;
- the magnetic flux;
- the topology of the experimental apparatus;
- coherent electron propagation;
- the interference detector;
- the observed phase shift.

Those are physical inputs and receipts.

---

## 5. Gauge covariance

Under a \(U(1)\) gauge transformation,

\[
A_{\mathrm{em}}\mapsto A_{\mathrm{em}}+d\lambda.
\]

For a closed loop and a single-valued gauge parameter,

\[
\oint_C d\lambda=0,
\]

so

\[
\exp\!\left(
\frac{\mathbf i q}{\hbar}
\oint_C A_{\mathrm{em}}
\right)
\]

is unchanged.

For open paths, the transported phase is frame-dependent at its endpoints. The observable comparison becomes gauge invariant only after the two paths share source and detector frames, or after the endpoint matter phases are included.

The closed loop is therefore not decorative. It is the minimum gauge-invariant comparison carrier.

---

## 6. The measured receipt

Let the two recombining amplitudes be

\[
\psi_1=\sqrt{I_1}\,e^{\mathbf i\varphi_1},
\qquad
\psi_2=\sqrt{I_2}\,e^{\mathbf i\varphi_2}.
\]

The detector reads

\[
I
=
|\psi_1+\psi_2|^2
=
I_1+I_2
+2\sqrt{I_1I_2}
\cos(\Delta\varphi_0+\Delta\varphi_{\mathrm{AB}}),
\]

where \(\Delta\varphi_0\) contains nonmagnetic path differences and

\[
\boxed{
\Delta\varphi_{\mathrm{AB}}
=
\frac{q\Phi_B}{\hbar}
\pmod{2\pi}
}.
\]

For an electron, \(q=-e\). Reversing the loop orientation or flux reverses the phase sign. The interference displacement retains that orientation information relative to the apparatus.

Aharonov and Bohm proposed this force-free phase effect in 1959. Tonomura and collaborators observed agreement with the fundamental phase relation by electron holography in 1982. In 1986 they reported the expected relative phase shift with the magnetic field confined inside a superconducting, copper-covered toroidal ferromagnet and shielded from the electron wave.

The 1986 superconducting configuration admitted enclosed flux in units of \(h/(2e)\). For an electron,

\[
\left|
\frac{q}{\hbar}\frac{h}{2e}
\right|
=
\pi,
\]

so the reported relative phase was \(0\) or \(\pi\), depending on the trapped flux sector.

This is the outside receipt:

> A change in enclosed magnetic flux changes the recombined electron phase even when the admitted electron paths remain outside the confined magnetic field.

---

## 7. Condition and constraint register

| Office | Required condition or constraint | Failure mode |
|---|---|---|
| carrier | coherent charged matter wave | incoherence erases stable fringes |
| split | two distinguishable admitted paths | no relative-path comparison |
| return | recombination in a common detector frame | open endpoint phase remains gauge-relative |
| exclusion | electron wave does not enter the flux-bearing region | local field interaction contaminates the topology-only read |
| shielding | leakage fields are controlled below the experimental discrimination scale | force-based alternatives remain admissible |
| topology | loop winds nontrivially around the excluded region | contractible loop in a flat region has trivial holonomy |
| connection | \(A_{\mathrm{em}}\) is defined patchwise with lawful gauge transitions | an untyped potential has no transport authority |
| curvature | \(F_{\mathrm{em}}=0\) on admitted paths | local Lorentz-force effects enter |
| units | \(qA_{\mathrm{em}}/\hbar\) is used in the phase connection | exponent is dimensionally ill-typed |
| flux stability | enclosed flux is stable during traversal | time dependence introduces electric fields and additional phase terms |
| receipt | interference phase is measured with uncertainty and controls | formal holonomy remains unrecognized physically |

The physical claim is conditional on this register. The experiments are important because they were designed to close the principal alternative paths, especially magnetic-field leakage into the electron region.

---

## 8. What “silence” can mean here

The word *silence* is admissible only after its physical office is stated.

In this carrier it may compress:

\[
F_{\mathrm{em}}\big|_M=0,
\]

meaning zero local electromagnetic curvature on the admitted electron region.

It does not mean:

- zero electron momentum;
- zero quantum evolution;
- zero phase accumulation;
- zero electromagnetic flux in the excluded region;
- zero global holonomy;
- zero experimental information;
- an ontological void or a universal still background.

The carrier therefore supplies a precise instance of a wider methodological correction:

> Silence is typed absence within an office, not cancellation of the occurrence carrying the read.

---

## 9. Return, phase, and Memory

The two paths return to a common detector. Their phase difference survives that return. Neither statement establishes Memory in the stronger root sense.

The Wilson phase

\[
e^{\mathbf i q\Phi_B/\hbar}
\]

retains one quotient of the traversal. Because phase is periodic, it identifies fluxes differing by

\[
n\frac{h}{q},
\qquad n\in\mathbb Z,
\]

up to orientation and sign conventions. It therefore cannot reconstruct the complete path history or flux history without additional records.

The exact status is:

- path recombination: **DECLARED and physically realized**;
- phase holonomy: **DERIVED**;
- interference displacement: **MEASURED**;
- complete occurrence memory: **REFUSED** from the phase receipt alone.

Phase return, occurrence return, and remembered return remain different offices.

---

## 10. Root-object verdicts in this carrier

| Root object | Role here | Verdict |
|---|---|---|
| \(\Omega\) | real generator of the compact \(U(1)\) phase representation | **ADMITTED** through \(\chi\) |
| \(I\) | identity transformation | **ADMITTED** |
| \(Q\) | none required | **NOT USED** |
| \(Q^2\) | none required | **NOT USED; NOT FORCED** |
| \(G\) | none required | **NOT USED** |
| \(H\) | none required | **NOT USED** |
| \(K\) | none required | **NOT USED** |
| \(\mathbf i\) | ordinary complex scalar in the matter-wave representation | **DECLARED physical representation data** |
| root path receipt | separate formal record | does not become the experimental phase automatically |

The absence of \(Q^2\) is a positive result. This carrier closes without it. The even carriage remains available for a later office only if a native physical construction requires it.

---

## 11. CORDIS record

### Domain

A coherent charged matter wave on two paths in the accessible complement of a confined magnetic-flux region.

### Operation

Parallel transport by the dimensionless electromagnetic \(U(1)\) connection:

\[
\mathcal A_\Omega
=
\frac{q}{\hbar}A_{\mathrm{em}}\,\Omega.
\]

### Codomain

A relative compact phase:

\[
U_C\in U(1).
\]

### Invariant

Closed-loop holonomy under lawful gauge transformation:

\[
U_C
=
\exp\!\left(
\frac{\mathbf i q}{\hbar}
\oint_C A_{\mathrm{em}}
\right).
\]

### Symmetry

Local electromagnetic \(U(1)\) gauge symmetry.

### Receipt

An interference-fringe displacement corresponding to

\[
\Delta\varphi_{\mathrm{AB}}
=
\frac{q\Phi_B}{\hbar}
\pmod{2\pi}.
\]

This CORDIS record reaches an empirical codomain. The observation belongs to the cited experiment, not to the root algebra.

---

## 12. What closes

The following claims are closed:

1. The root matrix \(\Omega\) is exactly equivalent to the standard complex \(U(1)\) generator under \(\chi\).
2. Multiplying the electromagnetic potential by \(q/\hbar\) produces a dimensionless phase connection.
3. Parallel transport around the comparison loop yields \(e^{\mathbf i q\Phi_B/\hbar}\).
4. The phase is gauge invariant for the closed physical comparison.
5. Local zero curvature on the accessible region is compatible with nontrivial holonomy because the region is multiply connected.
6. The phase changes the interference receipt without supplying the electron’s underlying motion.
7. Electron holography has measured the predicted phase relation in field-excluded configurations.
8. The physical carrier closes using \(\Omega\) alone; \(Q^2\) is not required.

---

## 13. What remains open

This note does not:

- derive electromagnetism from the root algebra;
- derive \(e\), \(h\), \(\hbar\), the fine-structure constant, or any empirical constant;
- identify zero curvature with universal silence;
- convert phase holonomy into complete Memory;
- prove that electromagnetic potentials are uniquely fundamental rather than connection representatives;
- supply a non-Abelian physical instantiation;
- connect \(Q^2\) to a measured transport;
- add a new prediction to the Aharonov–Bohm effect.

Its contribution is a typed and receipt-bearing adapter between an existing root coordinate and an independently established physical mechanism.

---

## 14. Source ledger

### Primary sources

1. James Clerk Maxwell, “A Dynamical Theory of the Electromagnetic Field,” *Philosophical Transactions of the Royal Society of London* **155** (1865), 459–512. <https://doi.org/10.1098/rstl.1865.0008>
2. Y. Aharonov and D. Bohm, “Significance of Electromagnetic Potentials in the Quantum Theory,” *Physical Review* **115** (1959), 485–491. <https://doi.org/10.1103/PhysRev.115.485>
3. Tai Tsun Wu and Chen Ning Yang, “Concept of Nonintegrable Phase Factors and Global Formulation of Gauge Fields,” *Physical Review D* **12** (1975), 3845–3857. <https://doi.org/10.1103/PhysRevD.12.3845>
4. A. Tonomura et al., “Observation of Aharonov–Bohm Effect by Electron Holography,” *Physical Review Letters* **48** (1982), 1443–1446. <https://doi.org/10.1103/PhysRevLett.48.1443>
5. A. Tonomura et al., “Evidence for Aharonov–Bohm Effect with Magnetic Field Completely Shielded from Electron Wave,” *Physical Review Letters* **56** (1986), 792–795. <https://doi.org/10.1103/PhysRevLett.56.792>
6. N. Osakabe et al., “Experimental Confirmation of Aharonov–Bohm Effect Using a Toroidal Magnetic Field Confined by a Superconductor,” *Physical Review A* **34** (1986), 815–822. <https://doi.org/10.1103/PhysRevA.34.815>
7. Bureau International des Poids et Mesures, *The International System of Units (SI)*, 9th edition, version 4.01 (June 2026). <https://doi.org/10.59161/AUEZ1291>

### Internal source

8. *The Classical Gauge Spine: A Certified \(U(1)\to SU(2)\) Root-to-Crown Joint*, v0.1.

### Source-to-claim map

| Claim | Source |
|---|---|
| classical electromagnetic field and potential lineage | Maxwell |
| force-free electromagnetic phase proposal | Aharonov and Bohm |
| global connection and nonintegrable phase language | Wu and Yang |
| electron-holography observation in field-free paths | Tonomura et al. 1982 |
| shielded toroidal observation | Tonomura et al. 1986; Osakabe et al. 1986 |
| SI values and dimensions of \(h\), \(e\), and the weber | BIPM 2026 |
| \(\Omega\)-representation adapter and methodological verdicts | present derivation |

---

## Status note

This is the first measured physical carrier attached to the classical gauge spine.

The physical theory supplies the connection, charge, units, paths, topology, and detector. The root supplies an exact real representation of the compact phase generator. Their adapter preserves phase transport and nothing beyond its certificate.

The local field is silent. The wave is not still. The return carries a measurable difference.
