# PHYSICAL ADAPTER CERTIFICATE

## Minimum protocol for formal-to-physical transport

**Version 0.1 — 20 August 2026**

---

## Purpose

A formal structure and a physical mechanism may occupy the same normal form without being the same occurrence. This certificate states the minimum record required before a result may pass from a formal jurisdiction into a physical one.

Its function is not to obstruct comparison. It is to make comparison transportable.

The certificate extends CORDIS:

\[
\boxed{
\text{domain}
\to
\text{operation}
\to
\text{codomain}
\to
\text{invariant}
\to
\text{symmetry}
\to
\text{receipt}
}
\]

with the conditions, constraints, units, evidence, and information-loss boundary required for physical recognition.

---

## 1. Governing rule

> No shared word, glyph, dimension, matrix size, normal form, or visual resemblance transports proof between jurisdictions.

A physical adapter is admitted only when:

1. both jurisdictions are independently stated;
2. the connecting operation is constructed;
3. the preserved structure is demonstrated;
4. the physical carrier supplies its own units and equations;
5. an observable receipt is specified;
6. an outside record is compared with the prediction;
7. uncertainty and information loss are retained.

Failure at any field does not refute either jurisdiction. It prevents the proposed transport.

---

## 2. Status vocabulary

Every material statement receives one status.

| Status | Meaning |
|---|---|
| **DECLARED** | selected as jurisdiction, convention, carrier, condition, or coordinate |
| **DERIVED** | follows from stated premises by a displayed operation |
| **MEASURED** | supplied by an empirical record with a stated protocol |
| **CONDITIONAL** | valid only when named additional conditions hold |
| **OPEN** | not yet supplied or decided |
| **REFUSED** | incompatible with a stated type, equation, or receipt |
| **NOT USED** | available elsewhere but unnecessary in this construction |

“Compatible,” “suggestive,” and “analogous” are not substitutes for these statuses.

---

## 3. Certificate fields

### A. Jurisdiction

State:

- the formal theory or root office;
- the physical theory;
- the physical regime;
- the permitted approximations;
- the excluded regimes;
- the status of every imported result.

The jurisdiction must be definable before the preferred correspondence is named.

### B. Formal carrier

Record:

- object and type;
- state space;
- allowed operations;
- invariants;
- symmetry action;
- internal receipt.

An algebraically eligible object is not yet a physical carrier.

### C. Physical carrier

Record:

- system or apparatus;
- state variables;
- governing equations;
- material or geometric support;
- preparation;
- evolution or transport;
- readout.

The physical carrier must be stated in the native language of its field before translation.

### D. Adapter

Supply the six CORDIS fields:

| Field | Required question |
|---|---|
| Domain | What exact formal object enters? |
| Operation | What map, representation, embedding, limit, or calibration acts? |
| Codomain | What exact physical object results? |
| Invariant | What equation or structure is preserved? |
| Symmetry | Under what group action is the adapter equivariant? |
| Receipt | What common evaluation can be compared? |

The operation must be written. Naming an arrow is not constructing one.

### E. Conditions

Conditions state what must be present for the carrier to operate:

- coherence;
- preparation;
- boundary data;
- material phase;
- topology;
- scale separation;
- adiabaticity or pulse closure;
- detector access;
- environmental stability.

A missing condition may change the mechanism rather than merely weaken the result.

### F. Constraints

Constraints state what restricts lawful evolution or interpretation:

- admissible state subspace;
- conservation law;
- gauge condition or gauge-independent formulation;
- dimensional consistency;
- causality;
- positivity;
- normalization;
- error tolerance;
- excluded leakage channel;
- domain of an approximation.

Condition and Constraint are not interchangeable. A condition admits operation; a constraint bounds it.

### G. Units and normalization

Record:

- dimensions of every physical quantity;
- conversion constants;
- sign and orientation conventions;
- representation normalization;
- dimensionless exponent or action;
- numerical values only from stated sources.

No exponent, phase, action, or coupling is admitted while dimensionally untyped.

### H. Prediction

Display the quantity the physical theory predicts before comparison:

\[
\mathcal P
=
\mathcal P(
\text{prepared state},
\text{operation},
\text{conditions},
\text{constraints}
).
\]

The prediction must not be reconstructed from the observed answer.

### I. Observable

State:

- what the instrument reads;
- how raw data are converted;
- what calibration is applied;
- which gauge- or frame-dependent quantities are eliminated;
- what uncertainty is reported.

A formal invariant is not an observable until this field is closed.

### J. Outside receipt

Record:

- source or experiment;
- apparatus or dataset;
- date/version;
- measured quantity;
- uncertainty or fidelity;
- relevant controls;
- agreement or failure.

The outside receipt belongs to the physical occurrence. It is not generated by the adapter.

### K. Information-loss boundary

State what the receipt forgets.

Test whether a decoder \(D\) exists such that

\[
D\circ R=\operatorname{id}
\]

on the claimed domain.

If no such decoder is supplied, the receipt is not complete Memory of that domain. A trace, phase modulo \(2\pi\), endpoint state, or scalar score is ordinarily many-to-one.

### L. Failure alternatives

List the nearest rival explanations and the controls that distinguish them:

- leakage;
- local force;
- dynamical phase;
- decoherence;
- drift;
- basis artifact;
- post-selection;
- finite-size effect;
- numerical fitting freedom;
- unmodeled coupling.

An unexplored rival remains OPEN. It is not silently excluded.

---

## 4. Acceptance tests

A certificate passes only if all applicable tests pass.

### Type test

Every object has one stated office at each use.

### Equation test

The adapter preserves the displayed relation, not merely its appearance.

### Unit test

Every physical expression is dimensionally lawful.

### Symmetry test

Gauge, frame, coordinate, and basis changes have stated effects.

### Return test

Endpoint return, phase return, occurrence return, and remembered return are separated.

### Receipt test

The prediction and measurement meet in the same codomain.

### Loss test

What cannot be reconstructed from the receipt is explicitly named.

### Rival test

The closest alternative mechanisms are controlled, bounded, or left OPEN.

### Provenance test

Imported theory and empirical claims are sourced to primary or authoritative records.

### Scope test

No result receives authority beyond the certificate’s jurisdiction.

---

## 5. Minimum certificate form

The following block may be copied into any physical-instantiation note.

---

### Physical Adapter Certificate: [name]

**Jurisdiction:**  
[formal and physical domains]

**Formal carrier:**  
[typed object]

**Physical carrier:**  
[system/apparatus]

**Domain:**  
[adapter input]

**Operation:**  
[constructed map]

**Codomain:**  
[adapter output]

**Invariant:**  
[preserved equation or structure]

**Symmetry:**  
[group action and covariance]

**Receipt:**  
[common comparison quantity]

**Conditions:**  
[required presences]

**Constraints:**  
[lawful bounds]

**Units and normalization:**  
[dimensional record]

**Prediction:**  
[pre-observation calculation]

**Observable:**  
[instrumental read]

**Outside receipt:**  
[primary empirical record]

**Uncertainty/fidelity:**  
[reported bound]

**Information loss:**  
[what the receipt forgets]

**Rival mechanisms:**  
[controls and open alternatives]

**Statuses:**  
[DECLARED / DERIVED / MEASURED / CONDITIONAL / OPEN / REFUSED / NOT USED]

**Scope wall:**  
[what does not follow]

---

## 6. Proven applications

### Electromagnetic holonomy carrier

The certificate has been instantiated for the magnetic Aharonov–Bohm configuration:

\[
\Omega
\xrightarrow{\ \chi\ }
-\mathbf i,
\qquad
U_C
=
\exp\!\left(
\frac{\mathbf i q\Phi_B}{\hbar}
\right),
\]

with interference displacement as the outside receipt.

This application established:

- exact representation transport;
- physical units;
- gauge-invariant loop comparison;
- a measured phase receipt;
- the distinction between local zero curvature and global holonomy;
- explicit phase-memory information loss.

### Non-Abelian holonomy carrier

The next application must preserve the same certificate fields without relaxation. Its irreducible physical receipt is:

\[
U_2U_1\neq U_1U_2,
\]

measured by full process or state tomography.

No additional authority is granted merely because the codomain is non-Abelian.

---

## 7. Closure rule

A successful certificate proves:

> This formal object and this physical object are connected by this operation, preserving this structure, under these conditions, to the resolution of this receipt.

It does not prove:

> The formal and physical objects are identical, share an origin, or transport every property between them.

The first statement is an adapter. The second is a category error unless separately certified.

---

## Status note

This certificate is DECLARED as the corpus-wide physical-adapter protocol. Its individual applications are DERIVED, MEASURED, CONDITIONAL, OPEN, or REFUSED field by field.

The method is now fixed strongly enough to test new carriers without rebuilding the rules during the comparison.
