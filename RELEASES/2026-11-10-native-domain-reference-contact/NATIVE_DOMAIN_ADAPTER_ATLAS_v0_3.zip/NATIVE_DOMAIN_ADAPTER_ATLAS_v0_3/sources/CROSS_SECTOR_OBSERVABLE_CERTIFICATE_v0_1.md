# CROSS-SECTOR OBSERVABLE CERTIFICATE

## Minimum protocol from lawful occurrence to inferred quantity

**Version 0.1 — 20 August 2026**

---

## Status and purpose

This certificate states the minimum record required to carry one physical occurrence across several theoretical offices, through an apparatus, into a retained dataset, and onward to an inferred quantity.

It is extracted from the completed neutron beta-decay traversal and checked against the magnetic Aharonov–Bohm carrier. It is therefore neither a speculative universal mechanism nor a neutron-specific summary.

Its governing line is

\[
\boxed{
\text{sector laws}
\longrightarrow
\text{theory-native prediction}
\longrightarrow
\text{apparatus response}
\longrightarrow
\text{record law}
\longrightarrow
\text{inference}
\longrightarrow
\text{comparison receipt}
}.
\]

The certificate is **DECLARED** as a corpus-wide protocol. Every application must earn its own **DERIVED**, **MEASURED**, **CONDITIONAL**, **OPEN**, or **REFUSED** statuses field by field.

The central correction is:

> One occurrence may require several theories without becoming one mechanism. One parameter may admit several recognition maps without those maps becoming one measurement.

---

## 1. Relation to the Physical Adapter Certificate

The *Physical Adapter Certificate* and the present certificate have different offices.

The Physical Adapter Certificate audits one proposed crossing:

\[
\text{formal carrier}
\xrightarrow{\text{typed adapter}}
\text{physical carrier}.
\]

The Cross-Sector Observable Certificate audits a composite measured traversal:

\[
\text{prepared physical system}
\rightsquigarrow
\text{native state or occurrence}
\rightsquigarrow
\text{instrument record}
\longrightarrow
\text{inferred result}.
\]

Every formal-to-physical joint inside the composite still requires the earlier certificate. The present certificate does not replace those local proofs. It asks whether the certified joints actually compose into the record being interpreted.

The distinction is exact:

| Certificate | Unit of audit | Closes when |
|---|---|---|
| Physical Adapter Certificate | one cross-jurisdiction arrow | a constructed map preserves the stated structure and reaches a physical receipt |
| Cross-Sector Observable Certificate | one complete prediction-to-inference traversal | every sector joint, response, correction, record, and estimator composes in one declared forward model |

A locally correct arrow does not prove the whole path. A complete measured path cannot excuse an untyped local arrow.

---

## 2. Three layers that must not collapse

Every application separates three layers.

### 2.1 Model layer

The model layer contains the laws, state spaces, parameters, approximations, and sector adapters used to assign probabilities or lawful outcomes.

It answers:

> Under the stated theory and preparation, what occurrences are admitted, with what distribution or deterministic rule?

### 2.2 Occurrence layer

The occurrence layer contains the physical event, trajectory, field configuration, survival interval, or other history that actually unfolds.

It is not created by the notation used to model it and is not exhausted by the record later retained from it.

It answers:

> What happened in the physical jurisdiction, whether or not every part was observed?

### 2.3 Recognition layer

The recognition layer contains apparatus transport, amplification, filtering, digitization, classification, stored records, and statistical inference.

It answers:

> Which bounded trace of the occurrence entered a record, and what claim can that record support?

The three layers meet through adapters. They are not three names for one object.

---

## 3. The observable normal form

Let

- \(X\) be the preparation-and-setting space;
- \(\mathsf S\) be the native intermediate carrier predicted by the theory;
- \(D\) be a measurable retained-record space, which may contain one record, a variable-length sequence, a marked point pattern, or a complete run dataset;
- \(\Theta\) be the target-parameter space;
- \(H\) be the nuisance, calibration, and environmental parameter space.

The theory and the apparatus must compose into a record probability law

\[
P_{\theta,\eta}(\,\cdot\mid x)\in\mathsf P(D).
\]

The intermediate carrier \(\mathsf S\) remains native to the physical theory. It is not presumed to be a classical hidden-occurrence space.

### 3.1 Classical stochastic realization

When the theory supplies a measurable occurrence space \(O\), let

\[
K_\theta:X\rightsquigarrow O
\]

be the occurrence kernel and

\[
R_\eta:O\rightsquigarrow D
\]

the apparatus-response kernel. Their composition gives

\[
\boxed{
P_{\theta,\eta}(B\mid x)
=
\int_O
R_\eta(B\mid o)\,
K_\theta(do\mid x)
}
\]

for measurable \(B\subseteq D\).

For fixed \(x\), \(K_\theta(\,\cdot\mid x)\) is a probability measure on admitted occurrences. For fixed measurable \(A\subseteq O\), the function \(x\mapsto K_\theta(A\mid x)\) is measurable. Deterministic maps are included as kernels concentrated at one value.

### 3.2 Quantum operational realization

When \(\mathsf S\) is a quantum state carrier, the preparation and evolution supply a density operator

\[
\rho_\theta(x),
\]

while the admitted measurement supplies a positive-operator-valued measure \(E_\eta\) on \(D\). The record law is

\[
\boxed{
P_{\theta,\eta}(B\mid x)
=
\operatorname{Tr}
\!\left[
\rho_\theta(x)E_\eta(B)
\right]
}.
\]

If the post-measurement state matters, the apparatus is represented by a quantum instrument \(\mathcal J_{\eta,B}\), with

\[
P_{\theta,\eta}(B\mid x)
=
\operatorname{Tr}
\mathcal J_{\eta,B}
\!\left(\rho_\theta(x)\right).
\]

No underlying classical path outcome is inserted merely to make the notation resemble the classical case. Interference is retained until the physical instrument turns the quantum state into a distribution of records.

### 3.3 Record and inference

Detection failure is itself represented: either \(D\) contains an explicit no-record outcome or the response is stated with its exposure normalization. Inefficiency is not allowed to disappear from the codomain.

The minimum physical reading seam is therefore the factorization of a native theory-side prediction and a calibrated readout into the record law actually used for inference.

For a retained dataset \(d\in D\), an inference operation

\[
\mathcal I:
D\times\mathfrak M\times\mathfrak C
\longrightarrow
\widehat\Theta
\]

returns a declared inferential object: a point estimate, interval, likelihood surface, posterior, hypothesis decision, or some typed combination. Here \(\mathfrak M\) records the fitted model and \(\mathfrak C\) records calibration, covariance, and controls.

Independent sampling is not presumed. If runs or records are correlated, the dataset law on \(D\) must retain those correlations rather than silently replacing it by a product law.

The full normal form is therefore

\[
\boxed{
X
\xrightarrow{\ K_\theta\ }
\mathsf S
\xrightarrow{\ R_\eta\ }
\mathsf P(D)
\overset{P_{\theta,\eta}}{\rightsquigarrow}
D
\xrightarrow{\ \mathcal I\ }
\widehat\Theta
}.
\]

Here \(K_\theta\) and \(R_\eta\) denote theory-appropriate channels: deterministic maps, Markov kernels, quantum channels and instruments, or a typed composition of them. This is an audit form. Distinct mechanisms may occupy it without becoming physically identical.

---

## 4. The sector-joint certificate

The theory-side channel may depend on several native theoretical sectors. Write the model-side construction as

\[
\mathcal S_0
\xrightarrow{A_1}
\mathcal S_1
\xrightarrow{A_2}
\cdots
\xrightarrow{A_m}
\mathcal S_m
\xrightarrow{\Pi}
(K_\theta,\mathsf S).
\]

Each \(A_j\) must record:

1. its exact domain and codomain;
2. whether it is an embedding, quotient, representation, matching relation, limit, coarse-graining, or calibration;
3. its scale and units;
4. the invariant or covariance it preserves;
5. the lawful difference it introduces;
6. what it forgets;
7. its uncertainty or truncation order;
8. its source and status;
9. its nearest failure mode.

The composite

\[
A_{m:1}=A_m\circ\cdots\circ A_1
\]

is admitted only when every adjacent type matches and every scale or scheme change is carried forward.

### Sector-joint rule

> Sharing one occurrence licenses co-evaluation. It does not license interchange of generators, fields, couplings, conserved quantities, or mechanisms.

Examples include:

- a quark field carrying both color and weak representation data;
- a charged matter wave responding to an electromagnetic connection;
- a gravitational potential shaping an apparatus boundary without mediating the event under study.

The occurrence is the joint. The theories retain their own offices.

---

## 5. The apparatus certificate

The apparatus response channel or instrument \(R_\eta\) must be decomposed far enough to expose every operation that can change the interpretation of a record:

\[
R_\eta
=
R_{r}\circ\cdots\circ R_2\circ R_1.
\]

Typical stages include:

- physical transport;
- field-guided confinement;
- energy or signal gain;
- material interaction;
- transduction;
- amplification;
- digitization;
- triggering;
- thresholding;
- classification;
- timestamping;
- storage.

Each stage records its efficiency, resolution, acceptance, calibration, background, saturation boundary, dead time, and uncertainty where applicable.

### Apparatus-addition rule

An apparatus may add energy, momentum, charge carriers, photons, voltage gain, timing structure, or computational labels to make a trace readable. These additions do not become properties the original occurrence possessed at its formation.

The physical exchange with the apparatus belongs in the model. It is not a violation of conservation and not evidence that the apparatus created the antecedent event.

### Directness refusal

The sentence

> the detector directly sees the event

is admitted only as a declared compression. Its exact expansion is the response channel or instrument and its calibration record.

---

## 6. The traversal ledger

Every completed traversal carries four lists:

\[
\boxed{
\mathsf{TraversalLedger}
=
(\mathsf{Keep},\mathsf{Change},\mathsf{Add},\mathsf{Forget})
}.
\]

### Keep

Relations shown to survive the crossing: conserved charge, event identity under transport, gauge-invariant phase, ordering, timestamp relation, or another displayed invariant.

### Change

Lawful transformations: particle identity, state, basis, energy distribution, representation, scale, coordinate, material form, or statistical description.

### Add

Structure supplied by an environment or apparatus: gain energy, reference clock, calibration field, label, bin, prior, threshold, or reconstruction convention.

### Forget

Information not recoverable from the retained record: unobserved momenta, microscopic path, absolute phase, integer winding, rejected events, subthreshold signals, or overwritten raw data.

No receipt is called lossless Memory beyond the distinctions for which a decoder or identifiability proof is supplied.

---

## 7. Corrections and nuisance structure

A correction is not a decorative number applied after the physical account is complete. It belongs to a definite arrow in the forward model.

For each correction \(c_j\), record:

| Field | Required content |
|---|---|
| Location | theory-side channel, response channel or instrument, calibration, or inference |
| Mechanism | what physical or mathematical difference it represents |
| Parameter | value, units, convention, and uncertainty |
| Dependence | variables and correlations on which it depends |
| Source | calculation, calibration, control run, or external datum |
| Effect | shift, convolution, efficiency, covariance, or changed support |
| Failure | result if omitted, duplicated, or applied in the wrong scheme |

Corrections that share inputs carry covariance. Moving one contribution between theory, calibration, and fitted parameter requires an explicit reparameterization; otherwise the traversal double-counts or forgets it.

The complete parameter is

\[
(\theta,\eta,\xi),
\]

where \(\theta\) is the target, \(\eta\) belongs to the apparatus, and \(\xi\) collects theory-side nuisance and correction parameters. The partition is declared, not ontological: its purpose is to keep offices and covariance visible.

---

## 8. Inference and identifiability

An inference certificate states:

1. the exact estimand;
2. the likelihood, estimating equation, or decision rule;
3. the dataset admitted to it;
4. the nuisance parameters and priors, if any;
5. the covariance and correlation model;
6. the blinding and selection procedure;
7. the interval or uncertainty convention;
8. the goodness-of-fit and residual checks;
9. the identifiability boundary;
10. the retained code, configuration, and provenance needed for reproduction.

The result \(\widehat\theta\) is not the occurrence. It is a record-conditioned statement about a parameter in the declared forward model.

If distinct parameter values induce the same record law,

\[
P_{\theta_1,\eta_1}
=
P_{\theta_2,\eta_2},
\]

then the data alone cannot distinguish those parameter points. The correct result is a quotient, interval, degeneracy surface, or OPEN distinction—not a forced unique value.

---

## 9. Equality adapter for multiple recognition maps

Suppose two methods \(j=1,2\) report values that are described by the same word or symbol.

Let \(\Theta\) be the full common physical parameter space, let

\[
c_j:\Theta\to\Theta_j
\]

select the method-specific estimand, and let

\[
e_j:\Theta_j\to Z
\]

carry that estimand into a declared comparison space \(Z\).

The methods read the same comparison quantity only if there exists a common map \(\zeta:\Theta\to Z\) such that

\[
\boxed{
e_1\circ c_1
=
\zeta
=
e_2\circ c_2
}
\]

on the stated domain.

This is the equality adapter.

It must also retain:

- method-specific response channels, instruments, and record laws;
- method-specific nuisance parameters;
- shared and unshared systematics;
- branch or acceptance factors;
- correlations between the reported values;
- the model under which a joint discrepancy is calculated.

Raw record equality is neither required nor expected. The records may inhabit different spaces. What must agree is the target reached through the certified comparison maps.

### Disagreement rule

If the equality adapter closes but the inferred values disagree beyond their declared joint uncertainty, the result is a localized unresolved comparison. It does not by itself select among:

- an unmodeled apparatus response;
- an omitted physical branch;
- a correction or covariance error;
- a failed common model;
- an additional interaction.

Those are rival mechanisms to be separated by further receipts.

If the equality adapter does not close, averaging the values as estimates of one quantity is **REFUSED**.

---

## 10. Composite CORDIS record

The complete traversal receives one CORDIS record without erasing its internal arrows.

### Domain

Prepared physical systems, environmental state, admitted event class, and model jurisdiction.

### Operation

The composed theory-side channel, apparatus response, correction stack, record law, and inference rule.

### Codomain

A typed inferential result with its uncertainty, covariance, and status.

### Invariant

The exact relation demonstrated to survive from occurrence model through the record and estimator.

### Symmetry

The physical, gauge, frame, permutation, or apparatus symmetries used in the forward model or cancellation scheme.

### Receipt

The retained raw and processed records, calibration state, model/version record, source ledger, and reproducible inference output.

The composite record does not replace the CORDIS record of any internal adapter. It indexes them.

---

## 11. Acceptance tests

A Cross-Sector Observable Certificate passes only when every applicable test passes.

### Native-office test

Every theory, field, operator, state, parameter, and apparatus component is first stated in its own field language.

### Joint test

Every sector interface is constructed, and the composite is well typed.

### Occurrence test

The native intermediate carrier is distinguished from the physical occurrence and the observed trace; no classical latent variable is added without warrant.

### Forward-model test

The theory-side prediction and apparatus response induce the record distribution actually used in the fit.

### Apparatus-addition test

Energy, gain, labels, or timing supplied by the apparatus are not read backward into the originating event.

### Unit and normalization test

Every physical quantity, exponent, probability law, rate, and efficiency is dimensionally and probabilistically normalized.

### Correction test

Each correction has one location, one convention, one uncertainty, and no undeclared duplication.

### Inference test

The estimator targets the stated quantity, retains covariance, and reports its identifiability boundary.

### Equality test

Methods claimed to measure the same quantity commute into one comparison space through displayed maps.

### Traversal-ledger test

What is kept, changed, added, and forgotten is explicitly recorded.

### Rival test

The nearest alternative mechanisms are controlled, bounded, or left OPEN.

### Provenance test

Every imported law, number, calibration, and empirical statement terminates in an internal derivation or an exact outside source.

### Scope test

The final claim does not exceed the support of the forward model and retained receipt.

---

## 12. Minimum reusable form

### Cross-Sector Observable Certificate: [name]

**Jurisdiction:**  
[physical regime, model regime, approximations, exclusions]

**Prepared domain \(X\):**  
[state or ensemble]

**Sector chain:**  
[native carriers and constructed adapters]

**Target parameters \(\Theta\):**  
[quantities sought]

**Native intermediate carrier \(\mathsf S\):**  
[classical occurrence space, state space, quantum state carrier, or other native type]

**Theory-side channel \(K_\theta\):**  
[deterministic rule, stochastic kernel, state evolution, or typed composite]

**Apparatus response \(R_\eta\):**  
[classical response kernel or quantum instrument, followed by transport, gain, detection, and classification as applicable]

**Record space \(D\):**  
[raw and processed record types]

**Record law \(P_{\theta,\eta}\):**  
[composed forward model]

**Correction stack:**  
[location, convention, covariance, sources]

**Inference \(\mathcal I\):**  
[estimand, likelihood/estimator, uncertainty]

**Equality adapter:**  
[method-specific targets and common comparison space, if applicable]

**Keep:**  
[preserved relations]

**Change:**  
[lawful transformations]

**Add:**  
[apparatus/environment/inference contributions]

**Forget:**  
[unrecoverable distinctions]

**Observable:**  
[calibrated instrument-space read]

**Outside receipts:**  
[data, apparatus, date/version, sources]

**Rivals and falsifiers:**  
[nearest alternatives and discriminating tests]

**Statuses:**  
[DECLARED / DERIVED / MEASURED / CONDITIONAL / OPEN / REFUSED / NOT USED]

**Scope wall:**  
[what does not follow]

---

## 13. Back-test: neutron beta decay

The neutron receipt occupies the normal form as follows.

| Field | Neutron-decay realization |
|---|---|
| prepared domain \(X\) | free-neutron ensemble with phase-space, polarization, exposure, and boundary data |
| sector chain | electroweak charged current \(\to\) low-energy four-fermion operator \(\to\) QCD nucleon matrix element \(\to\) amplitude and phase space |
| occurrence space \(O\) | survival intervals and admitted \(p+e^-+\bar\nu_e\) final states |
| occurrence law \(K_\theta\) | exponential survival plus differential beta-decay distribution with matched corrections |
| response \(R_\eta\) | bottle survivor recognition or beam product transport and detection |
| record space \(D\) | hold-time survivor counts, or time-tagged product and neutron-exposure records |
| inference | \(\widehat\tau_n\), \(\widehat\lambda\), and \(\widehat V_{ud}\) under stated models |
| Keep | charge, color-singlet structure, four-momentum at the event, event identity under calibrated transport |
| Change | neutron identity, flavor content, final energy distribution, instrument representation |
| Add | trap fields, detector acceleration energy, amplification, timestamps, bins, fit conventions |
| Forget | most microscopic history, often the antineutrino momentum, rejected/subthreshold events, unrecorded apparatus state |

The two lifetime methods expose the equality adapter.

Bottle survival targets

\[
\Gamma_{\mathrm{tot}},
\]

after nondecay losses are removed. Proton-counting beam recognition targets

\[
\Gamma_p=B_p\Gamma_{\mathrm{tot}}.
\]

In lifetime coordinates,

\[
\tau_p=\frac{\tau_{\mathrm{tot}}}{B_p},
\qquad
\tau_{\mathrm{tot}}=B_p\tau_p.
\]

Taking the beam estimand space to include \((\tau_p,B_p)\), its comparison map is

\[
e_p(\tau_p,B_p)=B_p\tau_p,
\]

while the corrected bottle map is the identity on \(\tau_{\mathrm{tot}}\). Thus the methods enter one comparison space only after \(B_p\), bottle-loss, fluence, efficiency, background, and covariance adapters are supplied.

The back-test passes. It also proves that a complete cross-sector receipt can close without assigning a physical office to root \(Q^2\).

---

## 14. Portability test: magnetic Aharonov–Bohm interference

The independently completed electromagnetic holonomy carrier occupies the same normal form through a different mechanism.

| Field | Aharonov–Bohm realization |
|---|---|
| prepared domain \(X\) | coherent charged matter wave, path pair, excluded flux region, detector frame |
| sector chain | electromagnetic \(U(1)\) connection \(\to\) charged-wave phase transport \(\to\) interference law |
| native carrier \(\mathsf S\) | coherent charged-matter-wave state on the admitted path pair; no classical which-path outcome is inserted |
| theory-side channel \(K_\theta\) | quantum evolution with \(\Delta\varphi=q\Phi_B/\hbar\pmod{2\pi}\), retaining coherent amplitudes through recombination |
| response \(R_\eta\) | quantum detection instrument plus electron optics, detector efficiency, gain, and spatial binning |
| record space \(D\) | electron-count pattern or holographic fringe record |
| inference | relative phase or fringe displacement with uncertainty |
| Keep | gauge-invariant closed-loop phase relation and orientation-sensitive displacement |
| Change | matter-wave propagation into localized detector events and accumulated counts |
| Add | reference frame, detector gain, spatial bins, calibration and fit model |
| Forget | complete path and flux history, absolute phase, integer-period distinctions without external records |

The phase receipt is periodic. It retains a quotient of traversal but does not decode complete historical occurrence. The quantum instrument expresses the passage from coherent amplitude to a distribution of counted detector events without assigning an unmeasured classical path.

The portability test passes. The same observable normal form carries both examples while their physical mechanisms remain distinct.

---

## 15. Root and crown verdict

The certificate supplies the missing operational joint between the root-to-crown trunk and an empirical result:

\[
\begin{aligned}
\text{addressed reference}
&\longrightarrow
\text{typed difference}
\longrightarrow
\text{lawful transport}
\longrightarrow
\text{return class}
\longrightarrow
\text{retained occurrence}
\longrightarrow
\text{recognized use}
\end{aligned}
\]

becomes physical only after the central passage is expanded to

\[
X
\xrightarrow{K_\theta}
\mathsf S
\xrightarrow{R_\eta}
\mathsf P(D)
\longrightarrow
\mathcal I.
\]

The root supplies an audit grammar and, in selected cases, a certified formal carrier. The physical theory supplies its native state space, dynamics, units, coupling, and occurrence law. The apparatus supplies a bounded material read. The inference supplies a warranted statement at the record’s resolution.

No root operator is required merely because an observable traversal closes. In particular:

- \(Q\) is **NOT GENERICALLY REQUIRED**;
- \(Q^2\) is **NOT GENERICALLY REQUIRED**;
- \(\Omega\) enters the Aharonov–Bohm carrier only through its certified representation adapter;
- the neutron traversal closes without a root-matrix office;
- a future physical carrier may admit \(Q^2\) only through its own native mechanism and certificate.

This keeps the read flexible while making the recognition standard exact.

---

## 16. What closes

The following claims close:

1. A full physical observable is a composite traversal, not a primitive identity between theory and detector value.
2. The appropriate minimum form is a theory-native prediction composed with an apparatus response into a record law: Markov kernels in the classical stochastic case, and a state plus instrument or POVM in the quantum case.
3. Native theoretical sectors may co-evaluate one occurrence without becoming one mechanism.
4. Every correction belongs to a specific arrow in the forward model.
5. The apparatus may add readable gain without donating that gain backward to the originating event.
6. A retained record is a bounded physical trace whose decoder authority must be stated.
7. Inference returns a model-conditioned claim, not the occurrence itself.
8. Two methods measure one comparison quantity only through a commuting equality adapter.
9. A method-dependent discrepancy can be held without erasure or premature causal selection.
10. The neutron and Aharonov–Bohm traversals occupy one audit form while remaining different mechanisms.
11. Root \(Q^2\) is not forced by observable closure.

---

## 17. What remains open

The certificate does not determine:

- which physical occurrence first supplies a native office for \(Q^2\);
- whether any such office exists;
- the cause of the neutron-lifetime discrepancy;
- a universal ontology of measurement;
- a unique statistical philosophy;
- the internal mechanism of every detector;
- a complete decoder for records designed to be lossy;
- a common physical mechanism behind all systems occupying the normal form;
- any empirical constant, particle content, interaction strength, or apparatus response from the root alone.

These remain visible without loading the certificate beyond its office.

---

## 18. Source ledger

### External formal sources

1. E. B. Davies and J. T. Lewis, “An Operational Approach to Quantum Probability,” *Communications in Mathematical Physics* **17** (1970), 239–260. <https://doi.org/10.1007/BF01647093>
2. Karl Kraus, “General State Changes in Quantum Theory,” *Annals of Physics* **64** (1971), 311–335. <https://doi.org/10.1016/0003-4916(71)90108-4>

### Internal dependencies

1. *Everything: The Minimum Classical Closure*, v0.9 — jurisdiction, addressed cut, CORDIS, return/Memory/Recognition distinctions, physical expansion rule.
2. *Root to Crown: Global Scope Inventory and Formal Closure Map*, v0.1 — selected trunk, graft receipt, edge audit, star-pattern tightening.
3. *Physical Adapter Certificate*, v0.1 — local cross-jurisdiction adapter fields and acceptance tests.
4. *The Standard Model Trunk*, v0.1 — native sector offices, Standard Model joints, gravity boundary, source architecture.
5. *The Neutron Beta-Decay Cross-Sector Receipt*, v0.1 — concrete multi-sector traversal and equality adapter.
6. *The Electromagnetic Holonomy Carrier*, v0.1 — independent phase-to-interference portability test.

### Source-to-claim map

| Claim | Principal source |
|---|---|
| audit order is not an origin story | *Everything* v0.9 |
| formal/physical resemblance requires a certified adapter | *Physical Adapter Certificate* v0.1 |
| every graft states preserved and forgotten difference | *Root to Crown* v0.1 |
| distinct Standard Model sectors share matter carriers without algebraic collapse | *The Standard Model Trunk* v0.1 |
| complete theory-to-detector traversal and lifetime equality adapter | *Neutron Beta-Decay Cross-Sector Receipt* v0.1 |
| phase-to-interference traversal and periodic information-loss boundary | *Electromagnetic Holonomy Carrier* v0.1 |
| operational quantum instrument and state-change formalism | Davies--Lewis; Kraus |
| classical-kernel/quantum-instrument branching, traversal ledger, and composite acceptance tests | present construction |

The external theory and experimental claims used in the two applications remain sourced in their respective carrier and receipt ledgers. They are not duplicated here as though this protocol had independently generated them.

---

## Status note

The corpus now has both scales of physical audit.

The Physical Adapter Certificate controls one crossing. The Cross-Sector Observable Certificate controls the entire measured line. Between them, a shared symbol cannot skip a mechanism, a detector cannot masquerade as direct access, and two methods cannot become one measurement merely because they print the same unit.

The key addition is the record-law factorization:

\[
P_{\theta,\eta}
=
R_\eta\circ K_\theta,
\]

where the composition is interpreted in the native category: classical stochastic channel, quantum instrument, or a certified typed combination. It gives the mirror a thickness. What reaches the page is materially related to what happened, but it is not the occurrence flattened without loss. The record has a physical carriage, an uncertainty surface, and a lawful boundary.

The path from theory to recognition is now explicit enough to be reused without pretending that reuse makes the paths the same.
