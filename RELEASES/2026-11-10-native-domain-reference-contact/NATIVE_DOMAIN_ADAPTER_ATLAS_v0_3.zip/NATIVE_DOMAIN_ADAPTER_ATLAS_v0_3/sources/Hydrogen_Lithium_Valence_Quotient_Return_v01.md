# Hydrogen–Lithium Valence Quotient Return

**Draft 0.1 · 19 July 2026 · elementary-structure branch**  
**Status:** first fired recurrence instrument; open outward diagnostic, no
sealed-core revision.

> A pattern may return exactly in its declared quotient while every physical
> coordinate that made the return possible remains different and readable.

## 0. Jurisdiction and result

This note constructs the operator left open by the Hydrogen–Helium seam,

\[
r_{\mathrm{PT}}^{\mathcal R}
=
r_{\mathrm{val}}^{\mathrm{fib},\mathcal R}
\circ s_{\mathrm{PT}}^{\mathcal R},
\]

constructs an evidence-bearing pattern quotient

\[
q_{\mathrm{pattern}}^{\mathcal P},
\]

and evaluates it on the first three periodic reference points:

\[
H\longrightarrow He\longrightarrow Li.
\]

At the declared configuration-label resolution,

\[
\boxed{
q_{\mathrm{pattern}}^{\mathcal P}
r_{\mathrm{PT}}^{\mathcal R}(1)
=
q_{\mathrm{pattern}}^{\mathcal P}
r_{\mathrm{PT}}^{\mathcal R}(3)
=
\mathsf P_{s^1}
}
\]

while

\[
r_{\mathrm{PT}}^{\mathcal R}(1)
\neq
r_{\mathrm{PT}}^{\mathcal R}(3).
\]

Here

\[
\mathsf O_s
=
(\ell_{\mathrm{fr}}=0,\,
N_{\mathrm{fr}}=1,\,
\operatorname{cap}_s=2,\,
\mathsf{FrontierOpen}),
\]

the single-electron frontier-\(s\) occupation pattern. With independent
spectral witnesses, define the refined pattern

\[
\mathsf P_{s^1}
=
\left(
\mathsf O_s,\,
J_{\mathrm{ang}}^{\pi_{\mathrm{el}}}=\frac12^+,\,
\lambda_{LS}^{\mathrm{EvaluatedLabel}}={}^2S_{1/2}
\right).
\]

This is the first admitted **quotient-return witness** in the elementary
branch. It is not a claim that Hydrogen and Lithium are the same atom, that
their Hamiltonians are equivalent, or that the global periodic structure is
already a wheel or spiral.

## 1. Shared resolution and external calibration

The comparison uses one resolution on both sides:

\[
\mathcal R_{\mathrm{cfg}}
=
(\mathsf{Neutral},
\mathsf{Isolated},
\mathsf{FieldFree},
\mathsf{GroundElectronicSector},
\mathsf{EvaluatedConfigurationLabel},
\mathsf{FineStructure},
\mathsf{HyperfineOff}).
\]

The canonical witnesses are

\[
\begin{aligned}
b_1&:=s_{\mathrm{PT}}^{\mathcal R_{\mathrm{cfg}}}
(1;{}^{1}\!H),\\
b_2&:=s_{\mathrm{PT}}^{\mathcal R_{\mathrm{cfg}}}
(2;{}^{4}\!He),\\
b_3&:=s_{\mathrm{PT}}^{\mathcal R_{\mathrm{cfg}}}
(3;{}^{7}\!Li).
\end{aligned}
\]

The isotope choices are retained witnesses, not definitions of the elements.
\({}^{7}\!Li\) is chosen explicitly as the dominant natural Lithium isotope.

The evaluated reference data are:

| \(Z\) | Witness | Evaluated ground configuration | Ground term | \(\pi_{\mathrm{el}}\) | \(I_{\mathrm{nuc}}^{\pi_{\mathrm{nuc}}}\) | Ionization energy |
|--:|:--|:--|:--|:--:|:--:|--:|
| 1 | \({}^{1}\!H\) | \(1s^1\) | \({}^2S_{1/2}\) | \(+1\) | \(\tfrac12^+\) | \(13.598433\ \mathrm{eV}\) |
| 2 | \({}^{4}\!He\) | \(1s^2\) | \({}^1S_0\) | \(+1\) | \(0^+\) | \(24.587387\ \mathrm{eV}\) |
| 3 | \({}^{7}\!Li\) | \(1s^2\,2s^1\) | \({}^2S_{1/2}\) | \(+1\) | \(\tfrac32^-\) | \(5.391719\ \mathrm{eV}\) |

The electronic configurations, terms, isotope spins, and ionization energies
come from
[NIST Hydrogen](https://www.physics.nist.gov/PhysRefData/Handbook/Tables/hydrogentable1_a.htm),
[NIST Helium](https://www.physics.nist.gov/PhysRefData/Handbook/Tables/heliumtable1_a.htm),
and
[NIST Lithium](https://www.physics.nist.gov/PhysRefData/Handbook/Tables/lithiumtable1_a.htm).
Nuclear spin-parity is independently typed by the
[NNDC Nuclear Wallet Cards](https://www.nndc.bnl.gov/walletcardsarchivals/).

The configuration label is evaluated physical evidence. It is not a claim
that an interacting many-electron state is exactly one Slater determinant.
At a correlated-wavefunction resolution,

\[
|\Psi_g\rangle
=
\sum_a c_a
|\Gamma_a;J_{\mathrm{ang}}^{\pi_{\mathrm{el}}}\rangle,
\]

and the configuration reader must return its support and coefficients,
\(\mathsf{Mixed}\), or \(\mathsf{Unknown}\) as the evidence warrants.

Hyperfine structure cannot be smuggled through the same comparison. Were it
restored,

\[
F_H\in\{0,1\},
\qquad
F_{{}^{7}Li}\in\{1,2\}
\]

is deliberately outside the descriptor resolution, not a field erased by the
quotient. A hyperfine-resolved recurrence would require a new domain policy
and does not follow from the result below.

## 2. The evidence-bearing valence reader

Let \(\mathsf{GroundPkg}^{\mathcal R}\) contain the admitted ground spectral
projector and its \(\mathsf{HamiltonianFiberPkg}\). The partial extractor is

\[
r_{\mathrm{val}}^{\mathrm{fib},\mathcal R}:
\mathsf{GroundPkg}^{\mathcal R}
\longrightarrow
\mathsf{ValPkg}^{\mathcal R}
\sqcup
\mathsf{Mixed}
\sqcup
\mathsf{Unknown}.
\]

When the extraction is admitted,

\[
\begin{aligned}
\mathsf{ValPkg}^{\mathcal R}(b)
=(&Z,\nu,N_e,\Gamma_{\mathrm{core}},
\epsilon_{\mathrm{core}},
n_{\mathrm{fr}},\ell_{\mathrm{fr}},N_{\mathrm{fr}},
\operatorname{cap}_{\ell},\\
&\Gamma_{\mathrm{support}},
J_{\mathrm{ang}},\pi_{\mathrm{el}},
\lambda_{LS},
H_b,P_{0,b},E_{\mathrm{ion}},
\mathsf{Evidence}).
\end{aligned}
\]

The fields mean:

- \(\Gamma_{\mathrm{core}}\): the retained core configuration; the empty core
  is the unit object, while \(1s^2\) requires its own closed-core witness;
- \((n_{\mathrm{fr}},\ell_{\mathrm{fr}},N_{\mathrm{fr}})\): the declared
  frontier-subshell label and occupation;
- \(\operatorname{cap}_{\ell}=2(2\ell+1)\): nonrelativistic subshell capacity
  including spin;
- \(\Gamma_{\mathrm{support}}\): exact, dominant, or mixed configuration
  support rather than an assumed factorization;
- \((J_{\mathrm{ang}},\pi_{\mathrm{el}})\): spectral symmetry labels admitted
  by \(\mathsf{GoodLabelPkg}\);
- \(\lambda_{LS}\): an evaluated \(LS\)-term label, retained with its coupling
  regime rather than promoted automatically to an exact universal label.

For the three reference points:

\[
\begin{aligned}
v_1
&=
(\Gamma_{\mathrm{core}}=\mathbf 1,\,
n_{\mathrm{fr}}=1,\ell_{\mathrm{fr}}=0,N_{\mathrm{fr}}=1,\,
{}^2S_{1/2},\pi_{\mathrm{el}}=+),\\
v_2
&=
(\Gamma_{\mathrm{core}}=\mathbf 1,\,
n_{\mathrm{fr}}=1,\ell_{\mathrm{fr}}=0,N_{\mathrm{fr}}=2,\,
{}^1S_0,\pi_{\mathrm{el}}=+),\\
v_3
&=
(\Gamma_{\mathrm{core}}=1s^2,\,
n_{\mathrm{fr}}=2,\ell_{\mathrm{fr}}=0,N_{\mathrm{fr}}=1,\,
{}^2S_{1/2},\pi_{\mathrm{el}}=+).
\end{aligned}
\]

The exactness boundary is:

\[
\boxed{
\text{the quotient is exact on admitted descriptors;}
\quad
\text{extracting a descriptor from a physical state is evidence-dependent.}
}
\]

## 3. Constructing \(q_{\mathrm{pattern}}\)

A pattern quotient is never bare. Each layer carries a policy

\[
\mathcal P
=
(\mathsf{DomainGate},
\mathsf{Keep},
\mathsf{Forget},
\mathsf{Purpose},
\mathsf{EvidenceContract}).
\]

The minimal recurrence test uses the occupation policy

\[
\mathcal P_{\mathrm{occ}}
=
(\mathsf{DomainGate}_{\mathrm{cfg}},
\mathsf{Keep}_{\mathrm{occ}},
\mathsf{Forget}_{\mathrm{lift}},
\mathsf{PatternReturn},
\mathsf{EvidenceContract}_{\mathrm{cfg}}).
\]

Its kept fields are

\[
\mathsf{Keep}_{\mathrm{occ}}
=
(\ell_{\mathrm{fr}},
N_{\mathrm{fr}},
\operatorname{cap}_{\ell},
\mathsf{FrontierOpen/Saturated}),
\]

while

\[
\begin{aligned}
\mathsf{Forget}_{\mathrm{lift}}
=(&Z,\nu,I_{\mathrm{nuc}}^{\pi_{\mathrm{nuc}}},
N_e,\Gamma_{\mathrm{core}},n_{\mathrm{fr}},
\Gamma_{\mathrm{support}},\\
&H_b,P_{0,b},E_{\mathrm{ion}},
\text{radial scale and density},
\mathcal R_{\mathrm{cfg}}\text{ receipt}).
\end{aligned}
\]

Neutrality, isolation, field freedom, ground-sector selection, and common
resolution are **domain gates**. They are not fields the quotient is permitted
to forget.

### 3.1 Occupation projection

The minimal projection is

\[
q_{\mathrm{occ}}^{\mathcal P}(v)
=
(\ell_{\mathrm{fr}},
N_{\mathrm{fr}},
\operatorname{cap}_{\ell},
\mathsf{FrontierOpen/Saturated}).
\]

It induces the explicit equivalence relation

\[
v\sim_{\mathrm{occ}}w
\quad\Longleftrightarrow\quad
q_{\mathrm{occ}}^{\mathcal P}(v)
=
q_{\mathrm{occ}}^{\mathcal P}(w).
\]

Write

\[
\mathsf O_s=(0,1,2,\mathsf{FrontierOpen}),
\qquad
\mathsf C_s=(0,2,2,\mathsf{FrontierSaturated})
\]

for the two patterns used by the first three elements. Then

\[
q_{\mathrm{occ}}(v_1)=\mathsf O_s,
\qquad
q_{\mathrm{occ}}(v_2)=\mathsf C_s,
\qquad
q_{\mathrm{occ}}(v_3)=\mathsf O_s.
\]

For Helium, a separate shell-context witness upgrades
\(\mathsf{FrontierSaturated}\) to \(\mathsf{ShellSaturated}\), because the
\(n=1\) shell contains no further subshell. The tuple
\((\ell,N,\operatorname{cap})\) alone is too coarse to call a later \(ns^2\)
atom globally shell-closed; future block and shell-context policies remain
separate.

### 3.2 Spectral refinement

With independent Hamiltonian and spectral witnesses,

\[
q_{\mathrm{spec}}(v)
=
(J_{\mathrm{ang}},\pi_{\mathrm{el}}).
\]

Thus

\[
q_{\mathrm{spec}}(v_1)
=
q_{\mathrm{spec}}(v_3)
=
\left(\frac12,+1\right),
\qquad
q_{\mathrm{spec}}(v_2)=(0,+1).
\]

The evaluated \(LS\) typography may be appended as a tagged label:

\[
\lambda_{LS}(v_1)=\lambda_{LS}(v_3)={}^2S_{1/2},
\]

but it does not silently replace the stronger operator/spectral evidence.

The refined pattern reader is a layered package, not a retroactive expansion
of \(\mathcal P_{\mathrm{occ}}\):

\[
q_{\mathrm{pattern}}
=
\left(
q_{\mathrm{occ}}^{\mathcal P_{\mathrm{occ}}},
q_{\mathrm{spec}}^{\mathcal P_{\mathrm{spec}}},
\lambda_{LS}^{\mathcal P_{LS},\mathrm{EvaluatedLabel}}
\right).
\]

Here \(\mathcal P_{\mathrm{spec}}\) keeps
\((J_{\mathrm{ang}},\pi_{\mathrm{el}})\) only with the required operator and
spectral witnesses, while \(\mathcal P_{LS}\) keeps the evaluated term label
and its coupling-regime tag. The graph below deliberately uses the minimal
occupation projection \(q_{\mathrm{occ}}\); the endpoint theorem also checks
the two independently admitted refinements.

## 4. Lossless quotient recognition

The quotient view alone forgets. The architectural operator does not:

\[
\widehat q_{\mathcal P}(v)
=
\bigl(
q_{\mathcal P}(v),
F_{\mathcal P}(v),
\eta_{\mathrm{split}}
\bigr),
\]

where \(F_{\mathcal P}(v)\) retains the fields declared in
\(\mathsf{Forget}_{\mathrm{lift}}\), and

\[
\operatorname{merge}
\bigl(q_{\mathcal P}(v),F_{\mathcal P}(v)\bigr)
=v
\]

is the structural recovery witness.

For Hydrogen and Lithium, the return receipt is

\[
\begin{aligned}
R_{H,Li}
=(&v_1,v_3,\mathsf P_{s^1},
\eta_{\mathrm{pattern}},
\Delta_{\mathrm{lift}}),\\
\Delta_{\mathrm{lift}}
=(&Z:1\to3,\,
N_e:1\to3,\,
n_{\mathrm{fr}}:1\to2,\,
\Gamma_{\mathrm{core}}:\mathbf1\to1s^2,\\
&I_{\mathrm{nuc}}^{\pi_{\mathrm{nuc}}}:
\tfrac12^+\to\tfrac32^-,\,
H_H\neq H_{Li},\,
P_{0,H}\neq P_{0,Li},\\
&E_{\mathrm{ion}}:
13.598433\to5.391719\ \mathrm{eV},\,
\text{distinct spectra and radial densities}).
\end{aligned}
\]

\(\Delta_{\mathrm{lift}}\) is a heterogeneous receipt, not vector subtraction.
The pattern returns because specified fields agree. The lift remains because
all other typed coordinates are retained.

## 5. The \(\pi\)-wall

Lithium supplies the first concrete test of the elementary
\(\pi[\mathsf{C2Character};X]\) registry:

\[
\begin{aligned}
\pi_{\mathrm{el}}({}^{1}\!H)&=+1,&
\pi_{\mathrm{el}}({}^{7}\!Li)&=+1,\\
\pi_{\mathrm{nuc}}({}^{1}\!H)&=+1,&
\pi_{\mathrm{nuc}}({}^{7}\!Li)&=-1.
\end{aligned}
\]

Therefore the valence-pattern reader must consume tagged
\(\pi_{\mathrm{el}}\). An unqualified \(\pi\) would either:

1. erase a real isotope/nuclear Difference by forcing the signs together; or
2. falsely reject the electronic-valence return by reading nuclear parity in
   the electronic slot.

The correct result is stronger:

> electronic parity returns; nuclear parity does not; the receipt retains
> both.

This does not identify electronic parity with
\(\pi[\mathsf{Phase}]\) or \(\pi[\mathsf{Recognition}]\). It demonstrates why
the shared \(C_2\)-character interface needs tagged carriers.

## 6. First Quotient-Return Theorem

Let \(\Gamma_{[1,3]}\) be the free path category generated by

\[
e_1:b_1\longrightarrow b_2,
\qquad
e_2:b_2\longrightarrow b_3,
\]

where both arrows are \(\mathsf{RefStep}\) comparisons, not physical
evolution.

Let \(\mathcal G_{\mathrm{occ}}^{\mathcal P}\) be the free path category on
the occupation-pattern graph generated below. Define

\[
\begin{aligned}
Q_{\mathrm{occ}}(e_1)
&=
f:\mathsf O_s\longrightarrow\mathsf C_s,
&&\mathsf{RefFill}_{1s},\\
Q_{\mathrm{occ}}(e_2)
&=
\ell:\mathsf C_s\longrightarrow\mathsf O_s,
&&\mathsf{RefLiftOpen}_{2s}.
\end{aligned}
\]

These descriptive edge names do not claim that one atom physically changes
into the next. The object and generator assignments extend uniquely to a
functor

\[
Q_{\mathrm{occ}}:
\Gamma_{[1,3]}
\longrightarrow
\mathcal G_{\mathrm{occ}}^{\mathcal P}.
\]

The projected composite is

\[
\lambda
=
\ell\circ f:
\mathsf O_s\longrightarrow\mathsf O_s.
\]

In the free occupation-pattern category,

\[
\lambda\neq I_{\mathsf O_s}
\]

because it is the retained length-two word \(\ell f\), not an empty path.

### Theorem

At \(\mathcal R_{\mathrm{cfg}}\) and under the declared pattern policy
\(\mathcal P\), the raw reference path

\[
b_1\longrightarrow b_2\longrightarrow b_3
\]

remains open, while its \(Q_{\mathrm{occ}}\)-image is the closed walk

\[
\mathsf O_s
\xrightarrow{\ f\ }
\mathsf C_s
\xrightarrow{\ \ell\ }
\mathsf O_s.
\]

The endpoint pattern returns, the projected path remains nonidentity, and the
total lifted endpoint does not close:

\[
q_{\mathrm{pattern}}(v_1)
=
q_{\mathrm{pattern}}(v_3),
\qquad
\lambda\neq I,
\qquad
v_1\neq v_3.
\]

This is an externally calibrated physical witness, at the declared resolution,
of the previously typed **Quotient-returned** mode: declared pattern identity
returns in a quotient while local Difference remains.

The earned vocabulary is:

- Helium: \(\mathsf{ShellSaturated}\);
- Lithium: \(\mathsf{PatternReturn}\);
- the whole three-point image: a **two-edge projected closed walk with retained
  lift**.

## 7. Evidence verdict

The result is predicate-qualified:

\[
\mathsf{Cert}
\bigl[
\mathsf{PatternEq}
\mid
\mathcal R_{\mathrm{cfg}},
\mathcal P,
\mathsf{EvaluatedConfigurationLabels}
\bigr].
\]

It is not

\[
\mathsf{Cert}[\mathsf{ExactStateEq}]
\quad\text{or}\quad
\mathsf{Cert}[H_H\simeq H_{Li}].
\]

The evidence ladder is:

| Physical extraction | Lawful verdict |
|:--|:--|
| evaluated configuration label with matching policy fields | \(\mathsf{Cert[PatternEq]}\) |
| validated dominant-configuration decomposition with error data | \(\mathsf{Approximate}\) or \(\mathsf{Mixed}\), predicate named |
| no validated active/core split | \(\mathsf{Unknown}\) |
| proved mismatch in a kept field | \(\mathsf{Defect[PatternEq]}\) |

Exactness belongs to the projection on admitted descriptors. Model dependence
belongs to the extraction of those descriptors from the physical state.

## 8. What geometry has—and has not—been earned

The result supplies the minimum local signature a lifted periodic geometry
would require:

\[
\text{projected return}
\quad+\quad
\text{nonzero retained lift}.
\]

It does **not** yet establish:

- a global periodic law;
- a wheel, spiral, helix, or covering-space theorem;
- a period-two action or involution;
- a \(C_2\) action on elements;
- a shell-translation operator;
- an intertwiner between \(H_H\) and \(H_{Li}\);
- physical evolution \(H\to He\to Li\);
- a \(\pi\)-, CORDIS-, or Greek-office alignment.

One lifted return supplies neither repeated transport nor measurable pitch,
curvature, or a composition law. A second \(s^1\) return, Lithium→Sodium,
together with compatible receipt composition, is the next direct geometry
test.

Before that longer return, the second-period carrier

\[
Li\longrightarrow Be\longrightarrow B\longrightarrow C
\longrightarrow N\longrightarrow O\longrightarrow F\longrightarrow Ne
\]

is the natural next build. It will:

1. test whether the pattern policy extends without laundering mixed
   configurations into exact labels;
2. seat Oxygen inside the declared Hamiltonian-fiber architecture;
3. produce the independent Helium→Neon shell-saturation return;
4. reopen the water/ComplexZeroReturn witness on a typed elemental base.

## 9. Admitted lock

\[
\boxed{
\begin{gathered}
q_{\mathrm{pattern}}r_{\mathrm{PT}}(1)
=
q_{\mathrm{pattern}}r_{\mathrm{PT}}(3),\\
r_{\mathrm{PT}}(1)\neq r_{\mathrm{PT}}(3),\\
\widehat q\ \text{retains and recovers the lifted Difference.}
\end{gathered}
}
\]

> Hydrogen opens the first \(s^1\) pattern. Helium saturates the first shell.
> Lithium returns the \(s^1\) pattern on a new radial layer. The quotient
> closes. The physical lineage does not.
