# THE ELECTROWEAK SEAM

## A typed \(SU(2)_L\times U(1)_Y\to U(1)_{\mathrm{em}}\) closure

**Version 0.1 — 20 August 2026**

---

## Status and purpose

This note carries *The Classical Gauge Spine* through the native electroweak junction.

It does not derive the Standard Model from the root construction. It does not identify a root matrix with a physical gauge field, a Higgs field, or a particle. It does not claim that an algebraic normal form selects chirality, hypercharge, coupling strengths, the electroweak scale, or the observed matter spectrum.

Its task is narrower and exact:

1. state the local electroweak carrier in its own jurisdiction;
2. distinguish weak isospin from hypercharge at the algebraic root;
3. register the chiral matter and scalar representations used by the minimal Standard Model;
4. derive the unbroken electromagnetic generator as the stabilizer of the scalar vacuum;
5. diagonalize the charged and neutral gauge-field quadratic forms;
6. replace “the Higgs gives mass” with the mechanism actually carried by the Lagrangian;
7. attach the \(W\), \(Z\), and Higgs sectors to outside experimental receipts;
8. state exactly what the root adapter preserves and what remains declared or open.

The governing distinction is:

> A shared Lie algebra supplies coordinates. A physical theory still has to supply the representation, connection, couplings, scalar carrier, vacuum, dynamics, and receipt.

Statuses are used as in *Physical Adapter Certificate v0.1*:

- **DERIVED** — follows from displayed definitions;
- **DECLARED** — selected as jurisdiction, convention, representation, parameter, or carrier;
- **MEASURED** — supplied by an empirical record;
- **CONDITIONAL** — valid under named additional hypotheses;
- **OPEN** — not supplied here;
- **REFUSED** — incompatible with the displayed type or operation;
- **NOT USED** — available elsewhere but unnecessary here.

---

## 1. The seam: three turning directions and one independent center

At the local Lie-algebra level, the electroweak theory uses

\[
\mathfrak g_{\mathrm{EW}}
=
\mathfrak{su}(2)_L\oplus\mathfrak u(1)_Y.
\]

The two summands have different offices.

- \(\mathfrak{su}(2)_L\) is non-Abelian and acts on declared left-handed weak doublets.
- \(\mathfrak u(1)_Y\) is Abelian, commutes with every weak-isospin generator, and acts with a representation-dependent hypercharge weight.

Let

\[
\tau_a=\frac{\sigma_a}{2}
\]

be the Hermitian weak-isospin generators on a doublet, and let

\[
S_a=-\mathbf i\tau_a=-\frac{\mathbf i}{2}\sigma_a
\]

be the corresponding anti-Hermitian basis. Then

\[
[S_a,S_b]=\varepsilon_{abc}S_c,
\qquad
-2\operatorname{tr}(S_aS_b)=\delta_{ab}.
\]

The independent central axis in the same two-dimensional complex carrier is

\[
Z_0=-\mathbf i I,
\qquad
[Z_0,S_a]=0.
\]

Therefore

\[
\operatorname{span}_{\mathbb R}
\{S_1,S_2,S_3,Z_0\}
=
\mathfrak u(2)
\]

as a local real Lie algebra, and

\[
\mathfrak u(2)
\cong
\mathfrak{su}(2)\oplus\mathfrak u(1).
\]

This local identity is **DERIVED**. It does not by itself fix the global electroweak gauge group, its discrete quotient, the normalization of hypercharge, or the representations on all matter fields. Those are separate data.

### Root hygiene

The central axis cannot be one of the three weak-isospin axes. In particular, no element of

\[
\operatorname{span}_{\mathbb R}\{S_1,S_2,S_3\}
\]

commutes with the whole non-Abelian algebra except zero. Therefore using \(\Omega\), \(\mathbf iH\), or \(\mathbf iK\) simultaneously as an internal weak axis and as hypercharge is **REFUSED**.

The minimum electroweak extension of the compact root frame is not a reinterpretation of one existing direction. It is the addition of an independent commuting direction:

\[
\boxed{
\mathfrak{su}(2)_{\mathrm{root}}
\longrightarrow
\mathfrak{su}(2)_L
\quad\text{and}\quad
\mathbb R Z_0
\text{ added independently}
}.
\]

---

## 2. Native matter and scalar register

Use the Hermitian hypercharge convention

\[
Q_{\mathrm{em}}=T_3+Y.
\]

This convention is **DECLARED**. It must not be mixed with the alternative convention \(Q=T_3+Y/2\) without rescaling every hypercharge.

For one Standard Model generation, the electroweak representations are:

| Field | Chirality | \(SU(2)_L\) | \(Y\) | Component electric charges |
|---|---:|---:|---:|---:|
| \(q_L=(u_L,d_L)^\mathsf T\) | left | \(\mathbf2\) | \(1/6\) | \((2/3,-1/3)\) |
| \(u_R\) | right | \(\mathbf1\) | \(2/3\) | \(2/3\) |
| \(d_R\) | right | \(\mathbf1\) | \(-1/3\) | \(-1/3\) |
| \(\ell_L=(\nu_L,e_L)^\mathsf T\) | left | \(\mathbf2\) | \(-1/2\) | \((0,-1)\) |
| \(e_R\) | right | \(\mathbf1\) | \(-1\) | \(-1\) |
| \(\phi=(\phi^+,\phi^0)^\mathsf T\) | scalar | \(\mathbf2\) | \(1/2\) | \((1,0)\) |

The quark fields also carry color, suppressed in this electroweak table. The weak group acts on the left-handed doublets; the right-handed charged fields are weak singlets. This is the physical meaning of the subscript \(L\) in \(SU(2)_L\). Chirality is **DECLARED by the measured Standard Model representation content**; it is not a consequence of the abstract algebra \(\mathfrak{su}(2)\).

For a doublet with hypercharge \(y\),

\[
Q_{\mathrm{em}}
=
\begin{pmatrix}
\frac12+y&0\\
0&-\frac12+y
\end{pmatrix}.
\]

The displayed component charges follow immediately. They are **DERIVED from the declared representations**.

The minimal Standard Model contains no right-handed neutrino field and therefore no renormalizable neutrino Yukawa mass term. Observed neutrino masses and mixing require an extension of this minimal register. Their mechanism is **OPEN in the present note**.

---

## 3. Connection and curvature

Let \(M\) be four-dimensional spacetime in the Standard Model regime. With Hermitian generators, write the electroweak covariant derivative on a field of weak representation \(R\) and hypercharge \(y_R\) as

\[
D_\mu
=
\partial_\mu
-\mathbf i g W_\mu^a\,\tau_a^{(R)}
-\mathbf i g' y_R B_\mu.
\]

Here:

- \(W_\mu^a\) is the \(SU(2)_L\) connection;
- \(B_\mu\) is the independent \(U(1)_Y\) connection;
- \(g\) and \(g'\) are dimensionless couplings in four spacetime dimensions;
- \(\tau_a^{(R)}=0\) for a weak singlet.

Equivalently, in anti-Hermitian notation,

\[
D_\mu
=
\partial_\mu
+gW_\mu^aS_a^{(R)}
+g'B_\mu Z_Y^{(R)},
\qquad
Z_Y^{(R)}=-\mathbf i y_R I_R.
\]

The curvatures are

\[
W_{\mu\nu}^a
=
\partial_\mu W_\nu^a
-\partial_\nu W_\mu^a
+g\varepsilon^{abc}W_\mu^bW_\nu^c,
\]

and

\[
B_{\mu\nu}
=
\partial_\mu B_\nu
-\partial_\nu B_\mu.
\]

The first curvature contains the connection self-commutator. The second does not. This is the native non-Abelian/Abelian distinction; it is not supplied by calling both objects fields.

The gauge kinetic term is

\[
\mathcal L_{\mathrm{gauge}}
=
-\frac14W_{\mu\nu}^aW^{a\mu\nu}
-\frac14B_{\mu\nu}B^{\mu\nu}.
\]

This note works at tree level unless radiative corrections are explicitly named. Precision electroweak predictions require renormalization conventions and loop corrections not reproduced here.

---

## 4. Scalar carrier and nonzero vacuum

Declare one complex scalar doublet

\[
\phi
=
\begin{pmatrix}
\phi^+\\
\phi^0
\end{pmatrix},
\qquad
Y_\phi=\frac12,
\]

with Lagrangian

\[
\mathcal L_\phi
=
(D_\mu\phi)^\dagger(D^\mu\phi)-V(\phi),
\]

and potential convention

\[
V(\phi)
=
-\mu^2\phi^\dagger\phi
+\lambda(\phi^\dagger\phi)^2,
\qquad
\mu^2>0,
\quad
\lambda>0.
\]

The minima satisfy

\[
\phi^\dagger\phi=\frac{v^2}{2},
\qquad
v=\frac{\mu}{\sqrt\lambda}.
\]

Choose the vacuum representative

\[
\phi_0
=
\frac1{\sqrt2}
\begin{pmatrix}
0\\
v
\end{pmatrix}.
\]

The potential, its parameters, the scalar representation, and the nonzero value of \(v\) are **DECLARED physical data of the minimal model**. The location of the minimum follows from the declared potential. The measured Fermi constant fixes

\[
v=(\sqrt2G_F)^{-1/2}\approx246.22\ \mathrm{GeV}
\]

in the conventional electroweak normalization.

The displayed representative is a gauge choice inside the orbit of minima. It does not imply that a gauge redundancy has become a physically distinguishable set of vacua.

---

## 5. The electromagnetic stabilizer

Let a general Hermitian neutral infinitesimal generator on the scalar doublet be

\[
X=\alpha_a\tau_a+\beta Y_\phi I.
\]

Demand that it preserve the chosen vacuum:

\[
X\phi_0=0.
\]

The \(\tau_1\) and \(\tau_2\) terms move the lower component into the upper component, so

\[
\alpha_1=\alpha_2=0.
\]

On the lower component,

\[
\tau_3=-\frac12,
\qquad
Y_\phi=+\frac12.
\]

Therefore

\[
-\frac{\alpha_3}{2}+\frac\beta2=0,
\qquad
\alpha_3=\beta.
\]

The one-dimensional stabilizer is generated by

\[
\boxed{
Q_{\mathrm{em}}=T_3+Y
}.
\]

Indeed,

\[
Q_{\mathrm{em}}\phi_0=0.
\]

Thus

\[
SU(2)_L\times U(1)_Y
\longrightarrow
U(1)_{\mathrm{em}}
\]

at the level of the vacuum stabilizer.

This is the load-bearing electroweak seam:

> Electromagnetism is the connection direction whose generator leaves the scalar vacuum invariant.

The statement is **DERIVED inside the declared scalar representation and vacuum**. It is not derived from the abstract gauge algebra alone.

---

## 6. Charged and neutral field coordinates

Evaluating the covariant derivative on the vacuum gives

\[
(D_\mu\phi_0)^\dagger(D^\mu\phi_0)
=
\frac{v^2}{8}
\left[
g^2\bigl((W_\mu^1)^2+(W_\mu^2)^2\bigr)
+(gW_\mu^3-g'B_\mu)^2
\right].
\]

### Charged directions

Define

\[
W_\mu^\pm
=
\frac{W_\mu^1\mp\mathbf iW_\mu^2}{\sqrt2}.
\]

The charged quadratic term is

\[
\frac{g^2v^2}{4}W_\mu^+W^{-\mu},
\]

so the tree-level mass is

\[
\boxed{m_W=\frac{gv}{2}}.
\]

### Neutral directions

The neutral quadratic form is

\[
\frac{v^2}{8}
\begin{pmatrix}W_\mu^3&B_\mu\end{pmatrix}
\begin{pmatrix}
g^2&-gg'\\
-gg'&g'^2
\end{pmatrix}
\begin{pmatrix}W^{3\mu}\\B^\mu\end{pmatrix}.
\]

Its determinant is zero. Its null vector is proportional to

\[
\begin{pmatrix}g'\\g\end{pmatrix},
\]

and its nonzero eigenvector is proportional to

\[
\begin{pmatrix}g\\-g'\end{pmatrix}.
\]

Define

\[
s_W=\sin\theta_W=\frac{g'}{\sqrt{g^2+g'^2}},
\qquad
c_W=\cos\theta_W=\frac{g}{\sqrt{g^2+g'^2}},
\]

so that

\[
\tan\theta_W=\frac{g'}g.
\]

The orthonormal neutral combinations are

\[
\boxed{
A_\mu=s_WW_\mu^3+c_WB_\mu
},
\]

and

\[
\boxed{
Z_\mu=c_WW_\mu^3-s_WB_\mu
}.
\]

The corresponding tree-level masses are

\[
\boxed{m_A=0},
\qquad
\boxed{m_Z=\frac v2\sqrt{g^2+g'^2}}.
\]

The electromagnetic coupling is

\[
\boxed{
e=gs_W=g'c_W
}.
\]

At tree level,

\[
m_W=m_Zc_W.
\]

The massless field direction and the unbroken charge generator are dual parts of the same stabilizer calculation. One acts on the connection coordinates; the other acts on the represented fields.

---

## 7. What “the Higgs gives mass” compresses

The familiar phrase is serviceable shorthand but mechanically inverted if read literally. No mass substance is transported from a scalar object into a gauge boson. No pre-existing motion is started. No local gauge generator is destroyed.

The typed statement is:

> A declared scalar doublet has a nonzero vacuum amplitude. Evaluating its gauge-covariant kinetic term about that vacuum produces quadratic terms for the connection combinations whose generators do not stabilize the vacuum. After canonical field normalization, the coefficients of those quadratic terms are the tree-level squared masses. The stabilizing connection direction has zero coefficient and remains the electromagnetic photon.

In unitary-gauge coordinates,

\[
\phi(x)
=
\frac1{\sqrt2}
\begin{pmatrix}
0\\
v+h(x)
\end{pmatrix}.
\]

The four real scalar coordinates have been reorganized:

- three gauge-orbit directions supply the longitudinal polarizations used to describe the massive \(W^+\), \(W^-\), and \(Z\) fields;
- one radial excitation \(h(x)\) remains as the physical Higgs boson.

“The Goldstone bosons are eaten” compresses this gauge-dependent reorganization. It is not literal consumption.

### Gauge-boson mass and fermion mass are different operations

Gauge-boson masses arise from the scalar kinetic term

\[
(D_\mu\phi)^\dagger(D^\mu\phi).
\]

Charged-fermion masses arise from separately declared Yukawa couplings. For example,

\[
\mathcal L_Y
\supset
-y_e\,\overline{\ell_L}\phi e_R
-y_d\,\overline{q_L}\phi d_R
-y_u\,\overline{q_L}\widetilde\phi u_R
+\mathrm{h.c.},
\]

with

\[
\widetilde\phi=\mathbf i\sigma_2\phi^*.
\]

After expansion about \(\phi_0\),

\[
m_f=\frac{y_fv}{\sqrt2}.
\]

The Standard Model does not derive the observed Yukawa values. It converts declared dimensionless couplings and the measured vacuum scale into masses. The flavor hierarchy is **OPEN**.

---

## 8. Quantum consistency check on one generation

The representation table is not an arbitrary list of unrelated charges. Written entirely as left-handed Weyl fields,

\[
q_L:(\mathbf3,\mathbf2)_{1/6},
\quad
u_R^c:(\overline{\mathbf3},\mathbf1)_{-2/3},
\quad
d_R^c:(\overline{\mathbf3},\mathbf1)_{1/3},
\]

\[
\ell_L:(\mathbf1,\mathbf2)_{-1/2},
\quad
e_R^c:(\mathbf1,\mathbf1)_1.
\]

The local gauge-anomaly sums vanish generation by generation.

For \([SU(3)]^2U(1)_Y\), omitting the common Dynkin index,

\[
2\left(\frac16\right)
-\frac23
+\frac13
=0.
\]

For \([SU(2)]^2U(1)_Y\),

\[
3\left(\frac16\right)
-\frac12
=0.
\]

For the mixed gravitational-hypercharge anomaly,

\[
6\left(\frac16\right)
+3\left(-\frac23\right)
+3\left(\frac13\right)
+2\left(-\frac12\right)
+1
=0.
\]

For \([U(1)_Y]^3\),

\[
6\left(\frac16\right)^3
+3\left(-\frac23\right)^3
+3\left(\frac13\right)^3
+2\left(-\frac12\right)^3
+1^3
=0.
\]

There are four left-handed \(SU(2)\) doublets per generation after the three quark colors are counted, so the number is even and the original Witten \(SU(2)\) global anomaly is absent.

These cancellations are **DERIVED from the declared Standard Model representation table**. They constrain the admissibility of that table as a quantum gauge theory. They do not prove that the root selects the table, and they do not by themselves prove uniqueness among all anomaly-free extensions.

---

## 9. Noether and charge hygiene

Local electroweak gauge invariance belongs to Noether’s second-theorem jurisdiction: it produces identities among field equations. It is not, by itself, a simple first-theorem statement that four gauge redundancies provide four directly observable conserved charges.

After the vacuum is fixed, the unbroken generator

\[
Q_{\mathrm{em}}=T_3+Y
\]

defines the electromagnetic representation weights. Electric charge conservation is carried by the surviving \(U(1)_{\mathrm{em}}\) gauge structure together with the matter equations and appropriate boundary conditions.

The weak charged currents change \(T_3\) and electric charge of the matter component while exchanging that charge with \(W^\pm\). The complete interacting system carries the conservation law; an isolated component label does not.

The phrase “symmetry breaking” must therefore be read with care. The Lagrangian remains gauge invariant. A nonzero scalar configuration has a smaller stabilizer, and the connection coordinates reorganize around it.

---

## 10. Outside receipts

### Charged weak carrier

In 1983 the UA1 Collaboration reported isolated high-transverse-energy electrons together with missing transverse energy in proton–antiproton collisions. The event topology and rate were consistent with a particle near \(80\ \mathrm{GeV}/c^2\) decaying through

\[
W^\pm\to e^\pm\nu.
\]

The missing transverse momentum is part of the operational receipt: it closes momentum balance without claiming direct detection of the neutrino.

### Neutral weak carrier

Later in 1983 UA1 reported electron and muon pairs with invariant mass near \(95\ \mathrm{GeV}/c^2\), providing the direct neutral-boson receipt associated with the \(Z\) sector. Subsequent precision programs refined the mass and couplings far beyond the discovery record.

### Scalar carrier

In 2012 ATLAS and CMS independently reported a new boson near \(125\)–\(126\ \mathrm{GeV}\). Each collaboration reported a local significance at or above five standard deviations in its combined analysis. Later measurements established properties consistent with the Standard Model Higgs boson.

These measurements certify physical carriers for the massive charged, massive neutral, and scalar sectors. They do not certify the root adapter. Conversely, the root adapter does not manufacture these receipts.

The tree-level mass equations above are not direct fits to the discovery numbers. Precision comparison requires radiative corrections, a renormalization scheme, detector response, likelihood construction, and uncertainty propagation.

---

## 11. Root-to-electroweak adapter

The classical gauge spine supplies the root compact basis

\[
T_1^{\mathrm r}=\frac12\Omega,
\qquad
T_2^{\mathrm r}=\frac12\mathbf iH,
\qquad
T_3^{\mathrm r}=\frac12\mathbf iK,
\]

with

\[
[T_a^{\mathrm r},T_b^{\mathrm r}]
=
\varepsilon_{abc}T_c^{\mathrm r},
\qquad
-2\operatorname{tr}(T_a^{\mathrm r}T_b^{\mathrm r})
=
\delta_{ab}.
\]

Define

\[
\beta_{\mathrm W}:
\mathfrak{su}(2)_{\mathrm{root}}
\longrightarrow
\mathfrak{su}(2)_L,
\qquad
\beta_{\mathrm W}(T_a^{\mathrm r})=S_a.
\]

Then

\[
\beta_{\mathrm W}([X,Y])
=
[\beta_{\mathrm W}(X),\beta_{\mathrm W}(Y)],
\]

and the normalized trace pairing is preserved.

Add an abstract independent central generator \(z\), and define the local extension

\[
\iota:
\mathfrak{su}(2)_{\mathrm{root}}\oplus\mathbb Rz
\longrightarrow
\mathfrak u(2),
\qquad
\iota(X,az)=\beta_{\mathrm W}(X)+aZ_0.
\]

Because \([Z_0,S_a]=0\), \(\iota\) is a real Lie-algebra isomorphism. On a field of hypercharge \(y_R\), the central generator is represented with the corresponding weight:

\[
d\rho_R(y_Rz)=-\mathbf i y_RI_R.
\]

### Adapter certificate

| Field | Certified content |
|---|---|
| Domain | root compact algebra plus an independently declared central line |
| Operation | \(\beta_{\mathrm W}(T_a^{\mathrm r})=S_a\), \(z\mapsto Z_0\) |
| Codomain | local \(\mathfrak{su}(2)_L\oplus\mathfrak u(1)_Y\) connection algebra |
| Invariant | Lie bracket; normalized trace pairing on the \(\mathfrak{su}(2)\) summand; centrality of \(z\) |
| Symmetry | local adjoint action, with the center fixed by conjugation |
| Receipt | equality of algebraic commutators and the derived vacuum-stabilizer/mass-matrix calculation once the physical carrier is declared |

### What the adapter does not supply

The adapter does not select:

- left rather than right chirality;
- the hypercharge weights;
- the number of generations;
- the scalar doublet or its potential;
- \(g\), \(g'\), \(\theta_W\), \(v\), \(\lambda\), or any Yukawa coupling;
- spacetime, quantum statistics, renormalization, or detector access;
- the global gauge-group quotient;
- a physical field configuration or measured event.

Those facts remain native physical input or open structure.

---

## 12. Condition and constraint register

| Office | Condition or constraint | Status | Failure mode |
|---|---|---|---|
| spacetime carrier | relativistic four-dimensional field theory in the Standard Model regime | **DECLARED** | the displayed kinetic and mass interpretation changes |
| local gauge algebra | \(\mathfrak{su}(2)_L\oplus\mathfrak u(1)_Y\) | **DECLARED** | weak and hypercharge offices are not defined |
| independent center | \([Z_0,S_a]=0\) | **DERIVED/REQUIRED** | hypercharge is conflated with weak isospin |
| chirality | weak doublet action restricted to declared left-handed matter fields | **DECLARED/MEASURED** | parity structure of weak interactions is lost |
| representations | field multiplets and hypercharges of Section 2 | **DECLARED/MEASURED** | electric charges, currents, and anomaly sums change |
| gauge connection | \(W_\mu^a,B_\mu\) with couplings \(g,g'\) | **DECLARED** | no physical transport or curvature is supplied |
| scalar carrier | one complex \((\mathbf2,1/2)\) field | **DECLARED** | displayed stabilizer and mass matrix do not follow |
| vacuum amplitude | \(v\neq0\) | **DECLARED/MEASURED** | all four gauge directions remain massless at tree level |
| stability | \(\lambda>0\), chosen potential bounded below | **DECLARED** | no stable vacuum shell exists |
| stabilizer | \(Q_{\mathrm{em}}\phi_0=0\) | **DERIVED** | photon direction is not protected as the null mode |
| canonical normalization | standard gauge and scalar kinetic coefficients | **DECLARED** | quadratic coefficients cannot be read as the displayed masses |
| anomaly cancellation | local anomaly sums vanish; weak-doublet count is even | **DERIVED from declared matter** | quantum gauge theory is inconsistent |
| fermion masses | gauge-invariant Yukawa couplings | **DECLARED** | charged fermions remain massless in the minimal renormalizable model |
| neutrino mass | carrier beyond the minimal register | **OPEN** | observed neutrino oscillations remain unexplained |
| precision | loop corrections and renormalization scheme | **CONDITIONAL/OPEN here** | tree-level relations are overread as precision identities |
| receipt | reconstructed decay products, missing momentum, invariant masses, and statistical controls | **MEASURED** | algebra is mistaken for observation |
| global form | quotient and hypercharge normalization kernel | **OPEN here** | local algebra is overread as a unique global gauge group |

---

## 13. Root-object verdicts

| Root object | Role in this seam | Verdict |
|---|---|---|
| \(\Omega,\mathbf iH,\mathbf iK\) | compact weak-isospin coordinate frame | **ADMITTED through \(\beta_{\mathrm W}\)** |
| ordinary \(\mathbf i\) | complex scalar used in anti-Hermitian physical representations | **DECLARED** |
| independent \(-\mathbf iI\) | central hypercharge coordinate | **ADMITTED as a new independent axis** |
| \(\Omega\) as hypercharge | would reuse a noncentral weak axis | **REFUSED** |
| \(K\) without \(\mathbf i\) | noncompact split direction | **NOT USED** |
| \(Q\) | no native electroweak office required | **NOT USED** |
| \(Q^2=e^{2\log\Phi K}\) | noncompact even carriage | **NOT USED; NOT FORCED** |
| \(G\) as root metric | no electroweak spacetime or kinetic metric supplied | **NOT USED** |
| \(\Phi\) and Fibonacci recurrence | no native role in the electroweak carrier | **NOT USED** |
| root central square | distinct from the electroweak vacuum stabilizer | **DO NOT CONFLATE** |

The absence of \(Q^2\) is informative rather than disappointing. The native electroweak closure does not ask for it. It remains visible at the root and unassigned until an independently certified physical office requires exactly that carriage.

---

## 14. What closes

The following claims are closed in the stated jurisdiction:

1. The local electroweak algebra requires a three-dimensional non-Abelian weak summand and an independent one-dimensional commuting hypercharge summand.
2. The compact root frame supplies an exact bracket- and trace-preserving coordinate adapter to the weak \(\mathfrak{su}(2)\) algebra.
3. A central line must be added independently; no weak-isospin axis can double as hypercharge.
4. The declared one-generation representations reproduce the observed component electric charges through \(Q_{\mathrm{em}}=T_3+Y\).
5. The scalar vacuum is stabilized by precisely the electromagnetic generator.
6. The scalar covariant kinetic term yields two charged massive directions, one neutral massive direction, and one neutral null direction.
7. The null direction is the photon and the orthogonal neutral direction is the \(Z\), with the displayed tree-level mixing and mass relations.
8. “The Higgs gives mass” is correctly unpacked as a vacuum-dependent quadratic-form calculation, not a transfer of substance or initiation of motion.
9. Gauge-boson masses and fermion masses arise from different Lagrangian offices.
10. The declared matter representation cancels the displayed local anomalies generation by generation and avoids the original \(SU(2)\) global anomaly.
11. The \(W\), \(Z\), and Higgs sectors possess independent outside experimental receipts.
12. None of these closures requires \(Q^2\).

---

## 15. What remains open

This note does not derive:

- why the physical gauge algebra is selected;
- why the weak action is left-chiral;
- the hypercharge spectrum or charge quantization from the root;
- the global Standard Model gauge group;
- the number of fermion generations;
- the values or running of \(g\), \(g'\), or \(\theta_W\);
- the electroweak scale \(v\) or scalar self-coupling \(\lambda\);
- the Yukawa matrices, flavor hierarchy, CKM phase, or PMNS data;
- neutrino mass;
- the strong interaction, gravity, dark matter, or cosmic evolution;
- the hierarchy/naturalness problem;
- nonperturbative quantum Yang–Mills closure;
- a physical role for \(Q\), \(Q^2\), \(G\), or \(\Phi\) in this carrier.

These are not defects hidden by the seam. They are the typed boundaries that keep the seam usable.

---

## 16. Source ledger

### Primary and authoritative external sources

1. Sheldon L. Glashow, “Partial-Symmetries of Weak Interactions,” *Nuclear Physics* **22** (1961), 579–588. <https://doi.org/10.1016/0029-5582(61)90469-2>
2. Peter W. Higgs, “Broken Symmetries and the Masses of Gauge Bosons,” *Physical Review Letters* **13** (1964), 508–509. <https://doi.org/10.1103/PhysRevLett.13.508>
3. Peter W. Higgs, “Spontaneous Symmetry Breakdown without Massless Bosons,” *Physical Review* **145** (1966), 1156–1163. <https://doi.org/10.1103/PhysRev.145.1156>
4. Steven Weinberg, “A Model of Leptons,” *Physical Review Letters* **19** (1967), 1264–1266. <https://doi.org/10.1103/PhysRevLett.19.1264>
5. C. Bouchiat, J. Iliopoulos, and Ph. Meyer, “An Anomaly-Free Version of Weinberg’s Model,” *Physics Letters B* **38** (1972), 519–523. <https://doi.org/10.1016/0370-2693(72)90532-1>
6. Edward Witten, “An \(SU(2)\) Anomaly,” *Physics Letters B* **117** (1982), 324–328. <https://doi.org/10.1016/0370-2693(82)90728-6>
7. UA1 Collaboration, “Experimental Observation of Isolated Large Transverse Energy Electrons with Associated Missing Energy at \(\sqrt s=540\) GeV,” *Physics Letters B* **122** (1983), 103–116. <https://doi.org/10.1016/0370-2693(83)91177-2>
8. UA1 Collaboration, “Experimental Observation of Lepton Pairs of Invariant Mass Around 95 GeV/\(c^2\) at the CERN SPS Collider,” *Physics Letters B* **126** (1983), 398–410. <https://doi.org/10.1016/0370-2693(83)90188-0>
9. ATLAS Collaboration, “Observation of a New Particle in the Search for the Standard Model Higgs Boson with the ATLAS Detector at the LHC,” *Physics Letters B* **716** (2012), 1–29. <https://cds.cern.ch/record/1471031>
10. CMS Collaboration, “Observation of a New Boson at a Mass of 125 GeV with the CMS Experiment at the LHC,” *Physics Letters B* **716** (2012), 30–61. <https://cds.cern.ch/record/1471016>
11. J. Erler and A. Freitas, “Electroweak Model and Constraints on New Physics,” in *Review of Particle Physics*, Particle Data Group (2024). <https://pdg.lbl.gov/2024/reviews/rpp2024-rev-standard-model.pdf>

### Internal sources

12. *Everything: The Minimum Classical Closure*, v0.9.
13. *The Classical Gauge Spine*, v0.1.
14. *The Electromagnetic Holonomy Carrier*, v0.1.
15. *The Non-Abelian Holonomy Carrier*, v0.1.
16. *Physical Adapter Certificate*, v0.1.

### Source-to-claim map

| Claim | Source |
|---|---|
| four electroweak connection directions and neutral mixing program | Glashow; Weinberg |
| gauge-field mass mechanism and surviving scalar mode | Higgs 1964; Higgs 1966; Weinberg |
| modern field content, chiral currents, mixing, tree masses, \(v\), precision boundary | Particle Data Group |
| local anomaly cancellation requirement | Bouchiat, Iliopoulos, and Meyer |
| even-doublet global \(SU(2)\) consistency condition | Witten |
| charged weak-boson discovery receipt | UA1 1983 \(W\) paper |
| neutral weak-boson discovery receipt | UA1 1983 \(Z\) paper |
| scalar-boson discovery receipts | ATLAS; CMS |
| compact root frame and split/compact boundary | *The Classical Gauge Spine* |
| root-to-weak adapter, central extension, stabilizer, mass-matrix diagonalization, charge table, anomaly arithmetic | present derivation |

---

## Status note

This seam closes the first native Standard Model junction reached by the gauge spine.

The root supplies three compact internal coordinates. Electroweak physics supplies an independent center, chiral representations, two couplings, a scalar doublet, a nonzero vacuum, spacetime dynamics, and measured receipts. The vacuum does not create the gauge occurrence. It selects the combination that can remain unopposed through it.

The center is independent. The vacuum fixes the seam. The photon is what the vacuum leaves free.
