# Native Domain Adapter Atlas v0.3

**Purpose:** preserve v0.2, bind the previously omitted hydrogen records, repair the atomic/GR status language, and add the exact Body–SI–English Length Adapter.

## New result

`BODY_SI_ENGLISH_LENGTH_ADAPTER_v0_1.md` closes a conventional, reversible public-measurement adapter:

\[
\text{body-length record}
\xrightarrow{\rho_{\rm cal}}
\text{SI length}
\xleftrightarrow{T_{\rm exact}}
\text{controlled English length expression}.
\]

The standard conversion is exact; a particular body reading retains its own calibration and uncertainty receipt.

## Repair

- v0.2 is preserved intact under `lineage/`.
- `STATUS_LABEL_RULING_v0_1.md` keeps consolidation, type closure, native reference contact, and prospective novelty in distinct offices.
- Hydrogen's existing NIST/CODATA-reference audit and H–Li receipt are now source-bound.
- GR's closed duty/type map is separated from the source's own selected-observation continuation.

## Run

```bash
python3 -I run_all.py
```

The runner verifies this packet's hashes, runs the U1 exact rational verifier, verifies source bindings, then clean-room reruns the preserved v0.2 packet. Python 3 and SymPy are required for the inherited v0.2 suite.

## Scope

This is a source-hashed adapter atlas. It neither overwrites v0.2 nor converts received source data into Architecture-derived predictions.
