#!/usr/bin/env python3
"""Render a self-contained, read-only research report from an exact audit.

Standard-library only. A separately generated Matplotlib SVG may be embedded
with --figure. The report never fits parameters or synthesizes measurements.
"""
from __future__ import annotations
import argparse
import base64
import hashlib
import html
import json
from pathlib import Path
from urllib.parse import urlparse

ROOT=Path(__file__).resolve().parent


def h(value):
    return html.escape(str(value),quote=True)


def read(path):
    return json.loads(path.read_text(encoding='utf8'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def safe_url(url):
    return h(url) if urlparse(url).scheme in ('https','http') else '#'


def bound(metric):
    if metric is None:
        return 'unmeasured'
    text=h(metric['value'])
    if metric['low']!=metric['high']:
        text+=f"<span class='bounds'>[{h(metric['low'])}, {h(metric['high'])}]</span>"
    return text


def statement(row):
    if row['is_baseline']:
        return 'Paired baseline'
    if row['oxygen_comparison']=='changed_read':
        return 'Oxygen read changed'
    if row['oxygen_comparison']=='compatible_with_return':
        return 'Return compatible; '+('redox difference resolved' if row['redox_difference_resolved'] else 'redox difference unresolved')
    if row['redox_difference_resolved']:
        return 'Returned read; redox difference resolved'
    return 'Returned read; no resolved redox difference'


def verified_algebra(path):
    if path is None or not path.exists():
        return None, 'Receipt unavailable'
    receipt=read(path)
    if receipt.get('code_sha256')!=digest(ROOT/'verify_algebra.py'):
        return receipt,'Verifier hash changed'
    if 'model.py' not in receipt.get('dependency_sha256',{}):
        return receipt,'Model dependency receipt missing'
    for name,expected in receipt.get('dependency_sha256',{}).items():
        if not (ROOT/name).is_file() or digest(ROOT/name)!=expected:
            return receipt,'Dependency hash changed'
    return receipt,receipt.get('status','Unknown status')


def render(audit_path,algebra_path,figure_path,out):
    data=read(audit_path)
    algebra,astatus=verified_algebra(algebra_path)
    tests_path=audit_path.parent/'audit_test_receipt.json'
    tests=read(tests_path) if tests_path.exists() else {}
    tstatus=tests.get('status','Receipt unavailable')
    for name,expected in tests.get('code_sha256',{}).items():
        if not (ROOT/name).is_file() or digest(ROOT/name)!=expected:
            tstatus='Code hash changed'
    receipt_path=audit_path.parent/'receipts.json'
    receipt=read(receipt_path) if receipt_path.exists() else {}
    receipt_match=receipt.get('output_sha256',{}).get('audit.json')==digest(audit_path)
    meta=data['metadata']; counts=data['counts']; origin=data['data_origin']
    source_ledger=read(ROOT/'sources.json')
    origin_label='Synthetic demonstration' if origin=='synthetic' else 'Submitted measured dataset'
    origin_note=('All displayed observations are constructed examples. Human kinetic constants and HIF/EPO responses have not been fitted.'
                 if origin=='synthetic' else
                 'Measurements are declared by the data provider. The report preserves entered values and bounds; causal identification remains a separate analysis.')
    figure=''
    if figure_path:
        figure_path=Path(figure_path)
        if figure_path.suffix.lower()!='.svg':
            raise ValueError('--figure must identify a local SVG')
        figure_receipt=read(figure_path.with_suffix('.json'))
        canonical=json.dumps(data,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode('utf8')
        if figure_receipt.get('audit_content_sha256')!=hashlib.sha256(canonical).hexdigest():
            raise ValueError('Figure receipt belongs to a different audit; regenerate the figure.')
        if figure_receipt.get('svg_sha256')!=digest(figure_path):
            raise ValueError('Figure changed after generation; regenerate it.')
        encoded=base64.b64encode(figure_path.read_bytes()).decode('ascii')
        clock_note='The supplied example has an arbitrary synthetic time scale.' if origin=='synthetic' else 'Time follows the declared dataset clock.'
        figure=f"<figure><img src='data:image/svg+xml;base64,{encoded}' alt='Oxygen, normalized oxidant and scavenger readings, and their ratio over recorded time.'><figcaption>Figure bound to this audit by its receipt. Plot coordinates use floating display values; classifications and the table use exact fractions. Lines connect recorded points. {clock_note}</figcaption></figure>"
    rows_html=[]
    for row in data['rows']:
        d=row['derived'];extra=row.get('extra_fields',{})
        style=' class="witness"' if row['relationship']=='returned_read_with_redox_difference' else ''
        rows_html.append(f"<tr{style}><td>{h(row['run_id'])}<small>{h(row['sample_id'])}</small></td><td>{h(row['occurrence'])}</td><td>{h(row['time_min'])}<small>{h(extra.get('phase_event',''))}</small></td><td>{h(row['inputs']['oxygen']['value'])}</td><td>{bound(d['r'])}</td><td>{bound(d['a'])}</td><td>{bound(d['q'])}</td><td>{bound(d['scale_squared'])}</td><td>{h(statement(row))}</td></tr>")
    source_rows=''.join(f"<tr><td><a href='{safe_url(s['url'])}'>{h(s['citation'])}</a><small>{h(s['type'].replace('_',' '))}</small></td><td>{h(s.get('finding',''))}</td><td>{h(s.get('tool_implication',''))}<small>{h(s['access'])}</small></td></tr>" for s in source_ledger['sources'])
    flags=[]
    for s in source_ledger['sources']:
        for flag in s.get('source_flags',[]):
            flags.append(f"<li><strong>{h(s['citation'])}:</strong> {h(flag)}</li>")
    warnings=''.join(f"<li><code>{h(w['code'])}</code><br>{h(w.get('message',''))}</li>" for w in data['warnings'])
    provenance=''.join(f"<tr><td>{h(key)}</td><td class='hash'>{h(value['sha256'])}</td></tr>" for key,value in data['provenance'].items())
    endpoint=meta.get('endpoint')
    endpoint_text=h(endpoint['name']+' / '+endpoint['compartment']) if endpoint else 'No endpoint measurements supplied'
    algebra_count=algebra.get('checks_passed','—') if algebra else '—'
    test_count=tests.get('tests_run','—')
    slash=chr(92)
    commands=h(f'python nop_audit.py audit {slash}\n  --metadata examples/metadata.json {slash}\n  --data examples/synthetic.csv {slash}\n  --out results\n\npython verify_all.py\n\npython render_report.py {slash}\n  --audit results/audit.json {slash}\n  --algebra results/algebra_receipt.json {slash}\n  --out NOP_Research_Workbench_v0_2.html')
    content=f'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>NOP Return / Memory Workbench — v0.2</title>
<style>
:root{{--ink:#213447;--muted:#596a77;--line:#d8e1e4;--teal:#127c80;--pale:#edf7f4;--paper:#f5f5f0;--amber:#875b26}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--paper);color:var(--ink);font:16px/1.6 system-ui,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif}}main{{max-width:1120px;margin:auto;padding:52px 40px 70px}}header{{border-top:5px solid var(--teal);padding-top:22px}}.eyebrow{{font-size:12px;text-transform:uppercase;letter-spacing:.13em;font-weight:750;color:var(--teal)}}h1{{font-size:clamp(31px,5vw,50px);line-height:1.12;letter-spacing:-.035em;margin:16px 0}}.lead{{font-size:21px;max-width:820px;line-height:1.5}}h2{{font-size:26px;line-height:1.25;margin:0 0 18px;letter-spacing:-.02em}}h3{{font-size:17px;margin:0 0 10px}}p{{margin:0 0 16px}}section{{margin-top:36px;padding:28px;background:white;border:1px solid var(--line);border-radius:12px}}.notice{{background:#eaf4f2;border-left:4px solid var(--teal);padding:16px 20px;margin:25px 0 0;border-radius:0 8px 8px 0}}.notice strong{{display:block}}.grid{{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin:24px 0 0}}.stat{{padding:20px 22px;background:white;border:1px solid var(--line);border-radius:10px}}.stat b{{display:block;font-size:29px;line-height:1.1;margin-bottom:8px}}.stat span{{font-size:13px;color:var(--muted)}}.pill{{display:inline-block;border:1px solid #b6d8d3;background:var(--pale);padding:3px 10px;border-radius:20px;font-size:12px;margin:0 8px 5px 0}}.two{{display:grid;grid-template-columns:1fr 1fr;gap:22px}}.math{{font:19px/1.8 Georgia,'Times New Roman',serif;background:#f5f8fa;border:1px solid #e0e7ea;padding:18px 22px;border-radius:7px;margin:15px 0;overflow-x:auto}}.math code{{font:15px/1.8 ui-monospace,SFMono-Regular,Consolas,monospace}}.muted,small,figcaption{{color:var(--muted);font-size:13px}}small,.bounds{{display:block;line-height:1.45;margin-top:5px}}.bounds{{font-size:12px;color:var(--muted)}}a{{color:#086e79;text-decoration:underline;text-underline-offset:3px}}.scroll{{overflow-x:auto;max-width:100%;border:1px solid var(--line);border-radius:7px}}table{{width:100%;border-collapse:collapse;font-size:14px}}th{{text-align:left;background:#f0f5f6;font-size:12px;letter-spacing:.02em;color:#385260}}td,th{{padding:12px 14px;border-bottom:1px solid var(--line);vertical-align:top}}tr:last-child td{{border-bottom:0}}.ledger{{min-width:920px}}.ledger td:nth-child(n+2):nth-child(-n+8){{font-variant-numeric:tabular-nums;white-space:nowrap}}.witness{{background:#eff8f4}}.hash{{font-family:ui-monospace,monospace;font-size:11px;word-break:break-all}}pre{{background:#1d3040;color:#edf5f7;padding:20px;border-radius:8px;overflow:auto;font:13px/1.7 ui-monospace,monospace}}code{{font-size:.92em}}ul,ol{{padding-left:22px;margin:12px 0 18px}}li{{margin:8px 0}}figure{{margin:18px 0 0}}figure img{{width:100%;height:auto;display:block}}figcaption{{padding:12px 5px 0}}details{{margin-top:18px;border-top:1px solid var(--line);padding-top:16px}}summary{{cursor:pointer;font-weight:650}}footer{{font-size:13px;color:var(--muted);margin-top:28px}}.rule{{font-size:24px;font-weight:650;line-height:1.4;color:#17474d}}.mono{{font-family:ui-monospace,monospace}}
@media(max-width:700px){{main{{padding:26px 15px 45px}}section{{padding:21px 17px;margin-top:22px}}.grid{{grid-template-columns:1fr;gap:9px}}.stat{{padding:15px 18px}}.stat b{{display:inline-block;font-size:23px;margin-right:12px}}.two{{grid-template-columns:1fr;gap:10px}}.lead{{font-size:18px}}.math{{font-size:17px;padding:14px}}td,th{{padding:10px}}h2{{font-size:23px}}}}
@media print{{body{{background:white;font-size:11px}}main{{max-width:none;padding:0}}section{{break-inside:avoid;padding:15px;margin-top:18px}}.grid{{grid-template-columns:repeat(3,1fr)}}details{{display:block}}.scroll{{overflow:visible}}.ledger{{min-width:0;font-size:9px}}a{{color:inherit}}header{{break-after:avoid}}}}
</style></head><body><main>
<header><div class="eyebrow">Coppalini Architecture / Research construction / v0.2</div>
<h1>Oxygen return<br>with retained state</h1>
<p class="lead">An exact tool for investigating the Normobaric Oxygen Paradox: preserve the oxygen read, recover the measured redox coordinates, and keep the preceding observations available.</p>
<span class="pill">{h(origin_label)}</span><span class="pill">Exact rational audit</span><span class="pill">Biological fit remains open</span>
<div class="notice"><strong>{h(origin_label)}</strong>{h(origin_note)}</div></header>
<div class="grid"><div class="stat"><b>{h(algebra_count)} · {h(astatus)}</b><span>Exact construction checks</span></div><div class="stat"><b>{h(test_count)} · {h(tstatus)}</b><span>Software acceptance tests</span></div><div class="stat"><b>{counts['rows']} / {counts['runs']}</b><span>Submitted records / runs</span></div></div>
<section><h2>1. The question now has a testable form</h2><p class="rule">Match present oxygen. Measure the retained state. Test the subsequent response.</p><p>The target paper proposes adaptation that persists after oxygen return. The tool represents that proposal with distinct oxygen, oxidant, scavenger and endpoint records. Its exact calculations establish what the submitted observations distinguish.</p>
<div class="two"><div><h3>Declared observation</h3><p><strong>{h(meta['oxygen_read']['kind'])}</strong><br>{h(meta['oxygen_read']['compartment'])}<br><span class="muted">{h(meta['oxygen_read']['assay'])}</span></p></div><div><h3>Endpoint in this dataset</h3><p>{endpoint_text}</p><p class="muted">HIF isoform, cell type and compartment travel with the measurement. Each causal connection remains an independently testable relation.</p></div></div>
<p class="muted">Target: <a href="https://www.mdpi.com/1422-0067/24/1/82">Salvagno et al., IJMS 24(1), 82</a>. Dataset: <code>{h(data['dataset_id'])}</code>.</p></section>
<section><h2>2. Retain both balance and magnitude</h2><div class="math">r = R/R<sub>0</sub> &nbsp; · &nbsp; a = A/A<sub>0</sub><br>q = r/a &nbsp; · &nbsp; scale² = ra &nbsp; · &nbsp; η = ½ log q<br>r = √(scale²q) &nbsp; · &nbsp; a = √(scale²/q)</div><p>R and A are specified assay readings. Normalization preserves their separate baseline references. The positive pair (q, scale²) reconstructs both indices. If r=a=2, the ratio is one while scale² is four.</p>
<p>The explicit adapter C<sub>redox</sub> = [[Φ, −1], [1, Φ]] carries these indices into the established operators H=G/√5 and S=(2Q−I)/√5:</p><div class="math">C<sub>redox</sub><sup>−1</sup> H C<sub>redox</sub> = [[0,1],[1,0]]<br>C<sub>redox</sub><sup>−1</sup> S C<sub>redox</sub> = diag(1,−1)</div><p>Mirror exchange gives q → 1/q and η → −η. Magnitude remains a separate coordinate. Observations or a declared model supply the actual biological motion; the algebra supplies its reversible representation.</p></section>
<section><h2>3. The exact adaptation result</h2><p>For the proposed law τ da/dt = r−a, constant input during each interval gives the exact update below. Rational λ is chosen directly; a biological rate has yet to be estimated.</p><div class="math">a<sub>next</sub> = λa + (1−λ)r, &nbsp; λ=e<sup>−Δ/τ</sup>, &nbsp; 0&lt;λ&lt;1<br>a<sub>d</sub> = 1+(k−1)(1−λ<sup>d</sup>)<br>a<sub>d+j</sub> = 1+(a<sub>d</sub>−1)λ<sup>j</sup><br>q<sub>d+j</sub> = 1/[1+(a<sub>d</sub>−1)λ<sup>j</sup>] &lt; 1</div><p>Starting at baseline, a pulse k&gt;1 for d intervals leaves a persistent adaptation state during finite recovery. At return the prescribed oxidant input is one. The remaining state follows from the model's declared update.</p><p class="muted">The included example uses k=2, λ=½ and four intervals: a=31/16 and q=16/31 immediately after return. Input r is an assumed oxidant drive; its conversion from oxygen and its downstream HIF effect remain unassigned.</p>{figure}</section>
<section><h2>4. Exact observation ledger</h2><p>Fractions preserve the entered data. Brackets show propagated interval bounds. A returned dry-gas read concerns that gas channel; tissue oxygen requires its own measurement. Green rows contain a returned read and a resolved difference in at least one redox index.</p><div class="scroll"><table class="ledger"><thead><tr><th>Run / sample</th><th>Event</th><th>Time · min</th><th>Oxygen · kPa</th><th>r</th><th>a</th><th>q</th><th>Scale²</th><th>Audit read</th></tr></thead><tbody>{''.join(rows_html)}</tbody></table></div>
<details><summary>Provenance and resolution notes</summary><p>Missing bounds mean a point as entered. Overlapping oxygen bounds establish compatibility with return. All run baselines are paired. This report supplies descriptive comparisons; statistical and causal estimates require the study design.</p><ul>{warnings}</ul><p>Audit snapshot hash matched its receipt: <strong>{'YES' if receipt_match else 'UNVERIFIED'}</strong>. Hashes bind the recorded files; experiment authenticity needs its own provenance.</p><div class="scroll"><table><thead><tr><th>Input or code</th><th>SHA-256</th></tr></thead><tbody>{provenance}</tbody></table></div></details></section>
<section><h2>5. The next discriminating measurements</h2><p>The preceding biological background enters here as a measurement interface: mitochondrial or cellular oxidant output, antioxidant adaptation, HIF regulation and gene-specific transcription. Each compartment and assay retains its identity. Repeated configurations and continuing events motivate the history record; biological rates are measured separately.</p><div class="scroll"><table><thead><tr><th>Relation</th><th>Evidence to collect</th><th>What can fail</th></tr></thead><tbody>
<tr><td>Present oxygen ↔ prior history</td><td>Matched tissue oxygen, exposure trace, clock-matched controls</td><td>The proposed history variable adds no held-out predictive value.</td></tr>
<tr><td>Retained redox state → HIF</td><td>Same-compartment oxidant/scavenger measures, hydroxylated HIF or PHD activity, specified HIF isoform and target transcription</td><td>The predicted time order, response direction or perturbation response fails.</td></tr>
<tr><td>Local oxygen / inflammatory alternatives</td><td>Tissue perfusion, oxygenation, NRF2 and NF-κB alongside redox measurements</td><td>A supposedly excluded intermediate explains the response.</td></tr>
<tr><td>HIF → EPO → erythropoiesis</td><td>Appropriate EPO-producing tissue, circulating EPO, later reticulocytes and Hb, relevant covariates</td><td>A within-group rise does not survive the prespecified control comparison.</td></tr>
</tbody></table></div><p class="muted">These are model-discrimination requirements derived for this tool. Exposure schedules and clinical decisions require the research team's experimental and clinical framework.</p></section>
<section><h2>6. Evidence registry</h2><p>Supporting and contrary results retain their populations, endpoints and limits. The included registry contains no imported individual measurements.</p><div class="scroll"><table><thead><tr><th>Primary source / target review</th><th>Reported result</th><th>Consequence for this tool</th></tr></thead><tbody>{source_rows}</tbody></table></div><details><summary>Source details requiring reconciliation</summary><ul>{''.join(flags)}</ul></details></section>
<section><h2>7. Run on a declared dataset</h2><p>The package contains the CSV template, metadata example, exact audit, symbolic verifier, acceptance tests, source ledger, demonstration and receipts.</p><pre>{commands}</pre><p>The audit and report use Python's standard library. Symbolic checks use SymPy; optional static figures use Matplotlib. The README specifies the complete data contract and exact adapter.</p></section>
<footer>v0.2 · 12 November 2026 · Exact construction and paired-data audit. Biological parameter identification and causal mechanism testing remain open. Framework provenance: Anthony V. Coppa, <em>Metric Mirror Symmetry</em> and <em>Infinity One Zero Lift</em>. No endorsement by the cited research teams is asserted.</footer>
</main></body></html>'''
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(content,encoding='utf8')
    return out


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--audit',type=Path,default=Path('results/audit.json'))
    ap.add_argument('--algebra',type=Path,default=Path('results/algebra_receipt.json'))
    ap.add_argument('--figure',type=Path)
    ap.add_argument('--out',type=Path,default=Path('NOP_Research_Workbench_v0_2.html'))
    args=ap.parse_args()
    print(render(args.audit,args.algebra,args.figure,args.out))
