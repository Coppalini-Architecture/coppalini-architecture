#!/usr/bin/env python3
"""Exact finite adaptation model and explicitly synthetic research fixtures.

The driving r is a normalized oxidant-assay value, not FiO2. The update
a_next = retention*a + (1-retention)*r is the exact sampled solution of
tau*da/dt = r-a for constant r, with retention=exp(-dt/tau).
Rational retention is an exact model input; it is not a fitted biological rate.
"""
from __future__ import annotations

import argparse
import csv
import json
from fractions import Fraction as F
from pathlib import Path

FIELDS = ['run_id','arm','sample_id','occurrence','time_min','is_baseline',
          'fio2','pressure_kpa','oxygen','oxygen_low','oxygen_high',
          'ros','ros_low','ros_high','scavenger','scavenger_low','scavenger_high',
          'endpoint','endpoint_low','endpoint_high','phase_event']


def adapt(a: F, r: F, retention: F) -> F:
    if a <= 0 or r <= 0 or not 0 <= retention <= 1:
        raise ValueError('Positive states and retention in [0,1] are required')
    return retention * a + (1-retention) * r


def pulse_states(level=F(2), retention=F(1,2), exposure_steps=4, recovery_steps=8):
    if level <= 1 or not 0 < retention < 1:
        raise ValueError('This finite-timescale pulse example requires level>1 and 0<retention<1')
    if exposure_steps < 1 or recovery_steps < 0:
        raise ValueError('Exposure steps>=1 and recovery steps>=0 are required')
    a = F(1)
    # Times are synthetic minutes; no timescale is estimated from a publication.
    out = [dict(stage='baseline', time=-exposure_steps, r=F(1), a=a)]
    out.append(dict(stage='exposure_onset',time=-exposure_steps,r=level,a=a))
    for step in range(exposure_steps):
        a = adapt(a, level, retention)
        out.append(dict(stage='exposure', time=step+1-exposure_steps, r=level, a=a))
    # Right after removal: the assumed fast drive returns; the slow state is continuous.
    out.append(dict(stage='return_0_plus', time=0, r=F(1), a=a))
    for step in range(1, recovery_steps+1):
        a = adapt(a, F(1), retention)
        out.append(dict(stage='recovery', time=step, r=F(1), a=a))
    return out


def row(run_id, idx, time, r, a, *, pulse=False, bounds=None, stage='sample'):
    d = {key:'' for key in FIELDS}
    d.update(run_id=run_id, arm=run_id, sample_id=f'{run_id}_{idx:02}',
             occurrence=str(idx),time_min=str(time),is_baseline='true' if idx==0 else 'false',
             fio2='0.30' if pulse else '0.21',pressure_kpa='101.325',
             ros=str(100*r),scavenger=str(200*a),phase_event=stage)
    if bounds:
        for key, val in bounds.items():
            d[key]=str(val)
    return d


def write_demo(out: Path, level=F(2), retention=F(1,2), exposure_steps=4, recovery_steps=8):
    out.mkdir(parents=True,exist_ok=True)
    states=pulse_states(level,retention,exposure_steps,recovery_steps)
    rows=[]
    for idx,state in enumerate(states):
        rows.append(row('lag',idx,state['time'],state['r'],state['a'],
                        pulse=state['stage'] in ('exposure_onset','exposure'),stage=state['stage']))
    for idx,state in enumerate(states):
        rows.append(row('air_control',idx,state['time'],F(1),F(1),stage=state['stage']))
    rows += [row('common_mode',0,-1,F(1),F(1)),row('common_mode',1,0,F(2),F(2))]
    rows += [row('uncertain',0,-1,F(1),F(1)),
             row('uncertain',1,0,F(1),F(11,10),bounds={
                 'ros_low':95,'ros_high':105,'scavenger_low':160,'scavenger_high':280})]
    with (out/'synthetic.csv').open('w',newline='',encoding='utf8') as fh:
        writer=csv.DictWriter(fh,fieldnames=FIELDS)
        writer.writeheader();writer.writerows(rows)
    meta={
        'schema_version':'0.1','dataset_id':'NOP_return_memory_synthetic_v0.1',
        'data_origin':'synthetic',
        'source_refs':['Constructed finite adaptation example; no participant data or fitted biological parameters.'],
        'oxygen_read':{'kind':'dry_inspired_po2','unit':'kPa','compartment':'delivered dry gas',
                       'assay':'nominal FiO2 times ambient pressure; tissue oxygen unmeasured'},
        'ros':{'unit':'synthetic assay unit','compartment':'synthetic cell compartment','assay':'constructed oxidant index'},
        'scavenger':{'unit':'synthetic assay unit','compartment':'synthetic cell compartment','assay':'constructed scavenging index'},
        'model':{'name':'one-state adaptation with instantaneous oxidant-drive return',
                 'retention':str(retention),'oxidant_drive_during_pulse':str(level),
                 'exposure_steps':exposure_steps,'recovery_steps':recovery_steps,
                 'step_duration_min':'1','oxygen_to_ros_transfer':'unassigned; independent synthetic input choices',
                 'hif_transfer':'unassigned; no HIF or EPO values are synthesized',
                 'bounds_semantics':'synthetic interval bounds; no probabilistic coverage claim'},
        'limitations':['Delivered-gas return does not establish tissue-oxygen return.',
                       'A recorded redox difference is a descriptive contrast, not causal identification.',
                       'Exact arithmetic preserves entered values; assay uncertainty remains explicit.']}
    (out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n',encoding='utf8')
    (out/'input_template.csv').write_text(','.join(FIELDS)+'\n',encoding='utf8')
    return len(rows)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out',type=Path,default=Path('examples'))
    ap.add_argument('--pulse',type=F,default=F(2),help='Assumed normalized oxidant drive; not oxygen dose')
    ap.add_argument('--retention',type=F,default=F(1,2))
    ap.add_argument('--exposure-steps',type=int,default=4)
    ap.add_argument('--recovery-steps',type=int,default=8)
    args=ap.parse_args()
    try:
        count=write_demo(args.out,args.pulse,args.retention,args.exposure_steps,args.recovery_steps)
    except ValueError as exc:
        ap.error(str(exc))
    print(f'Created {count} explicitly synthetic records in {args.out}')


if __name__=='__main__':
    main()
