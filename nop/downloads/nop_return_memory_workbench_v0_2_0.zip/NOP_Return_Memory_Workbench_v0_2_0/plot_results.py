#!/usr/bin/env python3
"""Create a static scientific figure from exact audit output; plotting uses floats."""
from __future__ import annotations
import argparse
import hashlib
import json
from fractions import Fraction
from pathlib import Path


def make_figure(audit: dict, run_id: str, output: Path):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    rows=[r for r in audit['rows'] if r['run_id']==run_id]
    if not rows:
        raise ValueError(f'Unknown run: {run_id}')
    def number(x): return float(Fraction(x))
    t=[number(r['time_min']) for r in rows]
    o=[number(r['inputs']['oxygen']['value']) for r in rows]
    r=[number(row['derived']['r']['value']) for row in rows]
    a=[number(row['derived']['a']['value']) for row in rows]
    q=[number(row['derived']['q']['value']) for row in rows]
    qlow=[number(row['derived']['q']['low']) for row in rows]
    qhigh=[number(row['derived']['q']['high']) for row in rows]
    plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False,
                         'axes.labelcolor':'#253344','text.color':'#253344','axes.edgecolor':'#b8c4cc',
                         'xtick.color':'#566371','ytick.color':'#566371','svg.fonttype':'none',
                         'svg.hashsalt':'NOP_return_memory_v0.1'})
    fig,axes=plt.subplots(3,1,figsize=(8.8,8.2),sharex=True,layout='constrained')
    fig.set_facecolor('#ffffff')
    origin=audit.get('data_origin','unspecified')
    fig.suptitle(f'{origin.upper()} OBSERVATIONS  /  {run_id}',fontsize=13,fontweight='bold',ha='left',x=.09)
    axes[0].plot(t,o,color='#147d83',marker='o',markersize=4,linewidth=2)
    axes[0].set_ylabel('Oxygen read\n(kPa)')
    axes[0].set_title(audit['metadata']['oxygen_read']['kind'].replace('_',' '),loc='left',fontsize=11)
    axes[1].plot(t,r,color='#bf5c24',marker='o',markersize=4,linewidth=2,label='r: oxidant index')
    axes[1].plot(t,a,color='#2672b4',marker='s',markersize=4,linewidth=2,label='a: scavenger index')
    axes[1].set_ylabel('Baseline-normalized\nassay indices')
    axes[1].legend(frameon=False,loc='upper right',fontsize=10)
    axes[1].axhline(1,color='#8a98a5',linestyle=':',linewidth=1)
    axes[2].plot(t,q,color='#263a50',marker='o',markersize=4,linewidth=2,label='q = r/a')
    if any(lo!=hi for lo,hi in zip(qlow,qhigh)):
        axes[2].fill_between(t,qlow,qhigh,color='#93c9c2',alpha=.25,label='entered interval bounds')
    axes[2].fill_between(t,q,1,where=[val<1 for val in q],color='#d6eee8',interpolate=True)
    axes[2].axhline(1,color='#8a98a5',linestyle=':',linewidth=1)
    axes[2].set_ylabel('Relative balance\nq = r/a')
    axes[2].set_xlabel('Recorded time (minutes; '+('synthetic scale' if origin=='synthetic' else 'declared dataset clock')+')')
    axes[2].legend(frameon=False,loc='upper right',fontsize=10)
    for ax in axes:
        ax.grid(axis='y',color='#e8edef',linewidth=.7)
    return_rows=[row for row in rows if row.get('extra_fields',{}).get('phase_event')=='return_0_plus']
    if return_rows:
        rt=number(return_rows[0]['time_min'])
        for ax in axes:
            ax.axvline(rt,color='#85949f',linestyle='--',linewidth=1)
        axes[0].annotate('return event',xy=(rt,axes[0].get_ylim()[1]),xytext=(6,-14),
                         textcoords='offset points',fontsize=10,color='#566371')
    output.parent.mkdir(parents=True,exist_ok=True)
    fig.savefig(output.with_suffix('.svg'),metadata={'Date':None})
    fig.savefig(output.with_suffix('.png'),dpi=180)
    canonical=json.dumps(audit,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode('utf8')
    receipt={'audit_content_sha256':hashlib.sha256(canonical).hexdigest(),
             'run_id':run_id,'data_origin':origin,
             'svg_sha256':hashlib.sha256(output.with_suffix('.svg').read_bytes()).hexdigest(),
             'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             'scope':'Display of this exact audit; plotted values use floats.'}
    output.with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n')
    plt.close(fig)
    return output.with_suffix('.svg')


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--audit',type=Path,default=Path('results/audit.json'))
    ap.add_argument('--run',default='lag')
    ap.add_argument('--out',type=Path,default=Path('figures/synthetic_return_memory.svg'))
    args=ap.parse_args()
    print(make_figure(json.loads(args.audit.read_text()),args.run,args.out))
