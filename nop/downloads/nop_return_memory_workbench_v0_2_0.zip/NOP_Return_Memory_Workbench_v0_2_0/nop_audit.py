#!/usr/bin/env python3
"""Exact, standard-library audit of paired oxygen and redox observations.

The audit preserves the submitted row order and declared measurement identities.
All calculations except the explicitly labelled eta display use Fraction.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
import os
from pathlib import Path
import re
import sys
import tempfile
from collections import Counter
from fractions import Fraction
from typing import Any


TOOL_VERSION = "0.2.0"
SCHEMA_VERSION = "0.1"
CSV_COLUMNS = (
    "run_id", "arm", "sample_id", "occurrence", "time_min", "is_baseline",
    "fio2", "pressure_kpa", "oxygen", "oxygen_low", "oxygen_high",
    "ros", "ros_low", "ros_high", "scavenger", "scavenger_low",
    "scavenger_high", "endpoint", "endpoint_low", "endpoint_high",
)
OUTPUT_NAMES = ("audit.json", "derived.csv", "receipts.json")
METRIC_NAMES = ("r", "a", "q", "scale_squared", "endpoint_normalized")
_DECIMAL = re.compile(r"[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?\Z")
_RATIONAL = re.compile(r"([+-]?[0-9]+)\s*/\s*([+-]?[0-9]+)\Z")


class AuditError(ValueError):
    """A rejected input or an output transaction that could not be completed."""


def exact(value: Fraction) -> str:
    return str(value.numerator) if value.denominator == 1 else f"{value.numerator}/{value.denominator}"


def parse_fraction(value: str, location: str) -> Fraction:
    """Accept finite decimal/scientific-decimal or integer-rational strings."""
    if not isinstance(value, str) or not value.strip():
        raise AuditError(f"{location}: a numeric value is required")
    text = value.strip()
    rational = _RATIONAL.fullmatch(text)
    try:
        if rational:
            result = Fraction(int(rational.group(1)), int(rational.group(2)))
        elif _DECIMAL.fullmatch(text):
            result = Fraction(text)
        else:
            raise ValueError("expected a finite decimal or integer fraction")
    except (ValueError, ZeroDivisionError, OverflowError) as exc:
        raise AuditError(f"{location}: invalid finite decimal/rational value {text!r}") from exc
    return result


def _required_string(obj: dict[str, Any], key: str, location: str) -> str:
    value = obj.get(key)
    if not isinstance(value, str) or not value.strip():
        raise AuditError(f"{location}.{key}: a nonempty string is required")
    return value


def _descriptor(metadata: dict[str, Any], key: str, location: str) -> dict[str, Any]:
    obj = metadata.get(key)
    if not isinstance(obj, dict):
        raise AuditError(f"{location}.{key}: an object is required")
    for field in ("unit", "compartment", "assay"):
        _required_string(obj, field, f"{location}.{key}")
    return obj


def validate_metadata(metadata: Any, location: str) -> list[dict[str, Any]]:
    if not isinstance(metadata, dict):
        raise AuditError(f"{location}: metadata must be a JSON object")
    if metadata.get("schema_version") != SCHEMA_VERSION:
        raise AuditError(f"{location}.schema_version: expected {SCHEMA_VERSION!r}")
    _required_string(metadata, "dataset_id", location)
    origin = metadata.get("data_origin")
    if origin == "extracted_summary":
        raise AuditError(f"{location}.data_origin: extracted_summary cannot establish paired sample observations")
    if origin not in ("synthetic", "measured"):
        raise AuditError(f"{location}.data_origin: expected synthetic, measured, or extracted_summary")
    refs = metadata.get("source_refs")
    if not isinstance(refs, list) or any(not isinstance(ref, str) or not ref.strip() for ref in refs):
        raise AuditError(f"{location}.source_refs: a list of nonempty source-reference strings is required (an empty list is allowed)")
    oxygen = _descriptor(metadata, "oxygen_read", location)
    if oxygen.get("kind") not in ("dry_inspired_po2", "arterial_po2", "tissue_po2"):
        raise AuditError(f"{location}.oxygen_read.kind: expected dry_inspired_po2, arterial_po2, or tissue_po2")
    if oxygen["unit"] != "kPa":
        raise AuditError(f"{location}.oxygen_read.unit: expected 'kPa'")
    ros = _descriptor(metadata, "ros", location)
    scavenger = _descriptor(metadata, "scavenger", location)
    if "endpoint" in metadata:
        endpoint = _descriptor(metadata, "endpoint", location)
        _required_string(endpoint, "name", f"{location}.endpoint")
    warnings: list[dict[str, Any]] = []
    if ros["compartment"].strip() != scavenger["compartment"].strip():
        warnings.append({
            "code": "cross_compartment_redox_composite",
            "message": "r, a, q, and scale_squared combine the separately declared ROS and scavenger compartments; they carry no inferred compartment or molecular equivalence.",
            "ros_compartment": ros["compartment"],
            "scavenger_compartment": scavenger["compartment"],
        })
    return warnings


def _measurement(row: dict[str, str], name: str, location: str, *,
                 required: bool = True, computed: Fraction | None = None,
                 allow_zero: bool = False) -> dict[str, Any] | None:
    value_text = row[name].strip()
    low_text = row[f"{name}_low"].strip()
    high_text = row[f"{name}_high"].strip()
    if bool(low_text) != bool(high_text):
        raise AuditError(f"{location}: {name}_low and {name}_high must both be present or both be empty")
    if value_text:
        value = parse_fraction(value_text, f"{location}.{name}")
        if computed is not None and value != computed:
            raise AuditError(f"{location}.{name}: supplied {exact(value)} differs from exact fio2 * pressure_kpa = {exact(computed)}")
    elif computed is not None:
        value = computed
    elif required:
        raise AuditError(f"{location}.{name}: a value is required")
    else:
        if low_text:
            raise AuditError(f"{location}.{name}: uncertainty bounds require a value")
        return None
    if value < 0 or (value == 0 and not allow_zero):
        requirement = "nonnegative" if allow_zero else "strictly positive"
        raise AuditError(f"{location}.{name}: value must be {requirement}")
    if low_text:
        low = parse_fraction(low_text, f"{location}.{name}_low")
        high = parse_fraction(high_text, f"{location}.{name}_high")
        if low < 0 or (low == 0 and not allow_zero):
            requirement = "nonnegative" if allow_zero else "strictly positive"
            raise AuditError(f"{location}.{name}_low: bound must be {requirement}")
        if not low <= value <= high:
            raise AuditError(f"{location}.{name}: required low <= value <= high")
        bounds_kind = "recorded_interval"
    else:
        low = high = value
        bounds_kind = "point_as_entered"
    return {"value": value, "low": low, "high": high, "bounds_kind": bounds_kind}


def _public_measurement(value: dict[str, Any] | None) -> dict[str, Any] | None:
    if value is None:
        return None
    return {key: exact(item) if isinstance(item, Fraction) else item for key, item in value.items()}


def _metric(value: Fraction, low: Fraction, high: Fraction, *, baseline: bool) -> dict[str, Any]:
    if high < 1:
        status = "below_baseline"
    elif low > 1:
        status = "above_baseline"
    elif low == high == 1:
        status = "baseline_exact_as_entered"
    else:
        status = "unresolved_at_recorded_bounds"
    return {
        "value": exact(value), "low": exact(low), "high": exact(high),
        "status": status,
        "bounds_basis": "baseline_self_cancellation" if baseline else "conservative_interval_arithmetic",
    }


def _ratio(current: dict[str, Any], baseline: dict[str, Any], same_sample: bool) -> dict[str, Any]:
    if same_sample:
        return _metric(Fraction(1), Fraction(1), Fraction(1), baseline=True)
    return _metric(current["value"] / baseline["value"],
                   current["low"] / baseline["high"],
                   current["high"] / baseline["low"], baseline=False)


def _eta(q: Fraction) -> float:
    if Fraction(1, 2) <= q <= 2:
        # log1p avoids cancellation for ratios close to one.
        value = 0.5 * math.log1p((q.numerator - q.denominator) / q.denominator)
    else:
        # Taking integer logs avoids conversion of an enormous ratio to float.
        value = 0.5 * (math.log(q.numerator) - math.log(q.denominator))
    if not math.isfinite(value):
        raise AuditError("eta: approximate display could not be represented as a finite float")
    return value


def _derive(current: dict[str, Any], baseline: dict[str, Any]) -> dict[str, Any]:
    same_sample = current["is_baseline"]
    readings = current["readings"]
    reference = baseline["readings"]
    r = _ratio(readings["ros"], reference["ros"], same_sample)
    a = _ratio(readings["scavenger"], reference["scavenger"], same_sample)
    R, A = readings["ros"], readings["scavenger"]
    R0, A0 = reference["ros"], reference["scavenger"]
    q_value = (R["value"] * A0["value"]) / (A["value"] * R0["value"])
    scale_value = (R["value"] * A["value"]) / (R0["value"] * A0["value"])
    if same_sample:
        q = _metric(Fraction(1), Fraction(1), Fraction(1), baseline=True)
        scale = _metric(Fraction(1), Fraction(1), Fraction(1), baseline=True)
    else:
        q = _metric(q_value, R["low"] * A0["low"] / (A["high"] * R0["high"]),
                    R["high"] * A0["high"] / (A["low"] * R0["low"]), baseline=False)
        scale = _metric(scale_value, R["low"] * A["low"] / (R0["high"] * A0["high"]),
                        R["high"] * A["high"] / (R0["low"] * A0["low"]), baseline=False)
    oxygen, oxygen0 = readings["oxygen"], reference["oxygen"]
    if oxygen["low"] == oxygen["high"] == oxygen0["low"] == oxygen0["high"]:
        oxygen_comparison = "exact_read_return"
    elif max(oxygen["low"], oxygen0["low"]) <= min(oxygen["high"], oxygen0["high"]):
        oxygen_comparison = "compatible_with_return"
    else:
        oxygen_comparison = "changed_read"
    difference = any(metric["status"] in ("above_baseline", "below_baseline") for metric in (r, a))
    if same_sample:
        relationship = "baseline_record"
    elif oxygen_comparison == "compatible_with_return":
        relationship = "return_candidate"
    elif oxygen_comparison == "changed_read":
        relationship = "changed_read"
    elif difference:
        relationship = "returned_read_with_redox_difference"
    else:
        relationship = "exact_read_return_without_resolved_redox_difference"
    endpoint = None
    if readings["endpoint"] is not None:
        if reference["endpoint"] is None:
            raise AuditError(f"{current['location']}.endpoint: run baseline {baseline['sample_id']!r} has no endpoint value")
        endpoint = _ratio(readings["endpoint"], reference["endpoint"], same_sample)
    return {
        "source_row": current["source_row"], "run_id": current["run_id"],
        "arm": current["arm"], "sample_id": current["sample_id"],
        "occurrence": exact(current["occurrence"]), "time_min": exact(current["time_min"]),
        "is_baseline": same_sample, "baseline_sample_id": baseline["sample_id"],
        "inputs": {
            "fio2": exact(current["fio2"]), "pressure_kpa": exact(current["pressure_kpa"]),
            **{name: _public_measurement(readings[name]) for name in ("oxygen", "ros", "scavenger", "endpoint")},
        },
        "derived": {"r": r, "a": a, "q": q, "scale_squared": scale, "endpoint_normalized": endpoint},
        "eta": {"approximate_float": _eta(q_value), "display_only": True},
        "oxygen_comparison": oxygen_comparison,
        "redox_difference_resolved": difference,
        "relationship": relationship,
        "extra_fields": current["extra_fields"],
    }


def _reject_json_constant(value: str) -> None:
    raise ValueError(f"nonfinite JSON constant {value!r}")


def _unique_json_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON key {key!r}")
        result[key] = value
    return result


def _read_bytes(path: Path) -> bytes:
    try:
        return path.read_bytes()
    except OSError as exc:
        raise AuditError(f"{path}: cannot read input: {exc}") from exc


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def load_and_audit(metadata_path: str | Path, data_path: str | Path) -> dict[str, Any]:
    """Validate complete inputs and return a JSON-serializable exact audit."""
    metadata_path = Path(metadata_path).resolve()
    data_path = Path(data_path).resolve()
    metadata_bytes = _read_bytes(metadata_path)
    try:
        metadata = json.loads(metadata_bytes.decode("utf-8-sig"),
                              parse_constant=_reject_json_constant,
                              object_pairs_hook=_unique_json_keys)
    except (UnicodeDecodeError, ValueError) as exc:
        raise AuditError(f"{metadata_path}: invalid JSON: {exc}") from exc
    warnings = validate_metadata(metadata, str(metadata_path))
    data_bytes = _read_bytes(data_path)
    try:
        data_text = data_bytes.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise AuditError(f"{data_path}: CSV must be UTF-8") from exc
    reader = csv.DictReader(io.StringIO(data_text, newline=""), strict=True)
    try:
        headers = reader.fieldnames
    except csv.Error as exc:
        raise AuditError(f"{data_path}: invalid CSV header: {exc}") from exc
    if not headers:
        raise AuditError(f"{data_path}: CSV header is required")
    if len(headers) != len(set(headers)):
        raise AuditError(f"{data_path}: duplicate CSV column names")
    missing = [column for column in CSV_COLUMNS if column not in headers]
    if missing:
        raise AuditError(f"{data_path}: missing CSV columns: {', '.join(missing)}")
    extras = [column for column in headers if column not in CSV_COLUMNS]
    if any(not column.strip() for column in extras):
        raise AuditError(f"{data_path}: blank CSV column names are invalid")
    if extras:
        warnings.append({"code": "extra_csv_columns_preserved", "columns": extras,
                         "message": "Additional columns are retained in each row's extra_fields and are not used for inference."})
    runs: dict[str, dict[str, Any]] = {}
    rows: list[dict[str, Any]] = []
    tied_rows: list[int] = []
    try:
        for raw in reader:
            source_row = reader.line_num
            location = f"{data_path}: CSV row {source_row}"
            if None in raw or any(value is None for value in raw.values()):
                raise AuditError(f"{location}: row has a different number of cells from the header")
            for field in ("run_id", "arm", "sample_id"):
                if not raw[field].strip():
                    raise AuditError(f"{location}.{field}: a nonempty identifier is required")
            run_id, arm, sample_id = (raw[field].strip() for field in ("run_id", "arm", "sample_id"))
            occurrence = parse_fraction(raw["occurrence"], f"{location}.occurrence")
            if occurrence.denominator != 1 or occurrence < 0:
                raise AuditError(f"{location}.occurrence: a nonnegative integer is required")
            time_min = parse_fraction(raw["time_min"], f"{location}.time_min")
            baseline_text = raw["is_baseline"].strip().lower()
            if baseline_text not in ("0", "1", "false", "true"):
                raise AuditError(f"{location}.is_baseline: expected 0, 1, false, or true")
            is_baseline = baseline_text in ("1", "true")
            if run_id not in runs:
                if not is_baseline:
                    raise AuditError(f"{location}.is_baseline: the first submitted row for run {run_id!r} must be its baseline")
            else:
                state = runs[run_id]
                if is_baseline:
                    raise AuditError(f"{location}.is_baseline: run {run_id!r} already has a baseline")
                if arm != state["arm"]:
                    raise AuditError(f"{location}.arm: a run must retain its declared arm")
                if sample_id in state["sample_ids"]:
                    raise AuditError(f"{location}.sample_id: duplicate sample_id within run {run_id!r}")
                if occurrence <= state["occurrence"]:
                    raise AuditError(f"{location}.occurrence: occurrences must strictly increase in submitted order within a run")
                if time_min < state["time_min"]:
                    raise AuditError(f"{location}.time_min: clock readings must be nondecreasing in submitted order within a run")
                if time_min == state["time_min"]:
                    tied_rows.append(source_row)
            fio2 = parse_fraction(raw["fio2"], f"{location}.fio2")
            pressure = parse_fraction(raw["pressure_kpa"], f"{location}.pressure_kpa")
            if not 0 <= fio2 <= 1:
                raise AuditError(f"{location}.fio2: fraction must lie in [0, 1]")
            if pressure <= 0:
                raise AuditError(f"{location}.pressure_kpa: pressure must be strictly positive")
            dry = metadata["oxygen_read"]["kind"] == "dry_inspired_po2"
            oxygen = _measurement(raw, "oxygen", location, computed=fio2 * pressure if dry else None,
                                  allow_zero=dry)
            ros = _measurement(raw, "ros", location)
            scavenger = _measurement(raw, "scavenger", location)
            endpoint = _measurement(raw, "endpoint", location, required=False)
            if endpoint is not None and "endpoint" not in metadata:
                raise AuditError(f"{location}.endpoint: values require a metadata.endpoint measurement declaration")
            current = {
                "source_row": source_row, "location": location, "run_id": run_id,
                "arm": arm, "sample_id": sample_id, "occurrence": occurrence,
                "time_min": time_min, "is_baseline": is_baseline,
                "fio2": fio2, "pressure_kpa": pressure,
                "readings": {"oxygen": oxygen, "ros": ros, "scavenger": scavenger, "endpoint": endpoint},
                "extra_fields": {column: raw[column] for column in extras},
            }
            if run_id not in runs:
                runs[run_id] = {"baseline": current, "arm": arm, "sample_ids": set()}
            state = runs[run_id]
            rows.append(_derive(current, state["baseline"]))
            state["sample_ids"].add(sample_id)
            state["occurrence"] = occurrence
            state["time_min"] = time_min
    except csv.Error as exc:
        raise AuditError(f"{data_path}: CSV row {reader.line_num}: invalid CSV: {exc}") from exc
    if not rows:
        raise AuditError(f"{data_path}: at least one data row is required")
    if tied_rows:
        warnings.append({
            "code": "tied_clock_readings_ordered_by_occurrence", "source_rows": tied_rows,
            "message": "Distinct occurrences share a recorded clock reading; submitted occurrence order is retained. Ties may represent finite clock resolution or left/right jump events. No derivative is inferred from tied timestamps.",
        })
    if len(rows) == len(runs):
        warnings.append({"code": "no_followup_rows", "message": "The input contains baseline records only; there are no paired follow-up comparisons."})
    code_path = Path(__file__).resolve()
    code_bytes = _read_bytes(code_path)
    counts = {
        "rows": len(rows), "runs": len(runs), "baselines": len(runs),
        "followup_rows": len(rows) - len(runs),
        "endpoint_rows": sum(row["inputs"]["endpoint"] is not None for row in rows),
        "tied_clock_rows": len(tied_rows), "warnings": len(warnings),
        "relationships": dict(sorted(Counter(row["relationship"] for row in rows).items())),
    }
    return {
        "schema_version": SCHEMA_VERSION, "tool_version": TOOL_VERSION,
        "dataset_id": metadata["dataset_id"], "data_origin": metadata["data_origin"],
        "metadata": metadata, "counts": counts, "warnings": warnings,
        "provenance": {
            "metadata": {"path": str(metadata_path), "sha256": _sha256(metadata_bytes)},
            "data": {"path": str(data_path), "sha256": _sha256(data_bytes)},
            "code": {"path": str(code_path), "sha256": _sha256(code_bytes), "version": TOOL_VERSION},
        },
        "interpretation": {
            "row_order": "submitted order retained; runs may interleave; no sorting",
            "baseline": "one first record per run; all ratios use that same run baseline",
            "bounds": "Missing bounds denote a point as entered, not biological certainty. Propagated intervals are conservative; baseline self-ratios cancel exactly.",
            "oxygen": "Comparisons concern the declared oxygen read, compartment, and assay. dry_inspired_po2 is the nominal dry-gas proxy fio2 * pressure_kpa.",
            "scope": "Arithmetic paired-data audit. No inferred tissue, assay, HIF isoform, causal mechanism, or clinical equivalence; no fitted model or derivative from tied clock readings.",
            "endpoint": "Optional endpoint normalization retains the single declared endpoint and the same run baseline; no causal attribution.",
            "eta": "Approximate float display of 0.5 * log(q); exact classifications use rational bounds.",
        },
        "rows": rows,
    }


def _json_bytes(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False) + "\n").encode("utf-8")


def _derived_csv_bytes(report: dict[str, Any]) -> bytes:
    columns = ["source_row", "run_id", "arm", "sample_id", "occurrence", "time_min", "is_baseline",
               "baseline_sample_id", "fio2", "pressure_kpa"]
    for name in ("oxygen", "ros", "scavenger", "endpoint"):
        columns.extend((name, f"{name}_low", f"{name}_high", f"{name}_bounds_kind"))
    for name in METRIC_NAMES:
        columns.extend((name, f"{name}_low", f"{name}_high", f"{name}_status"))
    columns.extend(("eta_approximate_display_only", "oxygen_comparison", "redox_difference_resolved",
                    "relationship", "extra_fields_json"))
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=columns, lineterminator="\n")
    writer.writeheader()
    for row in report["rows"]:
        flat = {key: row[key] for key in ("source_row", "run_id", "arm", "sample_id", "occurrence",
                                        "time_min", "baseline_sample_id")}
        flat["is_baseline"] = "1" if row["is_baseline"] else "0"
        flat.update({key: row["inputs"][key] for key in ("fio2", "pressure_kpa")})
        for name in ("oxygen", "ros", "scavenger", "endpoint"):
            reading = row["inputs"][name]
            if reading is not None:
                flat[name] = reading["value"]
                for field in ("low", "high", "bounds_kind"):
                    flat[f"{name}_{field}"] = reading[field]
        for name in METRIC_NAMES:
            metric = row["derived"][name]
            if metric is not None:
                flat[name] = metric["value"]
                for field in ("low", "high", "status"):
                    flat[f"{name}_{field}"] = metric[field]
        flat["eta_approximate_display_only"] = repr(row["eta"]["approximate_float"])
        flat["oxygen_comparison"] = row["oxygen_comparison"]
        flat["redox_difference_resolved"] = "1" if row["redox_difference_resolved"] else "0"
        flat["relationship"] = row["relationship"]
        flat["extra_fields_json"] = json.dumps(row["extra_fields"], ensure_ascii=False, sort_keys=True)
        writer.writerow(flat)
    return stream.getvalue().encode("utf-8")


def write_outputs(report: dict[str, Any], out_dir: str | Path) -> dict[str, str]:
    """Stage all outputs, then commit them together with rollback on write errors."""
    out = Path(out_dir).absolute()
    audit_bytes = _json_bytes(report)
    derived_bytes = _derived_csv_bytes(report)
    receipt = {
        "schema_version": SCHEMA_VERSION, "tool_version": TOOL_VERSION,
        "dataset_id": report["dataset_id"], "data_origin": report["data_origin"],
        "status": "validated_paired_data", "counts": report["counts"],
        "provenance": report["provenance"],
        "output_sha256": {"audit.json": _sha256(audit_bytes), "derived.csv": _sha256(derived_bytes)},
        "scope": "Input and code identity, input validation, exact arithmetic, and output identity. Receipt hashes do not certify a biological mechanism.",
    }
    payloads = {"audit.json": audit_bytes, "derived.csv": derived_bytes, "receipts.json": _json_bytes(receipt)}
    try:
        if out.is_symlink() or (out.exists() and not out.is_dir()):
            raise AuditError(f"{out}: output path must be a directory, not a symlink or file")
        for name in OUTPUT_NAMES:
            target = out / name
            if target.is_symlink() or (target.exists() and not target.is_file()):
                raise AuditError(f"{target}: output target must be a regular file or absent")
            if any(target.resolve() == Path(info["path"]).resolve() for info in report["provenance"].values()):
                raise AuditError(f"{target}: output would overwrite an input or the audit code")
        out.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix=".nop-audit-stage-", dir=out.parent) as stage_name:
            stage = Path(stage_name)
            for name, payload in payloads.items():
                (stage / name).write_bytes(payload)
            created_out = not out.exists()
            if created_out:
                os.replace(stage, out)
            else:
                with tempfile.TemporaryDirectory(prefix=".nop-audit-backup-", dir=out.parent) as backup_name:
                    backup = Path(backup_name)
                    saved: list[str] = []
                    installed: list[str] = []
                    try:
                        for name in OUTPUT_NAMES:
                            if (out / name).exists():
                                os.replace(out / name, backup / name)
                                saved.append(name)
                        for name in OUTPUT_NAMES:
                            os.replace(stage / name, out / name)
                            installed.append(name)
                    except BaseException:
                        for name in installed:
                            (out / name).unlink()
                        for name in saved:
                            os.replace(backup / name, out / name)
                        raise
    except OSError as exc:
        raise AuditError(f"{out}: output transaction failed: {exc}") from exc
    return {name: str(out / name) for name in OUTPUT_NAMES}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--version", action="version", version=TOOL_VERSION)
    subparsers = parser.add_subparsers(dest="command", required=True)
    audit_parser = subparsers.add_parser("audit", help="audit paired CSV observations against exact run baselines")
    audit_parser.add_argument("--metadata", required=True, type=Path)
    audit_parser.add_argument("--data", required=True, type=Path)
    audit_parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args(argv)
    try:
        report = load_and_audit(args.metadata, args.data)
        paths = write_outputs(report, args.out)
    except (AuditError, OSError) as exc:
        print(f"audit error: {exc}", file=sys.stderr)
        return 2
    print(json.dumps({"status": "complete", "dataset_id": report["dataset_id"],
                      "counts": report["counts"], "outputs": paths}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
