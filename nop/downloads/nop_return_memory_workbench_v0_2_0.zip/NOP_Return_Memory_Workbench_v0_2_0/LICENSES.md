# Release licenses

Copyright (c) 2026 Anthony Vito Coppa.

The original software in this release — Python and JavaScript source, browser HTML/CSS, verification scripts, and synthetic input fixtures — is licensed under the MIT License, reproduced in `LICENSES/MIT.txt`.

The original manual, research briefing, formal note and their sources, empirical reference map, generated research report, explanatory figures, and prose documentation are licensed under the Creative Commons Attribution 4.0 International License (CC BY 4.0): https://creativecommons.org/licenses/by/4.0/ . Legal terms: https://creativecommons.org/licenses/by/4.0/legalcode . Attribution: Anthony Vito Coppa, *NOP Return / Memory Workbench*, version 0.2.0, Coppalini Architecture.

This grant covers the original material in this package. Cited third-party articles, protocols, and external software retain their own rights and licenses. Links and bibliographic references identify those materials; their full texts are not included. A later contributed empirical dataset requires its own rights and provenance declaration.

The release metadata declares both licenses and this file assigns each to its component. The licensing proposal becomes the public release terms when the author approves publication of this candidate.
