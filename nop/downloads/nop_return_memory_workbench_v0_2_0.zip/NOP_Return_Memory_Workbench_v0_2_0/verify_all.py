#!/usr/bin/env python3
"""Run the construction checks and measurement-contract tests; save actual receipts."""
from __future__ import annotations
import hashlib
import io
import json
import platform
import subprocess
import unittest
from pathlib import Path
from verify_algebra import verify

ROOT=Path(__file__).resolve().parent


def main():
    results=ROOT/'results'
    results.mkdir(exist_ok=True)
    algebra=verify()
    (results/'algebra_receipt.json').write_text(json.dumps(algebra,indent=2)+'\n')
    suite=unittest.defaultTestLoader.discover(str(ROOT/'tests'),pattern='test_*.py')
    def leaves(group):
        for item in group:
            if isinstance(item, unittest.TestSuite):
                yield from leaves(item)
            else:
                yield item
    test_ids=[test.id() for test in leaves(suite)]
    output=io.StringIO()
    result=unittest.TextTestRunner(stream=output,verbosity=2).run(suite)
    (results/'audit_tests.txt').write_text(output.getvalue(),encoding='utf8')
    receipt={'status':'PASS' if result.wasSuccessful() else 'FAIL',
             'tests_run':result.testsRun,'failures':len(result.failures),
             'errors':len(result.errors),'skipped':len(result.skipped),
             'python':platform.python_version(),
             'node':subprocess.run(['node','--version'],capture_output=True,text=True,check=True).stdout.strip(),
             'scope':'Measurement-contract acceptance and browser/Python exact parity tests; synthetic test data. UI interaction is checked separately.',
             'suite_counts':{'measurement_contract':sum('test_audit.' in name for name in test_ids),
                             'browser_python_parity':sum('test_web_parity.' in name for name in test_ids)},
             'test_ids':test_ids,
             'code_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
                            for p in [ROOT/'nop_audit.py',ROOT/'tests/test_audit.py',ROOT/'tests/test_web_parity.py',ROOT/'web/kernel.js',ROOT/'web/demo.js',Path(__file__)]}}
    (results/'audit_test_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'algebra_checks':algebra['checks_passed'],**receipt},indent=2))
    return 0 if result.wasSuccessful() else 1


if __name__=='__main__':
    raise SystemExit(main())
