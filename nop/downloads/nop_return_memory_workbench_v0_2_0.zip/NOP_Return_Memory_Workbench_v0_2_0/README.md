# NOP Return / Memory Workbench — v0.2

An exact research audit for the Normobaric Oxygen Paradox, carrying the Metric Mirror Symmetry / Infinity One Zero Lift distinction between a returned readout and a retained state into a declared assay interface.

**Research question:** after an oxygen readout returns, what measured biochemical information remains different, and which subsequent response does that information predict?

Version 0.2.0 supplies a browser edition, a user manual, a formal proof note, an empirical reference map, executable arithmetic, an explicit coordinate adapter, a sampled adaptation model, a measurement contract, and a source ledger. The included observations are **synthetic**. Human kinetic constants, the oxygen-to-ROS transfer, and the redox-to-HIF response law remain unassigned.

## Browser edition

Open `web/index.html` or the website instrument. Use **Load synthetic demo**, or select a metadata JSON and paired-observations CSV, then **Validate & audit**. The page calculates locally, retains exact rational results, and exports JSON, CSV, and an input-identity receipt. See `web/README.md` for browser limits and parity verification. The PDF manual, research briefing, formal note, and empirical reference map are in `docs/`.

## Run

Python 3.10 or later is sufficient for the audit, model, and HTML report. SymPy is needed only for symbolic verification; the supplied receipt was generated with Python 3.12.14 and SymPy 1.14.0.

```bash
python model.py --out examples
python nop_audit.py audit --metadata examples/metadata.json --data examples/synthetic.csv --out results
python verify_all.py
python render_report.py --audit results/audit.json --algebra results/algebra_receipt.json --out NOP_Research_Workbench_v0_2.html
```

For a new dataset, copy the CSV header in `examples/input_template.csv` and the metadata structure. Give it a new dataset ID, declare its origin, and replace the synthetic assay descriptions with the actual methods. Run the same audit command with the new paths. Keep one assay definition and one endpoint definition per dataset; use separate datasets for another tissue, assay, or HIF isoform.

The report generator creates a self-contained HTML analysis report. It uses the supplied audit, includes its source receipt, and makes no network calls. The Python audit exports exact results to JSON and CSV for downstream statistical analysis.

To include the optional static figure, run `python plot_results.py --audit results/audit.json --run lag --out figures/synthetic_return_memory.svg`, then add `--figure figures/synthetic_return_memory.svg` to the report command. For a new dataset choose its run ID and a new output name. The figure's sidecar receipt binds it to the audited data; the renderer rejects a stale or changed figure.

## 1. The closed construction

Let R and A be positive readings from a specified oxidant assay and a specified scavenger assay. Their paired baseline readings are R0 and A0. Define

    r = R/R0
    a = A/A0
    q = r/a
    scale_squared = r*a
    eta = (1/2)*log(q)

These are **baseline-normalized assay indices**. The raw assays can have different units. A ratio of normalized indices carries their relative changes; it does not become a stoichiometric chemical balance or a redox potential. GSH concentration is one possible proxy and requires its own metadata; it does not automatically measure total scavenging capacity. Assay offsets and background subtraction need recorded calibration.

Both q and scale_squared are retained. On the positive domain they reconstruct the two indices:

    r = sqrt(scale_squared*q)
    a = sqrt(scale_squared/q)

The example r=a=2 has q=1 and scale_squared=4. Its balance has returned while both indices differ from baseline. This is the reason for retaining magnitude alongside contrast.

### Exact mirror map

Preserve the established matrices

    Q = [[1,1],[1,0]]
    C1 = [[0,-1],[1,0]]
    G = [[-2,1],[1,2]] = [C1,Q]
    H = G/sqrt(5)
    S = (2Q-I)/sqrt(5)
    Phi = (1+sqrt(5))/2

Declare the new assay adapter

    C_redox = [[Phi,-1],[1,Phi]]
    v = C_redox * [r,a]^T.

Then

    C_redox^-1 H C_redox = [[0,1],[1,0]]
    C_redox^-1 S C_redox = diag(1,-1).

The mirror exchanges the assay coordinates, giving q -> 1/q and eta -> -eta. The axial family L_s=exp(sS) changes eta by s. With zeta=sqrt(ra), any positive pair has the representation

    v = zeta * L_eta * C_redox * [1,1]^T.

For two observations, the exact change factors into a magnitude change and an axial change:

    v_next = (zeta_next/zeta) * L_(eta_next-eta) * v.

This makes the correspondence to Metric Mirror Symmetry explicit and invertible. The biological motion is supplied by observations or a declared dynamical model. The signed form satisfies

    C_redox^T G C_redox = sqrt(5)*(Phi+2)*[[0,1],[1,0]].

The model generally changes ra; no conservation of that form is imposed on chemistry. The mathematical step log(Phi) supplies no measured biological timescale.

### Exact return / memory theorem

Retain the proposed adaptation equation

    tau * da/dt = r-a.

For constant r during an interval of length Delta, its exact sampled solution is

    a_next = lambda*a + (1-lambda)*r,
    lambda = exp(-Delta/tau).

Choose a rational lambda directly for exact finite arithmetic. For 0<lambda<1 and a constant pulse r=k>1 lasting d intervals, starting from a=1,

    a_d = 1+(k-1)*(1-lambda^d).

Immediately after the prescribed oxidant drive returns to one, and after j further recovery intervals,

    r = 1,
    a_(d+j) = 1+(a_d-1)*lambda^j,
    q_(d+j) = 1 / [1+(a_d-1)*lambda^j] < 1.

The strict inequality holds at every finite j under those hypotheses. That is the exact model result: the fast read has returned while the slow state retains the preceding pulse. For k=2, lambda=1/2, d=4, the return value is a=31/16, q=16/31. One recovery interval later, a=47/32 and q=32/47.

The normalized r drive is an assumed oxidant input. The synthetic gas-exposure trace is a separately declared input; there is no fitted oxygen-to-ROS conversion. The synthetic minute scale is arbitrary. Combining m equal intervals at constant input requires lambda^m. Changing the interval while keeping lambda fixed changes the model.

At an input jump, the exposure-end observation at time 0 and the immediately returned observation at time 0 have distinct occurrence addresses. Their order is retained even though their visible clock values agree. The slow state is continuous at that jump.

### What the occurrence record retains

The audit preserves every input row in its original order, with run ID, sample ID, occurrence address, visible time, baseline reference, metadata, and hashes. Current state and count alone do not invert an arbitrary history. For lambda=1/2, the two driving sequences (2,2) and (3,3/2) both leave a=7/4 after two intervals; returning both drives to one gives the same current state. Their raw input records remain distinct.

Version 0.2.0 produces a hashed snapshot. The hashes witness file integrity relative to that snapshot; they do not authenticate an experiment or implement an externally anchored append-only service. Retain the original input and all later snapshots when extending a study.

## 2. Measurement contract

### Metadata

| Field | Required meaning |
|---|---|
| `schema_version` | `0.1` |
| `dataset_id` | Stable identifier chosen by the researcher |
| `data_origin` | `synthetic`, `measured`, or `extracted_summary`; summary data are rejected for paired individual analysis |
| `source_refs` | Provenance references for the supplied data |
| `oxygen_read.kind` | `dry_inspired_po2`, `arterial_po2`, or `tissue_po2` |
| `oxygen_read.unit` | `kPa` in this version |
| `oxygen_read.compartment`, `assay` | Exact location and measurement or calculation method |
| `ros`, `scavenger` | Each has `unit`, `compartment`, and `assay` |
| `endpoint` | Optional object with `name`, `unit`, `compartment`, and `assay`; spell out HIF isoform when applicable |

Keep organism, tissue preparation, clock-time origin, instrument, calibration, batch, units before conversion, exposure delivery, and other study covariates in additional metadata. The audit preserves them. Required-field validation establishes structural completeness; the operator remains responsible for the accuracy of supplied metadata.

### CSV fields

| Fields | Contract |
|---|---|
| `run_id`, `arm`, `sample_id` | Nonempty identifiers; sample IDs unique within run; one run owns one paired baseline |
| `occurrence` | Strictly increasing integer within run |
| `time_min` | Nondecreasing minutes on the run's declared clock; tied clocks are flagged and ordered by occurrence |
| `is_baseline` | Exactly one baseline at the start of each run |
| `fio2` | Inspired oxygen fraction in [0,1] |
| `pressure_kpa` | Positive absolute ambient pressure |
| `oxygen`, `oxygen_low`, `oxygen_high` | The declared oxygen channel and optional paired interval bounds |
| `ros`, `ros_low`, `ros_high` | Positive oxidant assay and optional paired bounds |
| `scavenger`, `scavenger_low`, `scavenger_high` | Positive scavenger assay and optional paired bounds |
| `endpoint`, `endpoint_low`, `endpoint_high` | Optional positive endpoint under its own metadata |

The exact unit conversions are 1 ATA=101.325 kPa and 1 bar=100 kPa. Preserve the reported pressure unit before conversion. A source that alternates bar and ATA requires resolution or a documented uncertainty range.

For `dry_inspired_po2`, oxygen is computed as FiO2*pressure_kpa. This is nominal dry-gas partial pressure. Humidification, alveolar gas exchange, arterial measurements, and tissue oxygenation retain their own channels and models. If oxygen is also supplied for this kind, it must agree with the exact product. A value FiO2=1.4 is rejected; pure oxygen at 1.4 ATA has FiO2=1 and pressure=141.855 kPa.

Decimal and rational entries are accepted. Logarithms are approximate display values; exact decisions use fractions and interval comparisons. Optional intervals must have both bounds and contain the value. With no bounds, a value is exact **as entered**. That status conveys no measurement precision beyond what was supplied. Intervals are conservative bounds, not confidence levels or significance tests. Do not insert an arbitrary positive epsilon for censored, zero, or below-detection observations; that needs a separately specified measurement model.

### Returned reads and resolved differences

- `exact_read_return`: the entered oxygen intervals are equal point values.
- `compatible_with_return`: the oxygen intervals overlap. The overlap establishes compatibility only.
- `changed_read`: the oxygen intervals are disjoint.
- `returned_read_with_redox_difference`: an exact entered oxygen return accompanies an r or a interval excluding one.
- `return_candidate`: oxygen intervals overlap; `redox_difference_resolved` separately records whether r or a excludes its baseline.

Each q and scale-squared interval is also classified against one. A baseline divided by itself cancels exactly; later comparisons retain uncertainty in both current and baseline samples. Interval dependence can make bounds conservative. A cross-compartment composite receives a warning. No causal inference, cross-subject significance test, or clinical effect estimate is generated.

## 3. The empirical question this enables

### Placement of the DNA and mitochondrial background

The biochemical interface assigns mitochondrial respiration and its measured oxidant outputs to a specified input compartment; antioxidant assays carry the adaptation coordinate; HIF/PHD measurements and gene-specific transcription carry downstream response. A mitochondrial assay, whole-cell assay, serum assay, nuclear protein measurement and transcript remain separately identified. ATP synthesis and DNA copying motivated the distinction between recurring configuration and ongoing events; their motor symmetries and rates are not inserted as oxygen-response parameters.

For a concrete experimental connection, Chandel et al. tested mitochondrial dependence of hypoxia-induced gene expression in Hep3B cells, including mitochondrial-DNA-depleted cells and ROS measurements. That experiment supports a specific mitochondria/redox/transcription link under its conditions. Its signaling direction must be assessed for the NOP setting. [Primary study, 1998](https://pmc.ncbi.nlm.nih.gov/articles/PMC21706/).

The linked review proposes delayed recovery of scavenging capacity as one explanation of a hypoxia-like response after oxygen return. It explicitly leaves the ROS–HIF mechanism and exposure timing unresolved. See [Salvagno et al., 2023](https://www.mdpi.com/1422-0067/24/1/82).

An informative comparison fixes present, compartment-specific oxygen and compares different recorded exposure histories. Measure the proposed retained state before interpreting the later outcome. The exact audit supplies the state and provenance layer for that comparison.

| Candidate relation | Measurements needed to discriminate it |
|---|---|
| Oxygen return with retained adaptation | Current tissue oxygen, prior exposure trace, same-compartment oxidant and antioxidant measurements, uncertainty, matched time controls |
| Redox state changes PHD–HIF regulation | PHD activity or hydroxylated HIF, specified HIF isoform, nuclear abundance and/or activity, target transcription |
| Inflammatory/oxidative signaling contributes | NRF2, NF-κB, specified ROS and damage assays, response timing |
| Local oxygen shortage contributes | Relevant tissue oxygen and perfusion rather than delivered gas alone |
| Circulating EPO and blood-cell outcomes | Appropriate EPO-producing compartment, circulating EPO, later reticulocytes/Hb, renal status, blood loss, fluids, iron, transfusions, shared oxygen exposures, clock-matched controls |

PBMC HIF-1α, renal HIF-2α, serum EPO, reticulocytes, and hemoglobin remain separate endpoints. Primary genetic work supports a renal PHD/HIF-2/EPO pathway in mice; transport to a human NOP mechanism needs its own evidence. [Kobayashi et al., 2016](https://www.jci.org/articles/view/83551).

For a next empirical version, prespecify an outcome and compare a current-oxygen model with a history-dependent model on held-out subjects or sequences. Fit the HIF observation law separately, including its sign and lag. Retained adaptation gains mechanistic support when its measured time course precedes and predicts the response, and when appropriate perturbations discriminate it from competing explanations. An absence of predictive improvement or a failed time-order prediction counts against the specified model.

`sources.json` records supporting and contrary studies, source discrepancies, and access limits. Public aggregate summaries support this registry. Paired parameter estimation requires the subject-level records; no such records are bundled or reconstructed from figures.

## 4. Current verification scope

`verify_algebra.py` verifies the root matrices, the new assay adapter, recovery closed forms, rational examples, unit invariance, reconstruction, and negative controls against false conservation or history-recovery claims. `tests/test_audit.py` exercises the measurement contract, uncertainty, and provenance behavior; `tests/test_web_parity.py` verifies exact browser/Python parity and requires Node.js. The combined verification command requires SymPy and Node.js. `results/` contains the actual generated receipts.

The current delivered layer is an exact construction and data audit. A biological model fit, causal mechanism identification, validated oxygen-exposure optimization, and clinical decision support remain outside this version's completed work. This package contains no new Lean certificate.

### Background provenance

- Anthony V. Coppa, *Metric Mirror Symmetry: Riemann's i Machine*, 9 September 2026, sections 1–7: [Zenodo record](https://doi.org/10.5281/zenodo.23478606). Root matrices and operator offices retained.
- Anthony V. Coppa, *Infinity One Zero Lift: The Normal Form of Projective Memory*, working v0.1, 11 November 2026. Retained state, readout, and occurrence are distinguished; no eight-coordinate biological model is assumed here.
- This v0.2 package constructs the explicit positive assay adapter and audit described above. It carries no claimed endorsement by the authors of the NOP papers.

## Release documents and rights

`docs/User_Manual.pdf` specifies browser and CLI use; `docs/Research_Briefing.pdf` states the research question and empirical route; `docs/Formal_Note.pdf` contains the proofs. The empirical reference map supplies 68 individually identified observables, 15 sources, and 19 retained source corrections. `results/browser_ui_receipt.json` records the actual browser interaction checks and downloaded-file comparisons.

The source archive includes a release manifest and SHA-256 checksums. `LICENSES.md` assigns the proposed MIT code license and CC BY 4.0 documentation license for the author-reviewed public release. `zenodo/record-metadata.json` and `zenodo/description.html` preserve the exact prepared deposit description; no DOI is assigned in this candidate.
