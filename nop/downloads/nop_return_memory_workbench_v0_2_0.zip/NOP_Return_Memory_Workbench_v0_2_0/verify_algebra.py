#!/usr/bin/env python3
"""Symbolic and exact rational checks for the NOP Return / Memory Workbench.

Scope: mathematical construction and implementation. No biological fit,
clinical efficacy result, Lean certificate, or HIF observation law is asserted.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import platform
from fractions import Fraction as F
from pathlib import Path
import sympy as sp
from model import adapt, pulse_states


def verify():
    checks=[]
    def check(name, condition, scope):
        passed=bool(condition)
        checks.append({'name':name,'passed':passed,'scope':scope})
        if not passed:
            raise AssertionError(name)
    def zero(x):
        if isinstance(x,sp.MatrixBase):
            return all(sp.simplify(e)==0 for e in x)
        return sp.simplify(x)==0
    I=sp.eye(2); Q=sp.Matrix([[1,1],[1,0]])
    C1=sp.Matrix([[0,-1],[1,0]])
    G=sp.Matrix([[-2,1],[1,2]]); H=G/sp.sqrt(5)
    S=(2*Q-I)/sp.sqrt(5); phi=(1+sp.sqrt(5))/2
    C=sp.Matrix([[phi,-1],[1,phi]])
    J=sp.Matrix([[0,1],[1,0]])
    D=sp.diag(1,-1)
    check('root_G_commutator',zero(G-(C1*Q-Q*C1)),'retained root algebra')
    check('root_Q_polynomial',zero(Q*Q-Q-I),'retained root algebra')
    check('mirror_involution',zero(H*H-I),'retained root algebra')
    check('axial_involution',zero(S*S-I),'retained root algebra')
    check('mirror_axial_anticommutation',zero(H*S+S*H),'retained root algebra')
    check('adapter_invertible',sp.simplify(C.det())>0,'new explicit redox adapter')
    check('adapter_S_diagonal',zero(S*C-C*D),'new explicit redox adapter')
    check('adapter_H_exchange',zero(H*C-C*J),'new explicit redox adapter')
    check('signed_metric_pullback',zero(C.T*G*C-sp.sqrt(5)*(phi+2)*J),'new explicit redox adapter')
    Lax=(Q+2*I)/sp.sqrt(5)
    check('golden_step_diagonal',zero(Lax*C-C*sp.diag(phi,1/phi)),'retained step in new coordinates')
    s=sp.symbols('s',real=True)
    L=sp.cosh(s)*I+sp.sinh(s)*S
    Linv=sp.cosh(s)*I-sp.sinh(s)*S
    check('mirror_reverses_axial_flow',zero(H*L*H-Linv),'all real s')
    check('axial_preserves_G',zero(L.T*G*L-G),'all real s')
    r,a,t=sp.symbols('r a t',positive=True)
    v=C*sp.Matrix([r,a])
    check('physical_state_pullback',zero((v.T*G*v)[0]-2*sp.sqrt(5)*(phi+2)*r*a),'positive assay indices, signed form')
    check('ratio_mirror_inversion',zero((a/r)*(r/a)-1),'positive assay indices')
    check('rational_boost_ratio',zero(((t*r)/(a/t))/(r/a)-t*t),'positive rational boost representative')
    check('rational_boost_product',zero((t*r)*(a/t)-r*a),'coordinate boost only')
    q=r/a; p=r*a
    check('coordinate_reconstruction_r',zero(sp.sqrt(p*q)-r),'positive branch')
    check('coordinate_reconstruction_a',zero(sp.sqrt(p/q)-a),'positive branch')
    uR,uA,R0,A0=sp.symbols('uR uA R0 A0',positive=True)
    check('ratio_unit_invariance',zero(((uR*r)/(uR*R0))/((uA*a)/(uA*A0))-(r/R0)/(a/A0)),'multiplicative unit changes')
    check('product_unit_invariance',zero(((uR*r)/(uR*R0))*((uA*a)/(uA*A0))-(r/R0)*(a/A0)),'multiplicative unit changes')
    lam,k=sp.symbols('lambda k',positive=True)
    n=sp.symbols('n',integer=True,nonnegative=True)
    A=1+(k-1)*(1-lam**n)
    check('pulse_closed_form_base',zero(A.subs(n,0)-1),'adaptation model')
    check('pulse_closed_form_recurrence',zero(A.subs(n,n+1)-(lam*A+(1-lam)*k)),'adaptation model')
    b=sp.symbols('b',positive=True)
    recovery=1+(b-1)*lam**n
    check('recovery_closed_form_base',zero(recovery.subs(n,0)-b),'adaptation model')
    check('recovery_closed_form_recurrence',zero(recovery.subs(n,n+1)-(lam*recovery+(1-lam))),'adaptation model')
    check('baseline_fixed',adapt(F(1),F(1),F(2,3))==1,'exact finite example')
    try:
        pulse_states(retention=F(0))
        rejects_zero=False
    except ValueError:
        rejects_zero=True
    check('finite_timescale_rejects_zero_retention',rejects_zero,'finite positive tau domain')
    fixture=pulse_states()
    returned=next(x for x in fixture if x['stage']=='return_0_plus')
    check('pulse_four_intervals_31_over_16',returned['a']==F(31,16),'synthetic fixture')
    check('returned_ratio_16_over_31',returned['r']/returned['a']==F(16,31),'synthetic fixture')
    first=next(x for x in fixture if x['stage']=='recovery')
    check('first_recovery_47_over_32',first['a']==F(47,32),'synthetic fixture')
    check('positive_states_in_fixture',all(x['r']>0 and x['a']>0 for x in fixture),'synthetic fixture')
    check('finite_recovery_below_ratio_one',all(x['r']/x['a']<1 for x in fixture if x['stage'] in ('return_0_plus','recovery')),'synthetic fixture')
    check('constant_input_interval_composition',
          adapt(adapt(F(7,5),F(2),F(1,3)),F(2),F(1,3))==adapt(F(7,5),F(2),F(1,9)),
          'same input, combined retention equals product')
    def end(inputs):
        state=F(1)
        for inp in inputs: state=adapt(state,inp,F(1,2))
        return state
    check('history_collision_retains_record_requirement',
          end([F(2),F(2)])==end([F(3),F(3,2)])==F(7,4),
          'different two-interval histories; identical state on return')
    check('ratio_alone_loses_common_mode',F(2)/F(2)==1 and F(2)*F(2)==4,'coordinate completeness')
    # An exact interval can straddle baseline; point sign alone must not decide.
    qlow=F(95,100)/F(280,200); qhigh=F(105,100)/F(160,200)
    check('uncertainty_fixture_contains_one',qlow<=1<=qhigh,'entered bounds, no coverage claim')
    # A first-order adaptation model is not reversed by exchanging assay roles.
    lam=F(1,2);oldr=F(2);olda=F(1)
    forward=(oldr,adapt(olda,oldr,lam))
    swapped_forward=(olda,adapt(oldr,olda,lam))
    check('biochemical_update_is_not_assumed_mirror_symmetry',
          (forward[1],forward[0])!=swapped_forward,'negative control for false dynamics claim')
    return {'schema_version':'0.1','tool_version':'0.2.0','status':'PASS',
            'scope':'Exact construction checks; biological mechanism and parameter identification remain open.',
            'python':platform.python_version(),'sympy':sp.__version__,
            'code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'dependency_sha256':{'model.py':hashlib.sha256(Path(__file__).with_name('model.py').read_bytes()).hexdigest()},
            'checks_passed':len(checks),'checks':checks}


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out',type=Path,default=Path('results/algebra_receipt.json'))
    args=ap.parse_args()
    result=verify()
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
    print(f"PASS: {result['checks_passed']} exact construction checks. Receipt: {args.out}")
