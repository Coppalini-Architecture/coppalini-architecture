"""Cross-language acceptance checks against the authoritative Python audit."""
import copy
import csv
import io
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import nop_audit

NODE = r"""
const fs=require('fs'),k=require(process.argv[1]),x=JSON.parse(fs.readFileSync(0,'utf8'));
try {const report=k.audit(x.metadata,x.csv);process.stdout.write(JSON.stringify({ok:true,report,csv:k.derivedCSV(report)}));}
catch(e){process.stdout.write(JSON.stringify({ok:false,error:e.message}));}
"""


def base_metadata():
    return {"schema_version":"0.1","dataset_id":"parity","data_origin":"synthetic","source_refs":[],
            "oxygen_read":{"kind":"dry_inspired_po2","unit":"kPa","compartment":"gas","assay":"nominal proxy"},
            "ros":{"unit":"R-unit","compartment":"sample","assay":"R-assay"},
            "scavenger":{"unit":"A-unit","compartment":"sample","assay":"A-assay"}}


def row(**changes):
    x={k:"" for k in nop_audit.CSV_COLUMNS}
    x.update(run_id="a",arm="test",sample_id="base",occurrence="0",time_min="0",is_baseline="true",fio2="0.21",pressure_kpa="101.325",ros="2",scavenger="3")
    x.update(changes)
    return x


def csv_text(rows,extras=(),newline="\n"):
    stream=io.StringIO(newline="")
    writer=csv.DictWriter(stream,fieldnames=[*nop_audit.CSV_COLUMNS,*extras],lineterminator=newline)
    writer.writeheader();writer.writerows(rows)
    return stream.getvalue()


class WebParityTests(unittest.TestCase):
    def compare(self, metadata, text, valid=True):
        metadata_text=metadata if isinstance(metadata,str) else json.dumps(metadata)
        with tempfile.TemporaryDirectory() as folder:
            m=Path(folder)/"metadata.json";c=Path(folder)/"data.csv"
            m.write_bytes(metadata_text.encode());c.write_bytes(text.encode())
            try:
                py=nop_audit.load_and_audit(m,c)
                py_ok=True
            except nop_audit.AuditError:
                py_ok=False
            node=subprocess.run(["node","-e",NODE,str(ROOT/"web/kernel.js")],input=json.dumps({"metadata":metadata_text,"csv":text}),text=True,capture_output=True,check=True)
            js=json.loads(node.stdout)
            self.assertEqual(py_ok,valid)
            self.assertEqual(js["ok"],py_ok,js.get("error"))
            if not valid:return
            actual=js["report"]
            for field in ("schema_version","tool_version","dataset_id","data_origin","metadata","counts","warnings","interpretation"):
                self.assertEqual(actual[field],py[field],field)
            self.assertEqual(len(actual["rows"]),len(py["rows"]))
            for a,b in zip(actual["rows"],py["rows"]):
                ae=a.pop("eta");be=b.pop("eta")
                self.assertEqual(a,b)
                self.assertEqual(ae["display_only"],be["display_only"])
                self.assertAlmostEqual(ae["approximate_float"],be["approximate_float"],places=11)
            py_csv=list(csv.DictReader(io.StringIO(nop_audit._derived_csv_bytes(nop_audit.load_and_audit(m,c)).decode())))
            js_csv=list(csv.DictReader(io.StringIO(js["csv"])))
            for a,b in zip(js_csv,py_csv):
                a.pop("eta_approximate_display_only");b.pop("eta_approximate_display_only")
                self.assertEqual(json.loads(a.pop("extra_fields_json")),json.loads(b.pop("extra_fields_json")))
                self.assertEqual(a,b)

    def test_current_embedded_demo_parity(self):
        self.compare((ROOT/"examples/metadata.json").read_text(),(ROOT/"examples/synthetic.csv").read_text())
        result=subprocess.run(["node","-e","require(process.argv[1]);process.stdout.write(JSON.stringify(globalThis.NOP_DEMO));",str(ROOT/"web/demo.js")],capture_output=True,text=True,check=True)
        demo=json.loads(result.stdout)
        self.assertEqual(demo["metadataText"],(ROOT/"examples/metadata.json").read_text())
        self.assertEqual(demo["csvText"],(ROOT/"examples/synthetic.csv").read_text())

    def test_fractional_intervals_ties_interleaving_extra_and_endpoint(self):
        meta=base_metadata();meta["scavenger"]["compartment"]="other declared compartment"
        meta["endpoint"]={"name":"HIF-1alpha assay","unit":"signal","compartment":"declared tissue","assay":"declared assay"}
        rows=[row(ros="1/3",ros_low="0.2",ros_high="0.5",endpoint="0.1",note='first, "quoted"\r\nline'),
              row(run_id="b",endpoint="1",note="interleaved"),
              row(sample_id="follow",occurrence="1",is_baseline="false",ros="2/3",ros_low="0.4",ros_high="1",scavenger="6",endpoint=".3",note="same time"),
              row(run_id="b",sample_id="b-follow",occurrence="1",time_min="2",is_baseline="0",fio2=".3",endpoint="2",note="end")]
        self.compare(meta,csv_text(rows,("note",),"\r\n"))

    def test_random_exact_interval_inputs(self):
        rng=random.Random(114)
        rows=[]
        for run in range(12):
            for n in range(8):
                r=rng.randint(2,100);a=rng.randint(2,100)
                rows.append(row(run_id=f"run{run}",sample_id=f"s{n}",occurrence=str(n),time_min=str(n//2),is_baseline="1" if n==0 else "0",ros=f"{r}/7",ros_low=f"{r-1}/7",ros_high=f"{r+1}/7",scavenger=f"{a}/11",scavenger_low=f"{a-1}/11",scavenger_high=f"{a+1}/11"))
        self.compare(base_metadata(),csv_text(rows))

    def test_oxygen_kinds_and_zero_dry_proxy(self):
        self.compare(base_metadata(),csv_text([row(fio2="0")]))
        for kind in ("arterial_po2","tissue_po2"):
            meta=base_metadata();meta["oxygen_read"]["kind"]=kind
            self.compare(meta,csv_text([row(oxygen="12",oxygen_low="10",oxygen_high="14"),row(sample_id="next",occurrence="1",is_baseline="0",oxygen="13",oxygen_low="12",oxygen_high="15")]))

    def test_invalid_values_bounds_identity_and_order(self):
        for changes in ({"fio2":"1.1"},{"fio2":"NaN"},{"pressure_kpa":"0"},{"ros":"0"},{"ros":"Infinity"},{"scavenger":"-1"},{"ros_low":"1"},{"ros_low":"3","ros_high":"4"},{"oxygen":"21"},{"occurrence":"1/2"},{"is_baseline":"maybe"}):
            with self.subTest(changes=changes):self.compare(base_metadata(),csv_text([row(**changes)]),False)
        for changes in ({"occurrence":"0"},{"time_min":"-1"},{"sample_id":"base"},{"is_baseline":"1"},{"arm":"other"}):
            next_row=row(sample_id="next",occurrence="1",is_baseline="0");next_row.update(changes)
            with self.subTest(changes=changes):self.compare(base_metadata(),csv_text([row(),next_row]),False)

    def test_invalid_metadata_and_summary_rejection(self):
        for section in ("oxygen_read","ros","scavenger"):
            for key in ("unit","compartment","assay"):
                meta=base_metadata();del meta[section][key]
                with self.subTest(section=section,key=key):self.compare(meta,csv_text([row()]),False)
        for change in ({"data_origin":"extracted_summary"},{"schema_version":"0.2"},{"source_refs":"not a list"}):
            meta=base_metadata();meta.update(change);self.compare(meta,csv_text([row()]),False)
        duplicate=json.dumps(base_metadata()).replace('"dataset_id": "parity"','"dataset_id": "first", "dataset_id": "second"')
        self.compare(duplicate,csv_text([row()]),False)

    def test_headers_empty_and_malformed_csv(self):
        correct=csv_text([row()])
        for text in ("",correct.replace("run_id,arm", "run_id,run_id",1),correct.replace("run_id,", "",1),correct+'"unterminated',correct+"short,row\n"):
            with self.subTest(text=text[:50]):self.compare(base_metadata(),text,False)


if __name__=="__main__":unittest.main()
