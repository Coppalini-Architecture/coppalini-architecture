"""Acceptance tests for exact paired arithmetic, typing, order, and receipts."""

import copy
import csv
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from fractions import Fraction
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import nop_audit as audit


def metadata():
    return {
        "schema_version": "0.1", "dataset_id": "test-paired", "data_origin": "synthetic",
        "source_refs": [],
        "oxygen_read": {"kind": "dry_inspired_po2", "unit": "kPa", "compartment": "inspired dry gas", "assay": "fio2 times absolute pressure"},
        "ros": {"unit": "assay-unit-R", "compartment": "sample compartment", "assay": "declared ROS assay"},
        "scavenger": {"unit": "assay-unit-A", "compartment": "sample compartment", "assay": "declared scavenger assay"},
    }


def sample(**changes):
    row = {column: "" for column in audit.CSV_COLUMNS}
    row.update(run_id="run-a", arm="exposure", sample_id="baseline", occurrence="0",
               time_min="0", is_baseline="1", fio2="0.21", pressure_kpa="100", ros="2", scavenger="3")
    row.update(changes)
    return row


def followup(**changes):
    row = sample(sample_id="followup", occurrence="1", time_min="1", is_baseline="0", ros="4", scavenger="6")
    row.update(changes)
    return row


class AuditTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.meta_path = self.root / "metadata.json"
        self.data_path = self.root / "samples.csv"

    def tearDown(self):
        self.temp.cleanup()

    def inputs(self, rows=None, meta=None, extra_columns=()):
        self.meta_path.write_text(json.dumps(metadata() if meta is None else meta), encoding="utf-8")
        with self.data_path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=[*audit.CSV_COLUMNS, *extra_columns])
            writer.writeheader()
            writer.writerows([sample(), followup()] if rows is None else rows)
        return self.meta_path, self.data_path

    def run_audit(self, rows=None, meta=None, extra_columns=()):
        return audit.load_and_audit(*self.inputs(rows, meta, extra_columns))

    def test_equal_redox_scaling_retains_state_difference_when_ratio_returns(self):
        report = self.run_audit()
        result = report["rows"][1]
        self.assertEqual(result["derived"]["r"]["value"], "2")
        self.assertEqual(result["derived"]["a"]["value"], "2")
        self.assertEqual(result["derived"]["q"]["value"], "1")
        self.assertEqual(result["derived"]["scale_squared"]["value"], "4")
        self.assertEqual(result["eta"]["approximate_float"], 0)
        self.assertTrue(result["redox_difference_resolved"])
        self.assertEqual(result["relationship"], "returned_read_with_redox_difference")

    def test_decimal_and_rational_inputs_remain_exact(self):
        report = self.run_audit([sample(fio2="1/3", pressure_kpa="0.3", ros="0.1"),
                                 followup(fio2="1/3", pressure_kpa="3/10", ros="0.3")])
        self.assertEqual(report["rows"][0]["inputs"]["oxygen"]["value"], "1/10")
        self.assertEqual(report["rows"][1]["derived"]["r"]["value"], "3")
        self.assertEqual(audit.parse_fraction("1e-3", "value"), Fraction(1, 1000))

    def test_assay_unit_conversion_preserves_all_normalized_quantities(self):
        rows = [sample(ros_low="1", ros_high="3", scavenger_low="2", scavenger_high="4"),
                followup(ros_low="3", ros_high="5", scavenger_low="5", scavenger_high="7")]
        original = self.run_audit(rows)
        converted = copy.deepcopy(rows)
        for row in converted:
            for name, factor in (("ros", Fraction(1000)), ("scavenger", Fraction(1, 1000000))):
                for column in (name, f"{name}_low", f"{name}_high"):
                    row[column] = str(Fraction(row[column]) * factor)
        converted_meta = metadata()
        converted_meta["ros"]["unit"] = "converted R units"
        converted_meta["scavenger"]["unit"] = "converted A units"
        changed = self.run_audit(converted, converted_meta)
        for before, after in zip(original["rows"], changed["rows"]):
            self.assertEqual(before["derived"], after["derived"])
            self.assertEqual(before["eta"], after["eta"])
            self.assertEqual(before["relationship"], after["relationship"])

    def test_uncertainty_overlap_remains_unresolved(self):
        result = self.run_audit([
            sample(ros="1", ros_low="0.9", ros_high="1.1", scavenger="1"),
            followup(ros="1.05", ros_low="0.95", ros_high="1.15", scavenger="1"),
        ])["rows"][1]
        self.assertEqual(result["derived"]["r"]["status"], "unresolved_at_recorded_bounds")
        self.assertLess(Fraction(result["derived"]["r"]["low"]), 1)
        self.assertGreater(Fraction(result["derived"]["r"]["high"]), 1)
        self.assertFalse(result["redox_difference_resolved"])
        self.assertEqual(result["relationship"], "exact_read_return_without_resolved_redox_difference")

    def test_baseline_self_ratios_cancel_even_with_uncertainty(self):
        result = self.run_audit([sample(ros_low="1", ros_high="3", scavenger_low="1", scavenger_high="5")])["rows"][0]
        for name in ("r", "a", "q", "scale_squared"):
            metric = result["derived"][name]
            self.assertEqual((metric["value"], metric["low"], metric["high"]), ("1", "1", "1"))
            self.assertEqual(metric["bounds_basis"], "baseline_self_cancellation")

    def test_oxygen_overlap_is_only_a_return_candidate(self):
        result = self.run_audit([sample(oxygen_low="20", oxygen_high="22"),
                                 followup(fio2="0.22", oxygen_low="21", oxygen_high="23")])["rows"][1]
        self.assertEqual(result["oxygen_comparison"], "compatible_with_return")
        self.assertEqual(result["relationship"], "return_candidate")
        self.assertTrue(result["redox_difference_resolved"])

    def test_oxygen_disjoint_bounds_are_changed_read(self):
        result = self.run_audit([sample(oxygen_low="20", oxygen_high="22"),
                                 followup(fio2="0.3", oxygen_low="29", oxygen_high="31")])["rows"][1]
        self.assertEqual(result["oxygen_comparison"], "changed_read")

    def test_wrong_fio2_and_nonfinite_numbers_are_rejected(self):
        for value in ("-0.1", "1.01", "NaN", "Infinity", "-inf"):
            with self.subTest(value=value), self.assertRaisesRegex(audit.AuditError, "fio2"):
                self.run_audit([sample(fio2=value)])
        for value in ("NaN", "Inf", "0", "-1", "1/0"):
            with self.subTest(ros=value), self.assertRaisesRegex(audit.AuditError, "ros"):
                self.run_audit([sample(ros=value)])

    def test_dry_inspired_zero_is_a_valid_nominal_proxy(self):
        result = self.run_audit([sample(fio2="0")])["rows"][0]
        self.assertEqual(result["inputs"]["oxygen"]["value"], "0")

    def test_supplied_dry_oxygen_requires_exact_agreement(self):
        with self.assertRaisesRegex(audit.AuditError, "differs from exact"):
            self.run_audit([sample(oxygen="21.0000000001")])

    def test_arterial_and_tissue_require_their_own_positive_read(self):
        for kind in ("arterial_po2", "tissue_po2"):
            meta = metadata()
            meta["oxygen_read"]["kind"] = kind
            with self.subTest(kind=kind), self.assertRaisesRegex(audit.AuditError, "oxygen"):
                self.run_audit([sample()], meta)
            result = self.run_audit([sample(oxygen="12")], meta)["rows"][0]
            self.assertEqual(result["inputs"]["oxygen"]["value"], "12")

    def test_required_measurement_metadata(self):
        for descriptor in ("oxygen_read", "ros", "scavenger"):
            for field in ("unit", "compartment", "assay"):
                meta = metadata()
                del meta[descriptor][field]
                with self.subTest(descriptor=descriptor, field=field), self.assertRaisesRegex(audit.AuditError, field):
                    self.run_audit(meta=meta)
        meta = metadata()
        meta["oxygen_read"]["unit"] = "mmHg"
        with self.assertRaisesRegex(audit.AuditError, "kPa"):
            self.run_audit(meta=meta)

    def test_extracted_summary_cannot_enter_paired_analysis(self):
        meta = metadata()
        meta["data_origin"] = "extracted_summary"
        with self.assertRaisesRegex(audit.AuditError, "cannot establish paired"):
            self.run_audit(meta=meta)

    def test_interleaved_runs_and_tied_clock_keep_occurrence_order(self):
        rows = [sample(sample_id="a0"), sample(run_id="run-b", sample_id="b0"),
                followup(sample_id="exposure_end_0_minus", time_min="0"),
                followup(run_id="run-b", sample_id="b1", time_min="0"),
                followup(sample_id="return_0_plus", occurrence="2", time_min="0")]
        report = self.run_audit(rows)
        self.assertEqual([row["sample_id"] for row in report["rows"]], [row["sample_id"] for row in rows])
        self.assertEqual(report["counts"]["tied_clock_rows"], 3)
        self.assertIn("tied_clock_readings_ordered_by_occurrence", [warning["code"] for warning in report["warnings"]])

    def test_duplicate_or_decreasing_occurrence_and_decreasing_time_fail(self):
        for changed in (dict(occurrence="0"), dict(occurrence="-1"), dict(time_min="-1")):
            with self.subTest(changed=changed), self.assertRaises(audit.AuditError):
                self.run_audit([sample(), followup(**changed)])

    def test_baseline_first_unique_and_sample_ids_unique_within_run(self):
        for rows in ([followup()], [sample(), followup(is_baseline="1")],
                     [sample(), followup(sample_id="baseline")]):
            with self.subTest(rows=rows), self.assertRaises(audit.AuditError):
                self.run_audit(rows)
        report = self.run_audit([sample(), sample(run_id="other")])
        self.assertEqual(report["counts"]["runs"], 2)

    def test_bounds_require_both_order_and_positive_values(self):
        for changes in (dict(ros_low="1"), dict(ros_low="3", ros_high="4"),
                        dict(ros_low="0", ros_high="3"), dict(ros_low="2", ros_high="1")):
            with self.subTest(changes=changes), self.assertRaises(audit.AuditError):
                self.run_audit([sample(**changes)])

    def test_extra_columns_are_retained_without_becoming_inference(self):
        report = self.run_audit([sample(stage="baseline", notes="quoted, field"),
                                 followup(stage="recovery", notes="verbatim")], extra_columns=("stage", "notes"))
        self.assertEqual(report["rows"][0]["extra_fields"], {"stage": "baseline", "notes": "quoted, field"})
        self.assertIn("extra_csv_columns_preserved", [warning["code"] for warning in report["warnings"]])

    def test_cross_compartment_composite_is_explicit(self):
        meta = metadata()
        meta["scavenger"]["compartment"] = "different sample compartment"
        report = self.run_audit(meta=meta)
        self.assertEqual(report["warnings"][0]["code"], "cross_compartment_redox_composite")

    def test_endpoint_uses_its_declared_same_run_baseline(self):
        meta = metadata()
        meta["endpoint"] = {"name": "HIF-1alpha declared assay read", "unit": "signal", "compartment": "declared tissue", "assay": "declared endpoint assay"}
        report = self.run_audit([sample(endpoint="10"), followup(endpoint="15")], meta)
        self.assertEqual(report["rows"][1]["derived"]["endpoint_normalized"]["value"], "3/2")
        with self.assertRaisesRegex(audit.AuditError, "metadata.endpoint"):
            self.run_audit([sample(endpoint="10")])
        with self.assertRaisesRegex(audit.AuditError, "baseline.*has no endpoint"):
            self.run_audit([sample(), followup(endpoint="15")], meta)

    def test_receipts_bind_exact_input_code_and_output_bytes(self):
        report = self.run_audit()
        out = self.root / "output"
        paths = audit.write_outputs(report, out)
        self.assertEqual(set(paths), set(audit.OUTPUT_NAMES))
        receipt = json.loads((out / "receipts.json").read_text())
        for key, path in (("metadata", self.meta_path), ("data", self.data_path), ("code", Path(audit.__file__))):
            self.assertEqual(receipt["provenance"][key]["sha256"], hashlib.sha256(path.read_bytes()).hexdigest())
        for name, expected in receipt["output_sha256"].items():
            self.assertEqual(hashlib.sha256((out / name).read_bytes()).hexdigest(), expected)
        self.assertEqual(receipt["counts"]["rows"], 2)
        self.assertEqual(receipt["tool_version"], audit.TOOL_VERSION)
        first_bytes = {name: (out / name).read_bytes() for name in audit.OUTPUT_NAMES}
        audit.write_outputs(report, out)
        self.assertEqual(first_bytes, {name: (out / name).read_bytes() for name in audit.OUTPUT_NAMES})

    def test_output_failure_rolls_back_existing_outputs(self):
        report = self.run_audit()
        out = self.root / "output"
        audit.write_outputs(report, out)
        before = {name: (out / name).read_bytes() for name in audit.OUTPUT_NAMES}
        changed = copy.deepcopy(report)
        changed["dataset_id"] = "changed"
        original_replace = os.replace
        failed = False

        def fail_once(source, destination):
            nonlocal failed
            if not failed and Path(destination) == out / "derived.csv" and "stage" in str(source):
                failed = True
                raise OSError("simulated output failure")
            return original_replace(source, destination)

        with patch.object(audit.os, "replace", side_effect=fail_once), self.assertRaises(audit.AuditError):
            audit.write_outputs(changed, out)
        self.assertEqual(before, {name: (out / name).read_bytes() for name in audit.OUTPUT_NAMES})

    def test_cli_rejects_late_bad_row_without_partial_outputs(self):
        self.inputs([sample(), followup(fio2="2")])
        out = self.root / "never-created"
        result = subprocess.run([sys.executable, str(Path(audit.__file__)), "audit", "--metadata",
                                 str(self.meta_path), "--data", str(self.data_path), "--out", str(out)],
                                capture_output=True, text=True, env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
        self.assertEqual(result.returncode, 2)
        self.assertIn("CSV row 3", result.stderr)
        self.assertIn(str(self.data_path), result.stderr)
        self.assertFalse(out.exists())

    def test_cli_success(self):
        self.inputs()
        out = self.root / "cli-output"
        result = subprocess.run([sys.executable, str(Path(audit.__file__)), "audit", "--metadata",
                                 str(self.meta_path), "--data", str(self.data_path), "--out", str(out)],
                                capture_output=True, text=True, env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)["status"], "complete")
        self.assertEqual({path.name for path in out.iterdir()}, set(audit.OUTPUT_NAMES))


if __name__ == "__main__":
    unittest.main()
